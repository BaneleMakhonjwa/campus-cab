<?php
session_start();
include_once __DIR__ . '/db_connect.php';

header('Content-Type: application/json');

// Check driver is logged in
if (!isset($_SESSION['driver_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

$driverID = (int)$_SESSION['driver_id'];
$rideID   = (int)($_POST['rideID'] ?? 0);
$action   = $_POST['action'] ?? '';

if ($rideID <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid ride']);
    exit;
}

// ============================================
// ACCEPT
// ============================================
if ($action === 'accept') {

    $stmt = $conn->prepare("
        UPDATE ride
        SET DriverID = ?,
            ride_status = 'Accepted',
            accepted_at = NOW()
        WHERE rideID = ?
          AND ride_status = 'Requested'
          AND DriverID IS NULL
    ");
    $stmt->bind_param("ii", $driverID, $rideID);
    $stmt->execute();

    if ($stmt->affected_rows === 1) {

        // Mark driver as Unavailable
        $upd = $conn->prepare("UPDATE driver SET availability_status = 'Unavailable' WHERE DriverID = ?");
        $upd->bind_param("i", $driverID);
        $upd->execute();
        $upd->close();

      echo json_encode([
    'success' => true,
    'message' => 'Ride accepted',
    'rideID'  => $rideID,
    'redirect' => 'driver_active_ride.php?id=' . $rideID
]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Ride already taken'
        ]);
    }

    $stmt->close();

// REJECT
} elseif ($action === 'reject') {
    echo json_encode(['success'=>true,'message'=>'Ride rejected']);

} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid action'
    ]);
}
?>