<?php
session_start();
require_once __DIR__ . '/db_connect.php';

if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}

$studentID = (int) $_SESSION['student_id'];

/*
 * Use the actual CampusCab database table/columns:
 * driver_ratings.ratingID, rideID, studentID, DriverID,
 * rating, comment, rated_at.
 */
$sql = "
    SELECT
        dr.ratingID,
        dr.rideID,
        dr.rating,
        dr.comment,
        dr.rated_at,
        d.DriverFname,
        d.DriverLname
    FROM driver_ratings dr
    LEFT JOIN driver d ON dr.DriverID = d.DriverID
    WHERE dr.studentID = ?
      AND dr.passenger_type = 'student'
    ORDER BY dr.rated_at DESC
";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('Unable to load ratings: ' . htmlspecialchars($conn->error));
}

$stmt->bind_param('i', $studentID);
$stmt->execute();
$ratings = $stmt->get_result();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My Ratings — CampusCab</title>
    <style>
        body{margin:0;background:#f6f5f1;color:#0c2d4d;font-family:Arial,Helvetica,sans-serif}
        .header{height:72px;background:#0c2d4d;display:flex;align-items:center;justify-content:space-between;padding:0 30px}
        .brand{font-size:25px;font-weight:700;text-decoration:none}
        .brand span:first-child{color:#fff}.brand span:last-child{color:#e0a526}
        .back{color:#fff;text-decoration:none}
        .wrap{max-width:950px;margin:35px auto;padding:0 20px}
        .card{background:#fff;border:1px solid #e0e4e7;border-radius:12px;overflow:hidden}
        .title{padding:22px;border-bottom:1px solid #e5e8ea;font-size:21px;font-weight:700}
        .row{padding:18px 22px;border-bottom:1px solid #eef0f1}
        .row:last-child{border-bottom:0}
        .driver{font-weight:700}
        .stars{color:#e0a526;font-size:18px;margin:5px 0}
        .comment{color:#64737e;font-size:13px}
        .date{font-size:11px;color:#89949b;margin-top:6px}
        .empty{padding:45px;text-align:center;color:#71808a}
        @media(max-width:650px){.header{padding:0 16px}.brand{font-size:21px}}
    </style>
</head>
<body>
<header class="header">
    <a class="brand" href="student_dashboard.php"><span>Campus</span><span>Cab</span></a>
    <a class="back" href="student_dashboard.php">← Dashboard</a>
</header>

<main class="wrap">
    <section class="card">
        <div class="title">My Ratings</div>

        <?php if ($ratings->num_rows === 0): ?>
            <div class="empty">You have not rated any drivers yet.</div>
        <?php else: ?>
            <?php while ($r = $ratings->fetch_assoc()): ?>
                <?php $stars = max(0, min(5, (int)$r['rating'])); ?>
                <div class="row">
                    <div class="driver">
                        <?php
                        echo htmlspecialchars(
                            trim(($r['DriverFname'] ?? '') . ' ' . ($r['DriverLname'] ?? '')) ?: 'Driver'
                        );
                        ?>
                    </div>
                    <div class="stars">
                        <?php echo str_repeat('★', $stars) . str_repeat('☆', 5 - $stars); ?>
                    </div>
                    <?php if (!empty($r['comment'])): ?>
                        <div class="comment"><?php echo htmlspecialchars($r['comment']); ?></div>
                    <?php endif; ?>
                    <div class="date">
                        Ride #<?php echo (int)$r['rideID']; ?> ·
                        <?php echo htmlspecialchars($r['rated_at']); ?>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
<?php $stmt->close(); ?>
