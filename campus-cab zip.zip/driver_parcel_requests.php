<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include_once __DIR__ . '/db_connect.php';

$driverID = (int)($_SESSION['driver_id'] ?? 0);

if ($driverID <= 0) {
    header("Location: login.php?role=driver");
    exit;
}

$driverName = "Driver";

$stmt = $conn->prepare("
    SELECT DriverFname, DriverLname
    FROM driver
    WHERE DriverID = ?
    LIMIT 1
");

if ($stmt) {
    $stmt->bind_param("i", $driverID);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $driverName = trim(
            ($row['DriverFname'] ?? '') . ' ' .
            ($row['DriverLname'] ?? '')
        );

        if ($driverName === '') {
            $driverName = "Driver";
        }
    }

    $stmt->close();
}

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';
    $parcelID = (int)($_POST['parcelID'] ?? 0);

    if ($parcelID <= 0) {
        $message = "Invalid parcel.";
        $messageType = "error";
    } else {

        if ($action === 'accept') {

            $stmt = $conn->prepare("
                UPDATE parcel
                SET
                    DriverID = ?,
                    parcel_status = 'Accepted'
                WHERE parcel = ?
                  AND parcel_status = 'Requested'
                  AND DriverID IS NULL
            ");

            if ($stmt) {
                $stmt->bind_param("ii", $driverID, $parcelID);

                if ($stmt->execute() && $stmt->affected_rows === 1) {
                    $busy = $conn->prepare("UPDATE driver SET availability_status='Unavailable' WHERE DriverID=?");
                    $busy->bind_param('i', $driverID);
                    $busy->execute();
                    $busy->close();
                    $message = "Parcel accepted successfully.";
                    $messageType = "success";
                } else {
                    $message = "This parcel is no longer available.";
                    $messageType = "error";
                }

                $stmt->close();
            }

        } elseif ($action === 'start') {

            $stmt = $conn->prepare("
                UPDATE parcel
                SET parcel_status = 'In Progress'
                WHERE parcel = ?
                  AND DriverID = ?
                  AND parcel_status = 'Accepted'
            ");

            if ($stmt) {
                $stmt->bind_param("ii", $parcelID, $driverID);

                if ($stmt->execute() && $stmt->affected_rows === 1) {
                    $message = "Delivery started.";
                    $messageType = "success";
                } else {
                    $message = "Unable to start this delivery.";
                    $messageType = "error";
                }

                $stmt->close();
            }

        } elseif ($action === 'cancel') {

            $reason = trim($_POST['cancellation_reason'] ?? '');

            $stmt = $conn->prepare("
                UPDATE parcel
                SET
                    parcel_status = 'Cancelled'
                WHERE parcel = ?
                  AND DriverID = ?
                  AND parcel_status IN ('Accepted', 'In Progress')
            ");

            if ($stmt) {
                $stmt->bind_param("ii", $parcelID, $driverID);

                if ($stmt->execute() && $stmt->affected_rows === 1) {
                    $free = $conn->prepare("UPDATE driver SET availability_status='Available' WHERE DriverID=?");
                    $free->bind_param('i', $driverID);
                    $free->execute();
                    $free->close();
                    $message = "Delivery cancelled.";
                    $messageType = "success";
                } else {
                    $message = "Unable to cancel this delivery.";
                    $messageType = "error";
                }

                $stmt->close();
            }
        }
    }
}

$stmt = $conn->prepare("
    SELECT
        p.parcel AS parcelID,
        p.studentID,
        p.parcel_description,
        p.parcel_size,
        p.recipient_name,
        p.recipient_contact,
        p.pickup_location,
        p.destination,
        p.estimated_price,
        p.requested_at,
        p.parcel_status,
        s.studentFname,
        s.studentLname,
        st.staff_name,
        st.surname
    FROM parcel p
    LEFT JOIN student s ON p.studentID = s.studentID
    LEFT JOIN staff st ON p.staff_id = st.staff_id
    WHERE p.parcel_status = 'Requested'
      AND p.DriverID IS NULL
    ORDER BY p.requested_at ASC
");

$newParcels = [];

if ($stmt) {
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $newParcels[] = $row;
    }

    $stmt->close();
}

$stmt = $conn->prepare("
    SELECT
        p.parcel AS parcelID,
        p.studentID,
        p.parcel_description,
        p.parcel_size,
        p.recipient_name,
        p.recipient_contact,
        p.pickup_location,
        p.destination,
        p.estimated_price,
        p.requested_at,
        p.parcel_status,
        s.studentFname,
        s.studentLname,
        st.staff_name,
        st.surname
    FROM parcel p
    LEFT JOIN student s ON p.studentID = s.studentID
    LEFT JOIN staff st ON p.staff_id = st.staff_id
    WHERE p.DriverID = ?
      AND p.parcel_status IN ('Accepted', 'In Progress')
    ORDER BY p.requested_at DESC
");

$activeParcels = [];

if ($stmt) {
    $stmt->bind_param("i", $driverID);
    $stmt->execute();

    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $activeParcels[] = $row;
    }

    $stmt->close();
}

function getStudentName($parcel)
{
    $name = trim(($parcel['studentFname'] ?? '') . ' ' . ($parcel['studentLname'] ?? ''));
    if ($name !== '') return $name;
    $name = trim(($parcel['staff_name'] ?? '') . ' ' . ($parcel['surname'] ?? ''));
    return $name !== '' ? $name : 'Requester';
}

function getInitials($name)
{
    $words = preg_split('/\s+/', trim($name));

    if (count($words) >= 2) {
        return strtoupper(
            substr($words[0], 0, 1) .
            substr($words[1], 0, 1)
        );
    }

    return strtoupper(substr($name, 0, 2));
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Parcel Services - CampusCab</title>

    <link rel="stylesheet" href="style.css">

    <style>

        /* =========================================================
           PARCELS PAGE
           ========================================================= */

        .parcels-page {
            max-width: 1100px;
            margin: 0 auto;
            padding: 35px 25px 60px;
        }

        .parcels-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        .parcels-header h1 {
            margin: 0 0 6px;
            color: #0c2d4d;
            font-size: 30px;
            font-weight: 800;
        }

        .parcels-header p {
            margin: 0;
            color: #6b7280;
            font-size: 15px;
        }

        .back-button {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #0c2d4d;
            color: #ffffff;
            text-decoration: none;
            padding: 11px 18px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            transition: background 0.25s ease;
        }

        .back-button:hover {
            background: #185fa5;
            color: #ffffff;
        }

        .parcels-message {
            padding: 14px 18px;
            border-radius: 8px;
            margin-bottom: 25px;
            font-weight: 600;
            font-size: 14px;
        }

        .parcels-message.success {
            background: #dcf1e9;
            color: #0f6e56;
            border-left: 4px solid #0f6e56;
        }

        .parcels-message.error {
            background: #fbe2df;
            color: #b03a2e;
            border-left: 4px solid #b03a2e;
        }

        .parcels-section {
            margin-bottom: 45px;
        }

        .section-title {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 20px;
        }

        .section-title h2 {
            margin: 0;
            color: #0c2d4d;
            font-size: 22px;
            font-weight: 700;
        }

        .section-count {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 28px;
            height: 28px;
            padding: 0 10px;
            border-radius: 20px;
            background: #e0a526;
            color: #0c2d4d;
            font-size: 13px;
            font-weight: 700;
        }

        .parcels-empty {
            background: #ffffff;
            border: 1px solid #e2e2dc;
            border-radius: 14px;
            padding: 50px 30px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(11, 31, 58, 0.04);
        }

        .empty-icon {
            font-size: 48px;
            margin-bottom: 12px;
        }

        .parcels-empty h3 {
            margin: 0 0 8px;
            color: #0c2d4d;
            font-size: 18px;
        }

        .parcels-empty p {
            margin: 0;
            color: #6b7280;
            font-size: 14px;
            line-height: 1.6;
            max-width: 400px;
            margin-left: auto;
            margin-right: auto;
        }

        .parcels-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 20px;
        }

        .parcel-card {
            background: #ffffff;
            border: 1px solid #e2e2dc;
            border-radius: 14px;
            padding: 22px;
            box-shadow: 0 4px 14px rgba(11, 31, 58, 0.06);
            display: flex;
            flex-direction: column;
            transition: transform 0.25s ease, box-shadow 0.25s ease;
        }

        .parcel-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 22px rgba(11, 31, 58, 0.1);
        }

        .parcel-card-new {
            border-left: 4px solid #e0a526;
        }

        .parcel-card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 18px;
            padding-bottom: 15px;
            border-bottom: 1px solid #f0f1f3;
        }

        .parcel-student {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .parcel-initials {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: #0c2d4d;
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 14px;
            flex-shrink: 0;
        }

        .parcel-student-name {
            color: #0c2d4d;
            font-size: 15px;
            font-weight: 700;
        }

        .parcel-id {
            color: #6b7280;
            font-size: 12px;
            margin-top: 3px;
        }

        .parcel-status {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.4px;
            white-space: nowrap;
        }

        .status-new {
            background: #fbecc9;
            color: #8a6d00;
        }

        .status-accepted {
            background: #dbe8fb;
            color: #185fa5;
        }

        .status-in-progress {
            background: #fef3c7;
            color: #b8860b;
        }

        .status-completed {
            background: #dcf1e9;
            color: #0f6e56;
        }

        .status-cancelled {
            background: #fbe2df;
            color: #b03a2e;
        }

        .parcel-details {
            display: grid;
            gap: 10px;
            margin-bottom: 18px;
            flex-grow: 1;
        }

        .parcel-detail {
            display: flex;
            flex-direction: column;
            gap: 3px;
        }

        .detail-label {
            color: #6b7280;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }

        .detail-value {
            color: #172033;
            font-size: 14px;
            line-height: 1.5;
            word-break: break-word;
        }

        .parcel-price {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 14px;
            background: #f8f9fa;
            border-radius: 8px;
            margin-bottom: 16px;
        }

        .price-label {
            color: #6b7280;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }

        .price-value {
            color: #0f6e56;
            font-size: 18px;
            font-weight: 800;
        }

        .parcel-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .parcel-actions form {
            flex: 1;
            min-width: 120px;
        }

        .action-btn {
            width: 100%;
            border: none;
            border-radius: 8px;
            padding: 12px 18px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.25s ease;
            font-family: inherit;
        }

        .btn-accept {
            background: #0f6e56;
            color: #ffffff;
        }

        .btn-accept:hover {
            background: #0b5a45;
            transform: translateY(-1px);
        }

        .btn-start {
            background: #185fa5;
            color: #ffffff;
        }

        .btn-start:hover {
            background: #134a80;
            transform: translateY(-1px);
        }

        .btn-complete {
            background: #0f6e56;
            color: #ffffff;
        }

        .btn-complete:hover {
            background: #0b5a45;
            transform: translateY(-1px);
        }

        .btn-cancel {
            background: #b03a2e;
            color: #ffffff;
        }

        .btn-cancel:hover {
            background: #8e2f25;
            transform: translateY(-1px);
        }

        .btn-close {
            background: #6b7280;
            color: #ffffff;
        }

        .btn-close:hover {
            background: #4b5563;
        }

        .modal {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(12, 45, 77, 0.6);
            align-items: center;
            justify-content: center;
            z-index: 1000;
            padding: 20px;
        }

        .modal-content {
            background: #ffffff;
            width: 100%;
            max-width: 480px;
            padding: 30px;
            border-radius: 14px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
        }

        .modal-content h3 {
            margin: 0 0 6px;
            color: #0c2d4d;
            font-size: 20px;
        }

        .modal-content > p {
            margin: 0 0 20px;
            color: #6b7280;
            font-size: 14px;
        }

        .modal-content label {
            display: block;
            font-weight: 600;
            font-size: 13px;
            color: #0c2d4d;
            margin-bottom: 6px;
        }

        .modal-content textarea {
            width: 100%;
            min-height: 110px;
            padding: 12px;
            border: 1px solid #dfe3e8;
            border-radius: 8px;
            font-family: inherit;
            font-size: 14px;
            resize: vertical;
            margin-bottom: 20px;
            box-sizing: border-box;
        }

        .modal-content textarea:focus {
            outline: none;
            border-color: #185fa5;
            box-shadow: 0 0 0 3px rgba(24, 95, 165, 0.15);
        }

        .modal-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }

        .modal-actions .action-btn {
            width: auto;
            padding: 11px 22px;
        }

        @media (max-width: 700px) {

            .parcels-page {
                padding: 25px 15px 45px;
            }

            .parcels-header h1 {
                font-size: 24px;
            }

            .parcels-grid {
                grid-template-columns: 1fr;
            }

            .parcel-actions form {
                min-width: 100%;
            }

            .action-btn {
                width: 100%;
            }

            .modal-actions {
                flex-direction: column;
            }

            .modal-actions .action-btn {
                width: 100%;
            }
        }

    </style>

</head>

<body>

<?php include 'header.php'; ?>

<div class="parcels-page">

    <div class="parcels-header">

        <div>
            <h1>Parcel Services</h1>
            <p>Manage your active deliveries and accept new parcel service requests.</p>
        </div>
    </div>

    <?php if ($message !== ''): ?>
        <div class="parcels-message <?php echo $messageType; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>


    <section class="parcels-section">

        <div class="section-title">
            <h2>My Active Deliveries</h2>
            <span class="section-count"><?php echo count($activeParcels); ?></span>
        </div>

        <?php if (empty($activeParcels)): ?>

            <div class="parcels-empty">
                <div class="empty-icon">📦</div>
                <h3>No active deliveries</h3>
                <p>You currently have no active parcel deliveries. Accept a new request below to get started.</p>
            </div>

        <?php else: ?>

            <div class="parcels-grid">

                <?php foreach ($activeParcels as $parcel): ?>
                    <?php
                    $studentName = getStudentName((int)$parcel['parcelID']);
                    $initials = getInitials($studentName);
                    $statusClass = strtolower(str_replace(' ', '-', $parcel['parcel_status']));
                    ?>

                    <div class="parcel-card">

                        <div class="parcel-card-header">

                            <div class="parcel-student">
                                <div class="parcel-initials"><?php echo htmlspecialchars($initials); ?></div>
                                <div>
                                    <div class="parcel-student-name"><?php echo htmlspecialchars($studentName); ?></div>
                                    <div class="parcel-id">Parcel #<?php echo (int)$parcel['parcelID']; ?></div>
                                </div>
                            </div>

                            <span class="parcel-status status-<?php echo $statusClass; ?>">
                                <?php echo htmlspecialchars($parcel['parcel_status']); ?>
                            </span>

                        </div>

                        <div class="parcel-details">

                            <div class="parcel-detail">
                                <span class="detail-label">Description</span>
                                <span class="detail-value"><?php echo htmlspecialchars($parcel['parcel_description']); ?></span>
                            </div>

                            <div class="parcel-detail">
                                <span class="detail-label">Size</span>
                                <span class="detail-value"><?php echo htmlspecialchars($parcel['parcel_size']); ?></span>
                            </div>

                            <div class="parcel-detail">
                                <span class="detail-label">Recipient</span>
                                <span class="detail-value"><?php echo htmlspecialchars($parcel['recipient_name']); ?></span>
                            </div>

                            <div class="parcel-detail">
                                <span class="detail-label">Contact</span>
                                <span class="detail-value"><?php echo htmlspecialchars($parcel['recipient_contact']); ?></span>
                            </div>

                            <div class="parcel-detail">
                                <span class="detail-label">Pickup</span>
                                <span class="detail-value"><?php echo htmlspecialchars($parcel['pickup_location']); ?></span>
                            </div>

                            <div class="parcel-detail">
                                <span class="detail-label">Destination</span>
                                <span class="detail-value"><?php echo htmlspecialchars($parcel['destination']); ?></span>
                            </div>

                        </div>

                        <div class="parcel-price">
                            <span class="price-label">Earning</span>
                            <span class="price-value">R<?php echo number_format((float)$parcel['estimated_price'], 2); ?></span>
                        </div>

                        <div class="parcel-actions">

                            <?php if ($parcel['parcel_status'] === 'Accepted'): ?>
                                <form method="POST">
                                    <input type="hidden" name="parcelID" value="<?php echo (int)$parcel['parcelID']; ?>">
                                    <input type="hidden" name="action" value="start">
                                    <button type="submit" class="action-btn btn-start">Start Delivery</button>
                                </form>
                            <?php elseif ($parcel['parcel_status'] === 'In Progress'): ?>
                                <form method="GET" action="driver_complete_parcel.php">
                                    <input type="hidden" name="parcelID" value="<?php echo (int)$parcel['parcelID']; ?>">
                                    <button type="submit" class="action-btn btn-complete">Complete Delivery</button>
                                </form>
                            <?php endif; ?>

                            <button type="button" class="action-btn btn-cancel" onclick="openCancelModal(<?php echo (int)$parcel['parcelID']; ?>)">
                                Cancel
                            </button>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </section>


    <section class="parcels-section">

        <div class="section-title">
            <h2>New Parcel Services</h2>
            <span class="section-count"><?php echo count($newParcels); ?></span>
        </div>

        <?php if (empty($newParcels)): ?>

            <div class="parcels-empty">
                <div class="empty-icon">📭</div>
                <h3>No new parcel services</h3>
                <p>There are currently no new parcel requests available. Check back soon.</p>
            </div>

        <?php else: ?>

            <div class="parcels-grid">

                <?php foreach ($newParcels as $parcel): ?>
                    <?php
                    $studentName = getStudentName((int)$parcel['parcelID']);
                    $initials = getInitials($studentName);
                    ?>

                    <div class="parcel-card parcel-card-new">

                        <div class="parcel-card-header">

                            <div class="parcel-student">
                                <div class="parcel-initials"><?php echo htmlspecialchars($initials); ?></div>
                                <div>
                                    <div class="parcel-student-name"><?php echo htmlspecialchars($studentName); ?></div>
                                    <div class="parcel-id">Parcel #<?php echo (int)$parcel['parcelID']; ?></div>
                                </div>
                            </div>

                            <span class="parcel-status status-new">New</span>

                        </div>

                        <div class="parcel-details">

                            <div class="parcel-detail">
                                <span class="detail-label">Description</span>
                                <span class="detail-value"><?php echo htmlspecialchars($parcel['parcel_description']); ?></span>
                            </div>

                            <div class="parcel-detail">
                                <span class="detail-label">Size</span>
                                <span class="detail-value"><?php echo htmlspecialchars($parcel['parcel_size']); ?></span>
                            </div>

                            <div class="parcel-detail">
                                <span class="detail-label">Recipient</span>
                                <span class="detail-value"><?php echo htmlspecialchars($parcel['recipient_name']); ?></span>
                            </div>

                            <div class="parcel-detail">
                                <span class="detail-label">Contact</span>
                                <span class="detail-value"><?php echo htmlspecialchars($parcel['recipient_contact']); ?></span>
                            </div>

                            <div class="parcel-detail">
                                <span class="detail-label">Pickup</span>
                                <span class="detail-value"><?php echo htmlspecialchars($parcel['pickup_location']); ?></span>
                            </div>

                            <div class="parcel-detail">
                                <span class="detail-label">Destination</span>
                                <span class="detail-value"><?php echo htmlspecialchars($parcel['destination']); ?></span>
                            </div>

                        </div>

                        <div class="parcel-price">
                            <span class="price-label">Earning</span>
                            <span class="price-value">R<?php echo number_format((float)$parcel['estimated_price'], 2); ?></span>
                        </div>

                        <div class="parcel-actions">

                            <form method="POST">
                                <input type="hidden" name="parcelID" value="<?php echo (int)$parcel['parcelID']; ?>">
                                <input type="hidden" name="action" value="accept">
                                <button type="submit" class="action-btn btn-accept">Accept Parcel</button>
                            </form>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </section>

</div>


<div class="modal" id="cancelModal">

    <div class="modal-content">

        <h3>Cancel Delivery</h3>
        <p>Please tell us why you're cancelling this delivery.</p>

        <form method="POST">

            <input type="hidden" name="action" value="cancel">
            <input type="hidden" name="parcel" id="cancelParcelID">

            <label for="cancellation_reason">Reason for cancellation</label>

            <textarea name="cancellation_reason" id="cancellation_reason" placeholder="Type your reason here..." required></textarea>

            <div class="modal-actions">
                <button type="button" class="action-btn btn-close" onclick="closeCancelModal()">Close</button>
                <button type="submit" class="action-btn btn-cancel">Cancel Delivery</button>
            </div>

        </form>

    </div>

</div>


<script>

function openCancelModal(parcel) {
    document.getElementById('cancelParcelID').value = parcel;
    document.getElementById('cancelModal').style.display = 'flex';
}

function closeCancelModal() {
    document.getElementById('cancelModal').style.display = 'none';
}

window.addEventListener('click', function(event) {
    const modal = document.getElementById('cancelModal');
    if (event.target === modal) {
        closeCancelModal();
    }
});

</script>

<script>
// Keep the driver's public live location fresh while handling a parcel.
(function(){
  if(!navigator.geolocation) return;
  async function pingLocation(){
    if(!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(async function(pos){
      try{
        await fetch('save_driver_location.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},credentials:'same-origin',body:new URLSearchParams({ride_id:'0',lat:pos.coords.latitude,lng:pos.coords.longitude,accuracy:pos.coords.accuracy||'',parcel_id:'0'})});
      }catch(e){}
    },function(){},{enableHighAccuracy:true,timeout:15000,maximumAge:5000});
  }
  pingLocation(); setInterval(pingLocation,10000);
})();
</script>
<?php include 'footer.php'; ?>

</body>
</html>