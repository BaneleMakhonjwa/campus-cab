<?php
session_start();
include_once __DIR__ . '/db_connect.php';

// =========================================================
// DETECT USER (Student or Staff)
// =========================================================
$requestedAs = strtolower(trim((string)($_GET['as'] ?? $_POST['passenger_type'] ?? '')));
$isStudent = isset($_SESSION['student_id']) && (int)$_SESSION['student_id'] > 0;
$isStaff   = isset($_SESSION['staff_id']) && (int)$_SESSION['staff_id'] > 0;

if (!$isStudent && !$isStaff) {
    header("Location: login.php");
    exit;
}

if ($requestedAs === 'staff' && $isStaff) {
    $userID = (int)$_SESSION['staff_id'];
    $userColumn = 'staff_id';
    $requesterType = 'Staff';
    $dashboardLink = 'staff_dashboard.php';
    $requesterValue = 'staff';
} elseif ($requestedAs === 'student' && $isStudent) {
    $userID = (int)$_SESSION['student_id'];
    $userColumn = 'studentID';
    $requesterType = 'Student';
    $dashboardLink = 'student_dashboard.php';
    $requesterValue = 'student';
} elseif (strtolower((string)($_SESSION['role'] ?? '')) === 'staff' && $isStaff) {
    $userID = (int)$_SESSION['staff_id']; $userColumn = 'staff_id'; $requesterType = 'Staff'; $dashboardLink = 'staff_dashboard.php'; $requesterValue = 'staff';
} elseif ($isStudent) {
    $userID = (int)$_SESSION['student_id']; $userColumn = 'studentID'; $requesterType = 'Student'; $dashboardLink = 'student_dashboard.php'; $requesterValue = 'student';
} else {
    $userID = (int)$_SESSION['staff_id']; $userColumn = 'staff_id'; $requesterType = 'Staff'; $dashboardLink = 'staff_dashboard.php'; $requesterValue = 'staff';
}

$aliceOnlySearch = true;

// Load campus locations
$locations = [];
$result = $conn->query("SELECT location_id, name, latitude, longitude FROM campus_location ORDER BY name");
while ($row = $result->fetch_assoc()) {
    $locations[] = $row;
}

// Load available drivers using the actual database columns.
$drivers = [];
$driverQuery = $conn->query("
    SELECT
        d.DriverID, d.DriverFname, d.DriverLname, d.profile_picture,
        d.vehicle_registration, d.vehicle_make, d.vehicle_model,
        l.latitude, l.longitude
    FROM driver d
    LEFT JOIN location l ON l.driver_id = d.DriverID
        AND l.recorded_at = (
            SELECT MAX(l2.recorded_at)
            FROM location l2
            WHERE l2.driver_id = d.DriverID
              AND l2.request_type = 'availability'
        )
    WHERE d.availability_status = 'Available'
      AND d.driverAccount_Status = 'Active'
");
while ($row = $driverQuery->fetch_assoc()) {
    $drivers[] = $row;
}

$pageTitle = "Request a Ride";
include 'header.php';
?>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<style>
.request-page { max-width: 900px; margin: 0 auto; padding: 35px 25px 60px; }
.request-page h1 { color: #0c2d4d; font-size: 28px; font-weight: 800; margin: 0 0 6px; }
.request-page .subtitle { color: #6b7280; font-size: 15px; margin: 0 0 30px; }
.card { background: #fff; border: 1px solid #e2e2dc; border-radius: 14px; padding: 30px; box-shadow: 0 4px 14px rgba(11,31,58,0.05); margin-bottom: 20px; }
.card h2 { color: #0c2d4d; font-size: 16px; font-weight: 700; margin: 0 0 16px; padding-bottom: 10px; border-bottom: 1px solid #f0f1f3; }
.form-group { margin-bottom: 18px; }
.form-group label { display: block; font-weight: 600; font-size: 14px; color: #0c2d4d; margin-bottom: 6px; }
.form-group input, .form-group select { width: 100%; padding: 12px; border: 1px solid #dfe3e8; border-radius: 8px; font-size: 15px; font-family: inherit; box-sizing: border-box; }
.form-group input:focus, .form-group select:focus { outline: none; border-color: #185fa5; box-shadow: 0 0 0 3px rgba(24,95,165,0.15); }
.location-search { position: relative; margin-bottom: 10px; }
.location-search input { width:100%; padding:12px 42px 12px 12px; border:1px solid #dfe3e8; border-radius:8px; font-size:15px; box-sizing:border-box; }
.location-search input:focus { outline:none; border-color:#185fa5; box-shadow:0 0 0 3px rgba(24,95,165,.15); }
.location-results { display:none; position:absolute; z-index:1000; left:0; right:0; top:100%; background:#fff; border:1px solid #dfe3e8; border-top:0; border-radius:0 0 8px 8px; max-height:230px; overflow-y:auto; box-shadow:0 8px 20px rgba(0,0,0,.12); }
.location-result { padding:11px 12px; cursor:pointer; border-top:1px solid #f0f1f3; font-size:14px; }
.location-result:hover { background:#f4f8fc; }
.location-result strong { display:block; color:#0c2d4d; }
.location-result span { color:#6b7280; font-size:12px; }
.search-status { color:#6b7280; font-size:12px; margin-top:5px; min-height:16px; }
.form-group small { display: block; color: #6b7280; font-size: 12px; margin-top: 5px; }
.mini-map { height: 220px; border-radius: 10px; margin-top: 10px; border: 1px solid #dfe3e8; }
.drivers-map { height: 320px; border-radius: 12px; border: 1px solid #dfe3e8; }
.driver-list { display: grid; gap: 12px; margin-top: 15px; }
.driver-item { display: flex; align-items: center; gap: 14px; padding: 14px; background: #f8f9fa; border-radius: 10px; border: 1px solid #e5e8ea; }
.driver-avatar { width: 48px; height: 48px; border-radius: 50%; background: #0c2d4d; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 16px; flex-shrink: 0; overflow: hidden; }
.driver-avatar img { width: 100%; height: 100%; object-fit: cover; }
.driver-info { flex: 1; }
.driver-info h4 { margin: 0 0 3px; font-size: 14px; color: #0c2d4d; }
.driver-info p { margin: 0; font-size: 12.5px; color: #6b7280; }
.price-box { background: linear-gradient(135deg, #0c2d4d, #185fa5); border-radius: 12px; padding: 24px; color: #fff; margin-top: 20px; }
.price-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 14px; }
.price-row.total { border-top: 1px solid rgba(255,255,255,0.3); margin-top: 10px; padding-top: 14px; font-size: 20px; font-weight: 800; }
.rate-badge { display: inline-block; padding: 4px 12px; border-radius: 20px; background: #fef3c7; color: #b8860b; font-size: 11px; font-weight: 700; text-transform: uppercase; margin-left: 8px; }
.rate-badge.night { background: #dbe8fb; color: #185fa5; }
.rate-badge.peak { background: #fbe2df; color: #b03a2e; }
.btn-submit { width: 100%; padding: 16px; background: #0c2d4d; color: #fff; border: none; border-radius: 10px; font-size: 16px; font-weight: 700; cursor: pointer; font-family: inherit; margin-top: 20px; }
.btn-submit:hover { background: #185fa5; }
.btn-back { display: inline-block; padding: 10px 18px; background: #6b7280; color: #fff; text-decoration: none; border-radius: 8px; font-size: 13px; font-weight: 600; margin-bottom: 20px; }
</style>

<div class="request-page">

    <a href="<?php echo $dashboardLink; ?>" class="btn-back">← Back to Dashboard</a>

    <h1>🚗 Request a Ride</h1>
    <p class="subtitle">Book a ride around campus or in Alice.</p>

    <form method="POST" action="save_ride.php" id="rideForm">
        <input type="hidden" name="passenger_type" value="<?php echo htmlspecialchars($requesterValue); ?>">

        <div class="card">
            <h2>📍 Pickup Location</h2>

            <div class="form-group">
                <label for="pickupSearch">Search pickup location</label>
                <div class="location-search">
                    <input type="text" id="pickupSearch" autocomplete="off" placeholder="Search an address, residence, building or place...">
                    <div id="pickupResults" class="location-results"></div>
                </div>
                <div id="pickupSearchStatus" class="search-status"></div>
                <label for="pickup">Or choose a campus pickup point *</label>
                <select id="pickup" name="pickup" required onchange="handlePickupChange()">
                    <option value="">-- Select Pickup Point --</option>
                    <?php foreach ($locations as $loc): ?>
                        <option value="<?php echo htmlspecialchars($loc['name']); ?>"
                                data-lat="<?php echo $loc['latitude']; ?>"
                                data-lng="<?php echo $loc['longitude']; ?>">
                            <?php echo htmlspecialchars($loc['name']); ?>
                        </option>
                    <?php endforeach; ?>
                    <option value="__other__">📍 Other (use map)</option>
                </select>
            </div>

            <div id="pickupMapBlock" style="display:none;">
                <div class="form-group">
                    <label>Click on the map to set your pickup</label>
                    <div id="pickupMap" class="mini-map"></div>
                    <input type="hidden" id="pickup_lat" name="pickup_lat">
                    <input type="hidden" id="pickup_lng" name="pickup_lng">
                </div>
            </div>
        </div>

        <div class="card">
            <h2>🎯 Destination</h2>

            <div class="form-group">
                <label for="destinationSearch">Search destination</label>
                <div class="location-search">
                    <input type="text" id="destinationSearch" autocomplete="off" placeholder="Search an address, residence, building or place...">
                    <div id="destinationResults" class="location-results"></div>
                </div>
                <div id="destinationSearchStatus" class="search-status"></div>
                <label for="destination">Or choose a campus destination *</label>
                <select id="destination" name="destination" required onchange="handleDestinationChange()">
                    <option value="">-- Select Destination --</option>
                    <?php foreach ($locations as $loc): ?>
                        <option value="<?php echo htmlspecialchars($loc['name']); ?>"
                                data-lat="<?php echo $loc['latitude']; ?>"
                                data-lng="<?php echo $loc['longitude']; ?>">
                            <?php echo htmlspecialchars($loc['name']); ?>
                        </option>
                    <?php endforeach; ?>
                    <option value="__other__">📍 Other (use map)</option>
                </select>
            </div>

            <div id="destMapBlock" style="display:none;">
                <div class="form-group">
                    <label>Click on the map to set your destination</label>
                    <div id="destMap" class="mini-map"></div>
                    <input type="hidden" id="dest_lat" name="dest_lat">
                    <input type="hidden" id="dest_lng" name="dest_lng">
                </div>
            </div>
        </div>

        <div class="card" id="priceCard" style="display:none;">
            <h2>💰 Price Estimate <span class="rate-badge" id="rateBadge">Normal</span></h2>
            <div class="price-box">
                <div class="price-row"><span>Base rate</span><span id="baseRate">R20.00</span></div>
                <div class="price-row"><span>Distance charge</span><span id="distCharge">R0.00</span></div>
                <div class="price-row"><span>Distance</span><span id="distDisplay">0.0 km</span></div>
                <div class="price-row total"><span>Total</span><span id="totalPrice">R20.00</span></div>
            </div>
        </div>

        <div class="card">
            <h2>🚗 Nearby Drivers</h2>
            <p style="color:#6b7280;font-size:13.5px;margin-top:-10px;margin-bottom:15px;">
                <?php echo count($drivers); ?> driver<?php echo count($drivers) === 1 ? '' : 's'; ?> available nearby
            </p>

            <div id="driversMap" class="drivers-map"></div>

            <?php if (count($drivers) > 0): ?>
                <div class="driver-list">
                    <?php foreach ($drivers as $d): ?>
                        <div class="driver-item">
                            <div class="driver-avatar">
                                <?php if (!empty($d['profile_picture']) && file_exists(__DIR__ . '/' . $d['profile_picture'])): ?>
                                    <img src="<?php echo htmlspecialchars($d['profile_picture']); ?>" alt="">
                                <?php else: ?>
                                    <?php echo strtoupper(substr($d['DriverFname'],0,1) . substr($d['DriverLname'],0,1)); ?>
                                <?php endif; ?>
                            </div>
                            <div class="driver-info">
                                <h4><?php echo htmlspecialchars($d['DriverFname'] . ' ' . $d['DriverLname']); ?></h4>
                                <p><?php echo htmlspecialchars(trim(($d['vehicle_make'] ?? '') . ' ' . ($d['vehicle_model'] ?? ''))); ?>
                                    <?php if ($d['vehicle_registration']): ?> · <?php echo htmlspecialchars($d['vehicle_registration']); ?><?php endif; ?>
                                </p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p style="text-align:center;color:#6b7280;padding:20px;">No drivers available right now.</p>
            <?php endif; ?>
        </div>

        <input type="hidden" id="estimated_distance" name="estimated_distance">
        <input type="hidden" id="estimated_duration" name="estimated_duration">
        <input type="hidden" id="estimated_price" name="estimated_price">

        <button type="submit" class="btn-submit">✅ Confirm & Request Ride</button>
    </form>
</div>

<script>
const campusLocations = <?php echo json_encode($locations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;

function selectLocation(type, name, lat, lng) {
    const select = document.getElementById(type);
    const latId = type === 'pickup' ? 'pickup_lat' : 'dest_lat';
    const lngId = type === 'pickup' ? 'pickup_lng' : 'dest_lng';
    const searchId = type === 'pickup' ? 'pickupSearch' : 'destinationSearch';
    const resultsId = type === 'pickup' ? 'pickupResults' : 'destinationResults';
    const statusId = type === 'pickup' ? 'pickupSearchStatus' : 'destinationSearchStatus';

    let option = Array.from(select.options).find(o => o.value === name);
    if (!option) {
        option = document.createElement('option');
        option.value = name;
        option.textContent = name;
        option.dataset.lat = lat;
        option.dataset.lng = lng;
        select.appendChild(option);
    } else {
        option.dataset.lat = lat;
        option.dataset.lng = lng;
    }
    select.value = name;
    document.getElementById(latId).value = lat;
    document.getElementById(lngId).value = lng;
    document.getElementById(searchId).value = name;
    document.getElementById(resultsId).style.display = 'none';
    document.getElementById(resultsId).innerHTML = '';
    document.getElementById(statusId).textContent = 'Location selected.';
    if (type === 'pickup') handlePickupChange(); else handleDestinationChange();
    calculatePrice();
}

function searchLocation(type) {
    const searchId = type === 'pickup' ? 'pickupSearch' : 'destinationSearch';
    const resultsId = type === 'pickup' ? 'pickupResults' : 'destinationResults';
    const statusId = type === 'pickup' ? 'pickupSearchStatus' : 'destinationSearchStatus';
    const input = document.getElementById(searchId);
    const results = document.getElementById(resultsId);
    const status = document.getElementById(statusId);
    const query = input.value.trim();

    if (query.length < 2) {
        results.style.display = 'none';
        status.textContent = '';
        return;
    }

    const campusMatches = campusLocations.filter(loc => loc.name.toLowerCase().includes(query.toLowerCase())).slice(0, 5);
    results.innerHTML = '';
    campusMatches.forEach(loc => {
        const div = document.createElement('div');
        div.className = 'location-result';
        div.innerHTML = '<strong>' + escapeHtml(loc.name) + '</strong><span>Campus location</span>';
        div.onclick = () => selectLocation(type, loc.name, loc.latitude, loc.longitude);
        results.appendChild(div);
    });

    status.textContent = 'Searching addresses...';
    const aliceOnlySearch = <?php echo $aliceOnlySearch ? 'true' : 'false'; ?>;
    const params = new URLSearchParams({
        format: 'jsonv2',
        limit: '6',
        countrycodes: 'za',
        q: aliceOnlySearch ? (query + ', Alice, Eastern Cape, South Africa') : query
    });
    if (aliceOnlySearch) {
        params.set('bounded', '1');
        params.set('viewbox', '26.75,-32.70,26.95,-32.88');
        params.set('addressdetails', '1');
    }

    fetch('https://nominatim.openstreetmap.org/search?' + params.toString(), {
        headers: {'Accept':'application/json','Accept-Language':'en'}
    })
    .then(r => r.ok ? r.json() : [])
    .then(data => {
        data.forEach(item => {
            const name = item.display_name;
            const div = document.createElement('div');
            div.className = 'location-result';
            div.innerHTML = '<strong>' + escapeHtml(name.split(',').slice(0,2).join(',')) + '</strong><span>' + escapeHtml(name) + '</span>';
            div.onclick = () => selectLocation(type, name, parseFloat(item.lat), parseFloat(item.lon));
            results.appendChild(div);
        });
        results.style.display = results.children.length ? 'block' : 'none';
        status.textContent = results.children.length ? 'Select a location from the results.' : 'No matching locations found.';
    })
    .catch(() => {
        results.style.display = results.children.length ? 'block' : 'none';
        status.textContent = results.children.length ? 'Select a campus location.' : 'Address search is temporarily unavailable.';
    });
}

function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}

['pickup','destination'].forEach(type => {
    const id = type === 'pickup' ? 'pickupSearch' : 'destinationSearch';
    const resultsId = type === 'pickup' ? 'pickupResults' : 'destinationResults';
    let timer;
    document.getElementById(id).addEventListener('input', function() {
        clearTimeout(timer);
        timer = setTimeout(() => searchLocation(type), 450);
    });
    document.getElementById(id).addEventListener('focus', function() {
        if (this.value.trim().length >= 2) searchLocation(type);
    });
    document.addEventListener('click', function(e) {
        if (!e.target.closest('#' + id) && !e.target.closest('#' + resultsId)) {
            document.getElementById(resultsId).style.display = 'none';
        }
    });
});

function getRate() {
    const now = new Date();
    const day = now.getDay();
    const hour = now.getHours();
    const isWeekendNight = (day === 5 || day === 6) && (hour >= 17 || hour < 3);
    const isNight = hour >= 22 || hour < 5;
    if (isWeekendNight) return { base: 40, label: 'Peak', class: 'peak' };
    if (isNight) return { base: 30, label: 'Night', class: 'night' };
    return { base: 20, label: 'Normal', class: '' };
}

function getDistance(lat1, lng1, lat2, lng2) {
    const R = 6371;
    const toRad = deg => deg * Math.PI / 180;
    const dLat = toRad(lat2 - lat1);
    const dLng = toRad(lng2 - lng1);
    const a = Math.sin(dLat/2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng/2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

let pickupMap, destMap, driversMap, pickupMarker, destMarker;

function handlePickupChange() {
    const sel = document.getElementById('pickup');
    const block = document.getElementById('pickupMapBlock');

    if (sel.value === '__other__') {
        block.style.display = 'block';
        setTimeout(() => {
            if (!pickupMap) {
                pickupMap = L.map('pickupMap').setView([-32.7833, 26.8448], 14);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(pickupMap);
                pickupMap.on('click', e => {
                    if (pickupMarker) pickupMap.removeLayer(pickupMarker);
                    pickupMarker = L.marker(e.latlng).addTo(pickupMap);
                    document.getElementById('pickup_lat').value = e.latlng.lat;
                    document.getElementById('pickup_lng').value = e.latlng.lng;
                    calculatePrice();
                });
            }
            pickupMap.invalidateSize();
        }, 100);
    } else {
        block.style.display = 'none';
        const opt = sel.options[sel.selectedIndex];
        document.getElementById('pickup_lat').value = opt?.dataset.lat || '';
        document.getElementById('pickup_lng').value = opt?.dataset.lng || '';
        document.getElementById('pickupSearch').value = sel.value || '';
    }
    calculatePrice();
}

function handleDestinationChange() {
    const sel = document.getElementById('destination');
    const block = document.getElementById('destMapBlock');

    if (sel.value === '__other__') {
        block.style.display = 'block';
        setTimeout(() => {
            if (!destMap) {
                destMap = L.map('destMap').setView([-32.7833, 26.8448], 14);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(destMap);
                destMap.on('click', e => {
                    if (destMarker) destMap.removeLayer(destMarker);
                    destMarker = L.marker(e.latlng).addTo(destMap);
                    document.getElementById('dest_lat').value = e.latlng.lat;
                    document.getElementById('dest_lng').value = e.latlng.lng;
                    calculatePrice();
                });
            }
            destMap.invalidateSize();
        }, 100);
    } else {
        block.style.display = 'none';
    }
    calculatePrice();
}

function getCoords(selectId, latId, lngId) {
    const sel = document.getElementById(selectId);
    if (!sel.value) return null;
    if (sel.value === '__other__') {
        const lat = parseFloat(document.getElementById(latId).value);
        const lng = parseFloat(document.getElementById(lngId).value);
        if (isNaN(lat) || isNaN(lng)) return null;
        return { lat, lng };
    }
    const opt = sel.options[sel.selectedIndex];
    const lat = parseFloat(opt.dataset.lat);
    const lng = parseFloat(opt.dataset.lng);
    if (isNaN(lat) || isNaN(lng)) return null;
    return { lat, lng };
}

function calculatePrice() {
    const p = getCoords('pickup', 'pickup_lat', 'pickup_lng');
    const d = getCoords('destination', 'dest_lat', 'dest_lng');
    if (!p || !d) {
        document.getElementById('priceCard').style.display = 'none';
        return;
    }
    const distKm = getDistance(p.lat, p.lng, d.lat, d.lng);
    const rate = getRate();
    const distanceCharge = distKm * 7.50;
    const total = rate.base + distanceCharge;
    const duration = Math.max(2, Math.round(distKm * 2));

    document.getElementById('priceCard').style.display = 'block';
    document.getElementById('baseRate').textContent = 'R' + rate.base.toFixed(2);
    document.getElementById('distCharge').textContent = 'R' + distanceCharge.toFixed(2);
    document.getElementById('distDisplay').textContent = distKm.toFixed(2) + ' km';
    document.getElementById('totalPrice').textContent = 'R' + total.toFixed(2);

    const badge = document.getElementById('rateBadge');
    badge.textContent = rate.label;
    badge.className = 'rate-badge ' + rate.class;

    document.getElementById('estimated_distance').value = distKm.toFixed(2);
    document.getElementById('estimated_duration').value = duration;
    document.getElementById('estimated_price').value = total.toFixed(2);
}

document.addEventListener('DOMContentLoaded', function() {
    driversMap = L.map('driversMap').setView([-32.7833, 26.8448], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(driversMap);
    const driverMarkers = new Map();
    const carIcon = L.divIcon({
        html: '<div style="width:38px;height:38px;border-radius:50%;background:#0c2d4d;border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,.35);display:flex;align-items:center;justify-content:center;font-size:21px;">🚗</div>',
        className: 'campuscab-car-marker',
        iconSize: [38, 38],
        iconAnchor: [19, 19],
        popupAnchor: [0, -19]
    });

    function refreshLiveDrivers() {
        fetch('get_online_drivers.php', {credentials:'same-origin', cache:'no-store'})
            .then(r => r.json())
            .then(data => {
                if (!data.success) return;
                const seen = new Set();
                data.drivers.forEach(d => {
                    if (d.latitude === null || d.longitude === null) return;
                    seen.add(String(d.DriverID));
                    let m = driverMarkers.get(String(d.DriverID));
                    if (!m) {
                        m=L.marker([d.latitude,d.longitude], {icon: carIcon}).addTo(driversMap);
                        driverMarkers.set(String(d.DriverID),m);
                    } else m.setLatLng([d.latitude,d.longitude]);
                    m.bindPopup('<strong>🚗 '+d.DriverFname+' '+d.DriverLname+'</strong><br>'+(d.vehicle_make||'')+' '+(d.vehicle_model||'')+'<br><span style="color:#0f6e56">● Online</span>');
                });
                driverMarkers.forEach((m,id)=>{ if(!seen.has(id)){ driversMap.removeLayer(m); driverMarkers.delete(id); }});
            }).catch(()=>{});
    }
    refreshLiveDrivers();
    setInterval(refreshLiveDrivers,5000);

    document.getElementById('rideForm').addEventListener('submit', function(e) {
        const p = getCoords('pickup', 'pickup_lat', 'pickup_lng');
        const d = getCoords('destination', 'dest_lat', 'dest_lng');
        if (!p || !d) {
            e.preventDefault();
            alert('Please select both pickup and destination.');
        }
    });
});
</script>

<?php include 'footer.php'; ?>