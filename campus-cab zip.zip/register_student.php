<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db_connect.php';

$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $student_number = trim($_POST['student_number']);
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Array to collect errors
    $errors = [];
    
    // 1. VALIDATE REQUIRED FIELDS
    if (empty($student_number) || empty($first_name) || empty($last_name) || 
        empty($email) || empty($phone) || empty($password)) {
        $errors[] = "All fields are required.";
    }
    
    // 2. STUDENT NUMBER VALIDATION (9 digits)
    if (!preg_match('/^[0-9]{9}$/', $student_number)) {
        $errors[] = "Student Number must be exactly 9 digits (e.g., 202412345).";
    }
    
    // 3. NAME VALIDATION (Letters only)
    if (!preg_match('/^[a-zA-Z\s\-]{2,}$/', $first_name)) {
        $errors[] = "First name must contain only letters (minimum 2 characters).";
    }
    
    // 4. SURNAME VALIDATION (Letters only)
    if (!preg_match('/^[a-zA-Z\s\-]{2,}$/', $last_name)) {
        $errors[] = "Last name must contain only letters (minimum 2 characters).";
    }
    // 5. EMAIL VALIDATION (Must be @ufh.ac.za)
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    } elseif (!str_ends_with($email, '@ufh.ac.za')) {
        $errors[] = "Email must be a valid student email ending with @ufh.ac.za";
    }
    // 6. CELL NUMBER VALIDATION (10 digits, starts with 0)
    if (!preg_match('/^0[0-9]{9}$/', $phone)) {
        $errors[] = "Cell number must be exactly 10 digits starting with 0 (e.g., 0712345678).";
    }
    
    // 7. STRONG PASSWORD VALIDATION
    $password_errors = [];
    
    if (strlen($password) < 8) {
        $password_errors[] = "at least 8 characters long";
    }
    if (!preg_match('/[A-Z]/', $password)) {
        $password_errors[] = "at least 1 uppercase letter";
    }
    if (!preg_match('/[a-z]/', $password)) {
        $password_errors[] = "at least 1 lowercase letter";
    }
    if (!preg_match('/[0-9]/', $password)) {
        $password_errors[] = "at least 1 number";
    }
    if (!preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
        $password_errors[] = "at least 1 special character (!@#$%^&*)";
    }
    
    if (!empty($password_errors)) {
        $errors[] = "Password must contain: " . implode(", ", $password_errors) . ".";
    } elseif ($password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    }
    
    // 8. CHECK IF STUDENT ALREADY EXISTS
    if (empty($errors)) {
        // Check email
        $check_email_sql = "SELECT studentID FROM student WHERE studentEmail = ?";
        $check_email_stmt = $conn->prepare($check_email_sql);
        $check_email_stmt->bind_param("s", $email);
        $check_email_stmt->execute();
        $check_email_stmt->store_result();
        
        if ($check_email_stmt->num_rows > 0) {
            $errors[] = "This email is already registered. Please use a different email or login.";
        }
        $check_email_stmt->close();
        
        // Check phone
        $check_phone_sql = "SELECT studentID FROM student WHERE studentPhoneNo = ?";
        $check_phone_stmt = $conn->prepare($check_phone_sql);
        $check_phone_stmt->bind_param("s", $phone);
        $check_phone_stmt->execute();
        $check_phone_stmt->store_result();
        
        if ($check_phone_stmt->num_rows > 0) {
            $errors[] = "This cell number is already registered.";
        }
        $check_phone_stmt->close();
    }
    
    // 9. IF ERRORS, DISPLAY THEM
    if (!empty($errors)) {
        $error = implode("<br>", $errors);
    } else {
        // 10. HASH PASSWORD AND INSERT INTO DATABASE
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Keep registration compatible with the core student schema.
        // Email-verification fields are optional in some existing Campus Cab databases.
        $insert_sql = "INSERT INTO student (
            studentFname,
            studentLname,
            studentEmail,
            studentPhoneNo,
            password
        ) VALUES (?, ?, ?, ?, ?)";

        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param(
            "sssss",
            $first_name,
            $last_name,
            $email,
            $phone,
            $hashed_password
        );

        if ($insert_stmt->execute()) {
            $success = "Registration successful! You can now log in.";
        } else {
            $error = "Registration failed: " . $conn->error;
        }
        $insert_stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration | Campus Cab</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .registration-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        .registration-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .registration-header h1 {
            color: #2c3e50;
            margin-bottom: 5px;
        }
        .registration-header p {
            color: #6c757d;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }
        .form-group input:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 5px rgba(0,123,255,0.3);
        }
        .form-group small {
            display: block;
            color: #6c757d;
            font-size: 12px;
            margin-top: 5px;
        }
        .form-row {
            display: flex;
            gap: 15px;
        }
        .form-row .form-group {
            flex: 1;
        }
        .error-message {
            font-size: 12px;
            margin-top: 5px;
            display: block;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .register-button {
            width: 100%;
            padding: 12px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.3s ease;
        }
        .register-button:hover {
            background: #0056b3;
        }
        .login-link {
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
        }
        .login-link a {
            color: #007bff;
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        .password-strength {
            margin: 10px 0 20px 0;
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
        }
        .strength-bar {
            height: 8px;
            background: #e9ecef;
            border-radius: 4px;
            overflow: hidden;
            margin-bottom: 8px;
        }
        .strength-fill {
            height: 100%;
            width: 0%;
            border-radius: 4px;
            transition: width 0.3s ease;
        }
        .strength-fill.weak { width: 25%; background: #dc3545; }
        .strength-fill.medium { width: 50%; background: #ffc107; }
        .strength-fill.good { width: 75%; background: #17a2b8; }
        .strength-fill.strong { width: 100%; background: #28a745; }
        .strength-text {
            font-size: 14px;
            margin: 0 0 10px 0;
            font-weight: bold;
        }
        .strength-text.weak { color: #dc3545; }
        .strength-text.medium { color: #ffc107; }
        .strength-text.good { color: #17a2b8; }
        .strength-text.strong { color: #28a745; }
        .requirements {
            list-style: none;
            padding: 0;
            margin: 5px 0 0 0;
            font-size: 13px;
        }
        .requirements li {
            padding: 3px 0;
            color: #dc3545;
            transition: all 0.3s ease;
        }
        .requirements li.met {
            color: #28a745;
            font-weight: bold;
        }
        .btn-primary {
            display: inline-block;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .btn-primary:hover {
            background: #0056b3;
        }
        h2 {
            margin-top: 30px;
            margin-bottom: 15px;
            color: #2c3e50;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }
        @media (max-width: 600px) {
            .form-row {
                flex-direction: column;
                gap: 0;
            }
            .registration-container {
                margin: 20px;
                padding: 15px;
            }
        }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="registration-container">

    <div class="registration-header">
        <h1>🎓 Student Registration</h1>
        <p>Create your account to start using Campus Cab services.</p>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger">
            ❌ <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success">
            ✅ <?php echo $success; ?>
            <br><br>
            <a href="login.php" class="btn-primary">🔑 Go to Login</a>
        </div>
    <?php endif; ?>

    <?php if (!$success): ?>
    <form action="" method="POST" id="registrationForm">

        <!-- STUDENT INFORMATION -->
        <h2>👤 Student Information</h2>

        <div class="form-group">
            <label for="student_number">Student Number *</label>
            <input 
                type="text" 
                id="student_number"
                name="student_number"
                placeholder="e.g., 202412345"
                maxlength="9"
                value="<?php echo isset($student_number) ? htmlspecialchars($student_number) : ''; ?>"
                required
            >
            <small>Must be exactly 9 digits</small>
            <span id="student_error" class="error-message"></span>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="first_name">First Name *</label>
                <input 
                    type="text"
                    id="first_name"
                    name="first_name"
                    placeholder="Enter your first name"
                    value="<?php echo isset($first_name) ? htmlspecialchars($first_name) : ''; ?>"
                    required
                >
                <span id="name_error" class="error-message"></span>
            </div>

            <div class="form-group">
                <label for="last_name">Last Name *</label>
                <input 
                    type="text"
                    id="last_name"
                    name="last_name"
                    placeholder="Enter your last name"
                    value="<?php echo isset($last_name) ? htmlspecialchars($last_name) : ''; ?>"
                    required
                >
                <span id="surname_error" class="error-message"></span>
            </div>
        </div>

        <div class="form-group">
            <label for="email">Email Address *</label>
            <input 
                type="email"
                id="email"
                name="email"
                placeholder="student@ufh.ac.za"
                value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>"
                required
            >
            <small>Must be a valid @ufh.ac.za email address</small>
            <span id="email_error" class="error-message"></span>
        </div>

        <div class="form-group">
            <label for="phone">Cellphone Number *</label>
            <input 
                type="tel"
                id="phone"
                name="phone"
                placeholder="e.g., 0712345678"
                maxlength="10"
                value="<?php echo isset($phone) ? htmlspecialchars($phone) : ''; ?>"
                required
            >
            <small>10 digits starting with 0 (e.g., 0712345678)</small>
            <span id="cell_error" class="error-message"></span>
        </div>

        <!-- 🔐 PASSWORD SECTION -->
        <h2>🔐 Create Account Password</h2>

        <div class="form-row">
            <div class="form-group">
                <label for="password">Create Password *</label>
                <input 
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Min 8 characters"
                    minlength="8"
                    required
                >
                <small>Password must contain: 8+ chars, uppercase, lowercase, number & special character</small>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm Password *</label>
                <input 
                    type="password"
                    id="confirm_password"
                    name="confirm_password"
                    placeholder="Re-enter your password"
                    required
                >
                <span id="password_match_message"></span>
            </div>
        </div>

        <!-- Password Strength Indicator -->
        <div class="password-strength">
            <div class="strength-bar">
                <div class="strength-fill" id="strengthFill"></div>
            </div>
            <p class="strength-text" id="strengthText">Enter a strong password</p>
            <ul class="requirements" id="requirements">
                <li id="reqLength">❌ At least 8 characters</li>
                <li id="reqUpper">❌ At least 1 uppercase letter</li>
                <li id="reqLower">❌ At least 1 lowercase letter</li>
                <li id="reqNumber">❌ At least 1 number</li>
                <li id="reqSpecial">❌ At least 1 special character (!@#$%^&*)</li>
            </ul>
        </div>

        <!-- SUBMIT -->
        <button type="submit" class="register-button">✅ Register as Student</button>

        <p class="login-link">
            Already have an account? <a href="login.php">Login here</a>
        </p>
        <p class="login-link">
            <a href="register.php">← Change Role</a>
        </p>

    </form>
    <?php endif; ?>

</div>

<?php include 'footer.php'; ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Get form elements
        const studentInput = document.getElementById('student_number');
        const nameInput = document.getElementById('first_name');
        const surnameInput = document.getElementById('last_name');
        const emailInput = document.getElementById('email');
        const cellInput = document.getElementById('phone');
        const passwordInput = document.getElementById('password');
        const confirmInput = document.getElementById('confirm_password');

        // Error message elements
        const studentError = document.getElementById('student_error');
        const nameError = document.getElementById('name_error');
        const surnameError = document.getElementById('surname_error');
        const emailError = document.getElementById('email_error');
        const cellError = document.getElementById('cell_error');

        // Password strength elements
        const strengthFill = document.getElementById('strengthFill');
        const strengthText = document.getElementById('strengthText');
        const reqLength = document.getElementById('reqLength');
        const reqUpper = document.getElementById('reqUpper');
        const reqLower = document.getElementById('reqLower');
        const reqNumber = document.getElementById('reqNumber');
        const reqSpecial = document.getElementById('reqSpecial');

        // 1. STUDENT NUMBER VALIDATION (9 digits only)
        if (studentInput) {
            studentInput.addEventListener('input', function() {
                this.value = this.value.replace(/\D/g, '');
                
                if (this.value.length > 0 && this.value.length !== 9) {
                    studentError.textContent = `❌ Student number must be exactly 9 digits (currently ${this.value.length})`;
                    studentError.style.color = 'red';
                    this.style.borderColor = 'red';
                } else if (this.value.length === 9) {
                    studentError.textContent = '✅ Valid student number';
                    studentError.style.color = 'green';
                    this.style.borderColor = 'green';
                } else {
                    studentError.textContent = '';
                    this.style.borderColor = '';
                }
            });
        }

        // 2. NAME VALIDATION (Letters only)
        if (nameInput) {
            nameInput.addEventListener('input', function() {
                const validName = this.value.replace(/[^a-zA-Z\s\-']/g, '');
                if (this.value !== validName) {
                    this.value = validName;
                    nameError.textContent = '❌ Only letters, spaces, hyphens, and apostrophes allowed';
                    nameError.style.color = 'red';
                    this.style.borderColor = 'red';
                } else if (this.value.length > 0 && this.value.length < 2) {
                    nameError.textContent = '❌ Name must be at least 2 characters';
                    nameError.style.color = 'red';
                    this.style.borderColor = 'red';
                } else if (this.value.length > 0) {
                    nameError.textContent = '✅ Valid name';
                    nameError.style.color = 'green';
                    this.style.borderColor = 'green';
                } else {
                    nameError.textContent = '';
                    this.style.borderColor = '';
                }
            });
        }

        // 3. SURNAME VALIDATION (Letters only)
        if (surnameInput) {
            surnameInput.addEventListener('input', function() {
                const validSurname = this.value.replace(/[^a-zA-Z\s\-']/g, '');
                if (this.value !== validSurname) {
                    this.value = validSurname;
                    surnameError.textContent = '❌ Only letters, spaces, hyphens, and apostrophes allowed';
                    surnameError.style.color = 'red';
                    this.style.borderColor = 'red';
                } else if (this.value.length > 0 && this.value.length < 2) {
                    surnameError.textContent = '❌ Surname must be at least 2 characters';
                    surnameError.style.color = 'red';
                    this.style.borderColor = 'red';
                } else if (this.value.length > 0) {
                    surnameError.textContent = '✅ Valid surname';
                    surnameError.style.color = 'green';
                    this.style.borderColor = 'green';
                } else {
                    surnameError.textContent = '';
                    this.style.borderColor = '';
                }
            });
        }

        // 4. EMAIL VALIDATION (@ufh.ac.za)
        if (emailInput) {
            emailInput.addEventListener('input', function() {
                const email = this.value;
                const emailPattern = /^[a-zA-Z0-9._%+-]+@ufh\.ac\.za$/;
                
                if (email.length > 0) {
                    if (emailPattern.test(email)) {
                        emailError.textContent = '✅ Valid student email';
                        emailError.style.color = 'green';
                        this.style.borderColor = 'green';
                    } else {
                        emailError.textContent = '❌ Must be a valid @ufh.ac.za email';
                        emailError.style.color = 'red';
                        this.style.borderColor = 'red';
                    }
                } else {
                    emailError.textContent = '';
                    this.style.borderColor = '';
                }
            });
        }
        // 5. CELL NUMBER VALIDATION (10 digits only)
        if (cellInput) {
            cellInput.addEventListener('input', function() {
                this.value = this.value.replace(/\D/g, '');
                
                if (this.value.length > 10) {
                    this.value = this.value.slice(0, 10);
                }
                
                if (this.value.length > 0 && this.value.length < 10) {
                    cellError.textContent = `❌ Cell number must be 10 digits (currently ${this.value.length})`;
                    cellError.style.color = 'red';
                    this.style.borderColor = 'red';
                } else if (this.value.length === 10) {
                    if (this.value.startsWith('0')) {
                        cellError.textContent = '✅ Valid cell number';
                        cellError.style.color = 'green';
                        this.style.borderColor = 'green';
                    } else {
                        cellError.textContent = '❌ Cell number must start with 0';
                        cellError.style.color = 'red';
                        this.style.borderColor = 'red';
                    }
                } else {
                    cellError.textContent = '';
                    this.style.borderColor = '';
                }
            });
        }

        // 6. PASSWORD STRENGTH CHECKER
        if (passwordInput && strengthFill && strengthText) {
            passwordInput.addEventListener('input', function() {
                const pwd = this.value;
                let metCount = 0;
                
                const hasLength = pwd.length >= 8;
                const hasUpper = /[A-Z]/.test(pwd);
                const hasLower = /[a-z]/.test(pwd);
                const hasNumber = /[0-9]/.test(pwd);
                const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(pwd);
                
                updateRequirement(reqLength, hasLength, 'At least 8 characters');
                updateRequirement(reqUpper, hasUpper, 'At least 1 uppercase letter');
                updateRequirement(reqLower, hasLower, 'At least 1 lowercase letter');
                updateRequirement(reqNumber, hasNumber, 'At least 1 number');
                updateRequirement(reqSpecial, hasSpecial, 'At least 1 special character');
                
                metCount = [hasLength, hasUpper, hasLower, hasNumber, hasSpecial].filter(Boolean).length;
                let score = (metCount / 5) * 100;
                
                strengthFill.style.width = score + '%';
                strengthFill.className = 'strength-fill';
                
                let level, colorClass;
                if (score === 0) {
                    level = 'Enter a strong password';
                    colorClass = '';
                } else if (score < 40) {
                    level = 'Weak - add more characters and variety';
                    colorClass = 'weak';
                } else if (score < 60) {
                    level = 'Medium - add more variety';
                    colorClass = 'medium';
                } else if (score < 80) {
                    level = 'Good - almost there!';
                    colorClass = 'good';
                } else {
                    level = '✅ Strong password!';
                    colorClass = 'strong';
                }
                
                strengthText.textContent = level;
                strengthText.className = 'strength-text ' + colorClass;
                strengthFill.classList.add(colorClass);
            });
        }

        function updateRequirement(element, met, text) {
            if (element) {
                if (met) {
                    element.textContent = '✅ ' + text;
                    element.className = 'met';
                } else {
                    element.textContent = '❌ ' + text;
                    element.className = '';
                }
            }
        }

        // 7. PASSWORD MATCH CHECKER (Real-time)
        const matchMessage = document.getElementById('password_match_message');

        if (confirmInput && passwordInput && matchMessage) {
            confirmInput.addEventListener('input', function() {
                if (this.value.length > 0) {
                    if (this.value === passwordInput.value) {
                        matchMessage.innerHTML = '✅ Passwords match';
                        matchMessage.style.color = 'green';
                    } else {
                        matchMessage.innerHTML = '❌ Passwords do not match';
                        matchMessage.style.color = 'red';
                    }
                } else {
                    matchMessage.innerHTML = '';
                }
            });
        }
    });
</script>

</body>
</html>