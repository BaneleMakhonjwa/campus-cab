<?php
session_start();error_reporting(E_ALL);ini_set('display_errors',1);require_once __DIR__.'/db_connect.php';
$error='';$success='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $name=trim($_POST['name']??'');$surname=trim($_POST['surname']??'');$email=trim($_POST['email']??'');$cell=trim($_POST['cell_number']??'');$licence=trim($_POST['id_number']??'');$make=trim($_POST['vehicle_make']??'');$model=trim($_POST['vehicle_model']??'');$registration=trim($_POST['vehicle_registration']??'');$color=trim($_POST['vehicle_color']??'');$capacity=(int)($_POST['vehicle_capacity']??0);$password=$_POST['password']??'';$confirm=$_POST['confirm_password']??'';$errors=[];
 if($name===''||$surname===''||$email===''||$cell===''||$licence===''||$make===''||$model===''||$registration===''||$color===''||$capacity<=0||$password==='')$errors[]='All required fields must be filled.';
 if($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL))$errors[]='Please enter a valid email address.';if($cell!==''&&!preg_match('/^0[0-9]{9}$/',$cell))$errors[]='Cell number must be 10 digits starting with 0.';if($capacity<1||$capacity>20)$errors[]='Vehicle capacity must be between 1 and 20.';if($password!==$confirm)$errors[]='Passwords do not match.';
 if(strlen($password)<8||!preg_match('/[A-Z]/',$password)||!preg_match('/[a-z]/',$password)||!preg_match('/[0-9]/',$password)||!preg_match('/[!@#$%^&*(),.?":{}|<>]/',$password))$errors[]='Password must be at least 8 characters and include upper/lowercase, a number and a special character.';
 if(!$errors){$q=$conn->prepare('SELECT DriverID FROM driver WHERE DriverEmail=? OR DriverPhoneNo=? LIMIT 1');$q->bind_param('ss',$email,$cell);$q->execute();if($q->get_result()->fetch_assoc())$errors[]='A driver with this email or phone already exists.';$q->close();}
 $photo=null;if(!$errors&&isset($_FILES['driver_photo'])&&$_FILES['driver_photo']['error']===UPLOAD_ERR_OK){$dir=__DIR__.'/uploads/drivers/';if(!is_dir($dir))mkdir($dir,0755,true);$ext=strtolower(pathinfo($_FILES['driver_photo']['name'],PATHINFO_EXTENSION));if(!in_array($ext,['jpg','jpeg','png','webp'],true))$errors[]='Driver photo must be JPG, PNG or WEBP.';else{$nameFile='driver_'.time().'_'.random_int(1000,9999).'.'.$ext;if(move_uploaded_file($_FILES['driver_photo']['tmp_name'],$dir.$nameFile))$photo='uploads/drivers/'.$nameFile;}}
 if(!$errors){$hash=password_hash($password,PASSWORD_DEFAULT);$st=$conn->prepare("INSERT INTO driver (DriverFname,DriverLname,DriverEmail,DriverPhoneNo,driverAccount_Status,licence_number,vehicle_make,vehicle_model,availability_status,password,vehicle_registration,profile_picture) VALUES (?,?,?,?, 'Active',?,?,?,'Unavailable',?,?,?)");$st->bind_param('ssssssssss',$name,$surname,$email,$cell,$licence,$make,$model,$hash,$registration,$photo);if($st->execute()){$driverID=$st->insert_id;$st->close();$v=$conn->prepare('INSERT INTO vehicle (DriverID,registration_no,make,model,colour,capacity) VALUES (?,?,?,?,?,?)');$v->bind_param('issssi',$driverID,$registration,$make,$model,$color,$capacity);$v->execute();$v->close();$success='Driver registration successful. You can now log in.';}else{$error='Registration failed: '.$conn->error;$st->close();}}
 if($errors)$error=implode('<br>',$errors);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Registration | Campus Cab</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .registration-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        .registration-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .registration-header h1 {
            color: #2c3e50;
            margin-bottom: 5px;
        }
        .registration-header p {
            color: #6c757d;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }
        .form-group input:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 5px rgba(0,123,255,0.3);
        }
        .form-group textarea {
            resize: vertical;
        }
        .form-group small {
            display: block;
            color: #6c757d;
            font-size: 12px;
            margin-top: 5px;
        }
        .form-row {
            display: flex;
            gap: 15px;
        }
        .form-row .form-group {
            flex: 1;
        }
        .password-row {
            display: flex;
            gap: 15px;
            margin-bottom: 5px;
        }
        .password-row .form-group {
            flex: 1;
            margin-bottom: 0;
        }
        .error-message {
            font-size: 12px;
            margin-top: 5px;
            display: block;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .register-button {
            width: 100%;
            padding: 12px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.3s ease;
        }
        .register-button:hover {
            background: #0056b3;
        }
        .login-link {
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
        }
        .login-link a {
            color: #007bff;
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        .password-strength {
            margin: 10px 0 20px 0;
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
        }
        .strength-bar {
            height: 8px;
            background: #e9ecef;
            border-radius: 4px;
            overflow: hidden;
            margin-bottom: 8px;
        }
        .strength-fill {
            height: 100%;
            width: 0%;
            border-radius: 4px;
            transition: width 0.3s ease;
        }
        .strength-fill.weak { width: 25%; background: #dc3545; }
        .strength-fill.medium { width: 50%; background: #ffc107; }
        .strength-fill.good { width: 75%; background: #17a2b8; }
        .strength-fill.strong { width: 100%; background: #28a745; }
        .strength-text {
            font-size: 14px;
            margin: 0 0 10px 0;
            font-weight: bold;
        }
        .strength-text.weak { color: #dc3545; }
        .strength-text.medium { color: #ffc107; }
        .strength-text.good { color: #17a2b8; }
        .strength-text.strong { color: #28a745; }
        .requirements {
            list-style: none;
            padding: 0;
            margin: 5px 0 0 0;
            font-size: 13px;
        }
        .requirements li {
            padding: 3px 0;
            color: #dc3545;
            transition: all 0.3s ease;
        }
        .requirements li.met {
            color: #28a745;
            font-weight: bold;
        }
        .btn-primary {
            display: inline-block;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .btn-primary:hover {
            background: #0056b3;
        }
        h2 {
            margin-top: 30px;
            margin-bottom: 15px;
            color: #2c3e50;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }
        .verification-options {
            display: flex;
            gap: 20px;
        }
        @media (max-width: 600px) {
            .form-row, .password-row {
                flex-direction: column;
                gap: 0;
            }
            .password-row .form-group {
                margin-bottom: 10px;
            }
            .registration-container {
                margin: 20px;
                padding: 15px;
            }
        }
    </style>
</head>

<body>

<?php include 'header.php'; ?>

<div class="registration-container">

    <div class="registration-header">
        <h1>🚗 Driver Registration</h1>
        <p>Join our team and start earning with Campus Cab.</p>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger">
            ❌ <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success">
            ✅ <?php echo $success; ?>
            <br><br>
            <a href="login.php" class="btn-primary">🔑 Go to Login</a>
        </div>
    <?php endif; ?>

    <?php if (!$success): ?>
    <form action="" method="POST" enctype="multipart/form-data" id="registrationForm">

        <!-- DRIVER INFORMATION -->
        <h2>👤 Driver Information</h2>

        <div class="form-group">
            <label for="id_number">ID Number *</label>
            <input 
                type="text" 
                id="id_number"
                name="id_number"
                placeholder="e.g. 9001011234089"
                maxlength="13"
                value="<?php echo isset($id_number) ? htmlspecialchars($id_number) : ''; ?>"
                required
            >
            <small>13 digits (e.g. 9001011234089)</small>
            <span id="id_error" class="error-message"></span>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="name">Name *</label>
                <input 
                    type="text"
                    id="name"
                    name="name"
                    placeholder="Enter your name"
                    value="<?php echo isset($name) ? htmlspecialchars($name) : ''; ?>"
                    required
                >
                <span id="name_error" class="error-message"></span>
            </div>

            <div class="form-group">
                <label for="surname">Surname *</label>
                <input 
                    type="text"
                    id="surname"
                    name="surname"
                    placeholder="Enter your surname"
                    value="<?php echo isset($surname) ? htmlspecialchars($surname) : ''; ?>"
                    required
                >
                <span id="surname_error" class="error-message"></span>
            </div>
        </div>

        <div class="form-group">
            <label for="gender">Gender *</label>
            <select id="gender" name="gender" required>
                <option value="">Select gender</option>
                <option value="Male" <?php echo (isset($gender) && $gender == 'Male') ? 'selected' : ''; ?>>Male</option>
                <option value="Female" <?php echo (isset($gender) && $gender == 'Female') ? 'selected' : ''; ?>>Female</option>
                <option value="Other" <?php echo (isset($gender) && $gender == 'Other') ? 'selected' : ''; ?>>Other</option>
            </select>
        </div>

        <div class="form-group">
            <label for="email">Email Address *</label>
            <input 
                type="email"
                id="email"
                name="email"
                placeholder="driver@gmail.com"
                value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>"
                required
            >
            <small>Must be a valid <strong>@gmail.com</strong> address</small>
            <span id="email_error" class="error-message"></span>
        </div>

        <div class="form-group">
            <label for="cell_number">Cellphone Number *</label>
            <input 
                type="tel"
                id="cell_number"
                name="cell_number"
                placeholder="e.g. 0712345678"
                maxlength="10"
                value="<?php echo isset($cell_number) ? htmlspecialchars($cell_number) : ''; ?>"
                required
            >
            <small>10 digits (e.g. 0712345678)</small>
            <span id="cell_error" class="error-message"></span>
        </div>

        <!-- ADDRESS SECTION -->
        <h2>📍 Residence Address</h2>

        <div class="form-group">
            <label for="street_address">Street Address *</label>
            <input 
                type="text"
                id="street_address"
                name="street_address"
                placeholder="e.g. 123 Nelson Mandela Drive"
                value="<?php echo isset($street_address) ? htmlspecialchars($street_address) : ''; ?>"
                required
            >
            <small>House number and street name</small>
        </div>

        <div class="form-group">
            <label for="suburb">Suburb / Area *</label>
            <input 
                type="text"
                id="suburb"
                name="suburb"
                placeholder="e.g. Sunnyside"
                value="<?php echo isset($suburb) ? htmlspecialchars($suburb) : ''; ?>"
                required
            >
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="city">City / Town *</label>
                <input 
                    type="text"
                    id="city"
                    name="city"
                    placeholder="e.g. Alice Town"
                    value="<?php echo isset($city) ? htmlspecialchars($city) : ''; ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="province">Province *</label>
                <select id="province" name="province" required>
                    <option value="">Select province</option>
                    <option value="Eastern Cape" <?php echo (isset($province) && $province == 'Eastern Cape') ? 'selected' : ''; ?>>Eastern Cape</option>
                    <option value="Free State" <?php echo (isset($province) && $province == 'Free State') ? 'selected' : ''; ?>>Free State</option>
                    <option value="Gauteng" <?php echo (isset($province) && $province == 'Gauteng') ? 'selected' : ''; ?>>Gauteng</option>
                    <option value="KwaZulu-Natal" <?php echo (isset($province) && $province == 'KwaZulu-Natal') ? 'selected' : ''; ?>>KwaZulu-Natal</option>
                    <option value="Limpopo" <?php echo (isset($province) && $province == 'Limpopo') ? 'selected' : ''; ?>>Limpopo</option>
                    <option value="Mpumalanga" <?php echo (isset($province) && $province == 'Mpumalanga') ? 'selected' : ''; ?>>Mpumalanga</option>
                    <option value="North West" <?php echo (isset($province) && $province == 'North West') ? 'selected' : ''; ?>>North West</option>
                    <option value="Northern Cape" <?php echo (isset($province) && $province == 'Northern Cape') ? 'selected' : ''; ?>>Northern Cape</option>
                    <option value="Western Cape" <?php echo (isset($province) && $province == 'Western Cape') ? 'selected' : ''; ?>>Western Cape</option>
                </select>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="postal_code">Postal Code *</label>
                <input 
                    type="text"
                    id="postal_code"
                    name="postal_code"
                    placeholder="e.g. 5200"
                    maxlength="4"
                    value="<?php echo isset($postal_code) ? htmlspecialchars($postal_code) : ''; ?>"
                    required
                >
                <small>4-digit postal code</small>
            </div>

            <div class="form-group">
                <label for="complex_name">Complex / Building Name</label>
                <input 
                    type="text"
                    id="complex_name"
                    name="complex_name"
                    placeholder="e.g. Green Acres"
                    value="<?php echo isset($complex_name) ? htmlspecialchars($complex_name) : ''; ?>"
                >
                <small>Optional</small>
            </div>
        </div>

        <!-- 🔐 PASSWORD SECTION -->
        <h2>🔐 Create Account Password</h2>

        <!-- ✅ Password row - closer together -->
        <div class="password-row">
            <div class="form-group">
                <label for="password">Create Password *</label>
                <input 
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Min 8 characters"
                    minlength="8"
                    required
                >
                <small>8+ chars, uppercase, lowercase, number & special character</small>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm Password *</label>
                <input 
                    type="password"
                    id="confirm_password"
                    name="confirm_password"
                    placeholder="Re-enter your password"
                    required
                >
                <span id="password_match_message"></span>
            </div>
        </div>

        <!-- Password Strength Indicator -->
        <div class="password-strength">
            <div class="strength-bar">
                <div class="strength-fill" id="strengthFill"></div>
            </div>
            <p class="strength-text" id="strengthText">Enter a strong password</p>
            <ul class="requirements" id="requirements">
                <li id="reqLength">❌ At least 8 characters</li>
                <li id="reqUpper">❌ At least 1 uppercase letter</li>
                <li id="reqLower">❌ At least 1 lowercase letter</li>
                <li id="reqNumber">❌ At least 1 number</li>
                <li id="reqSpecial">❌ At least 1 special character (!@#$%^&*)</li>
            </ul>
        </div>

        <!-- DRIVER PHOTO -->
        <div class="form-group">
            <label for="driver_photo">Driver's Picture *</label>
            <input 
                type="file"
                id="driver_photo"
                name="driver_photo"
                accept="image/*"
                required
            >
            <small>Allowed: JPG, PNG, JPEG (Max 5MB)</small>
        </div>

        <!-- VEHICLE PHOTO -->
        <div class="form-group">
            <label for="vehicle_photo">Vehicle Picture *</label>
            <input 
                type="file"
                id="vehicle_photo"
                name="vehicle_photo"
                accept="image/*"
                required
            >
            <small>Allowed: JPG, PNG, JPEG (Max 5MB)</small>
        </div>

        <!-- ============================================ -->
        <!-- 🚗 VEHICLE INFORMATION -->
        <!-- ============================================ -->
        <h2>🚗 Vehicle Information</h2>

        <div class="form-group">
            <label for="vehicle_type">Vehicle Type *</label>
            <select id="vehicle_type" name="vehicle_type" required>
                <option value="">Select vehicle type</option>
                <option value="Car" <?php echo (isset($vehicle_type) && $vehicle_type == 'Car') ? 'selected' : ''; ?>>🚗 Car</option>
                <option value="Motor Bike" <?php echo (isset($vehicle_type) && $vehicle_type == 'Motor Bike') ? 'selected' : ''; ?>>🏍️ Motor Bike</option>
                <option value="Van" <?php echo (isset($vehicle_type) && $vehicle_type == 'Van') ? 'selected' : ''; ?>>🚐 Van</option>
            </select>
            <small>Select your vehicle type</small>
        </div>

        <div class="form-group">
            <label for="vehicle_make">Vehicle Make *</label>
            <input 
                type="text"
                id="vehicle_make"
                name="vehicle_make"
                placeholder="e.g. Toyota, Ford, Honda"
                value="<?php echo isset($vehicle_make) ? htmlspecialchars($vehicle_make) : ''; ?>"
                required
            >
            <small>Brand of your vehicle</small>
        </div>

        <div class="form-group">
            <label for="vehicle_model">Vehicle Model *</label>
            <input 
                type="text"
                id="vehicle_model"
                name="vehicle_model"
                placeholder="e.g. Corolla, Focus, Civic"
                value="<?php echo isset($vehicle_model) ? htmlspecialchars($vehicle_model) : ''; ?>"
                required
            >
            <small>Model name</small>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="vehicle_color">Vehicle Color *</label>
                <input 
                    type="text"
                    id="vehicle_color"
                    name="vehicle_color"
                    placeholder="e.g. Red, Blue, White"
                    value="<?php echo isset($vehicle_color) ? htmlspecialchars($vehicle_color) : ''; ?>"
                    required
                >
                <small>Color of your vehicle</small>
            </div>

            <div class="form-group">
                <label for="vehicle_capacity">Vehicle Capacity *</label>
                <input 
                    type="number"
                    id="vehicle_capacity"
                    name="vehicle_capacity"
                    placeholder="e.g. 4"
                    min="1"
                    max="7"
                    value="<?php echo isset($vehicle_capacity) ? htmlspecialchars($vehicle_capacity) : '4'; ?>"
                    required
                >
                <small>Number of passengers (excluding driver)</small>
            </div>
        </div>

        <div class="form-group">
            <label for="vehicle_registration">Vehicle Registration Number *</label>
            <input 
                type="text"
                id="vehicle_registration"
                name="vehicle_registration"
                placeholder="e.g. PG 206 EC"
                value="<?php echo isset($vehicle_registration) ? htmlspecialchars($vehicle_registration) : ''; ?>"
                required
            >
            <span id="vehicle_reg_error" class="error-message"></span>
        </div>

        <!-- AUTHENTICATION -->
        <h2>📱 Authentication</h2>

        <div class="form-group">
            <label>Choose verification method *</label>
            <div class="verification-options">
                <label>
                    <input 
                        type="radio"
                        name="verification_method"
                        value="email"
                        <?php echo (isset($verification_method) && $verification_method == 'email') ? 'checked' : ''; ?>
                        required
                    >
                    📧 Email
                </label>
                <label>
                    <input 
                        type="radio"
                        name="verification_method"
                        value="cellphone"
                        <?php echo (isset($verification_method) && $verification_method == 'cellphone') ? 'checked' : ''; ?>
                    >
                    📱 Cellphone
                </label>
            </div>
        </div>

        <!-- SUBMIT -->
        <button type="submit" class="register-button">✅ Register as Driver</button>

        <p class="login-link">
            Already registered as a driver? <a href="login.php">Login here</a>
        </p>
        <p class="login-link">
            <a href="register.php">← Change Role</a>
        </p>

    </form>
    <?php endif; ?>

</div>

<?php include 'footer.php'; ?>

<!-- ============================================ -->
<!-- ✅ UPDATED JAVASCRIPT WITH REAL-TIME VALIDATION -->
<!-- ============================================ -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Get form elements
        const form = document.getElementById('registrationForm');
        const idInput = document.getElementById('id_number');
        const nameInput = document.getElementById('name');
        const surnameInput = document.getElementById('surname');
        const emailInput = document.getElementById('email');
        const cellInput = document.getElementById('cell_number');
        const passwordInput = document.getElementById('password');
        const confirmInput = document.getElementById('confirm_password');
        const vehicleRegInput = document.getElementById('vehicle_registration');

        // Error message elements
        const idError = document.getElementById('id_error');
        const nameError = document.getElementById('name_error');
        const surnameError = document.getElementById('surname_error');
        const emailError = document.getElementById('email_error');
        const cellError = document.getElementById('cell_error');
        const vehicleRegError = document.getElementById('vehicle_reg_error');

        // Password strength elements
        const strengthFill = document.getElementById('strengthFill');
        const strengthText = document.getElementById('strengthText');
        const reqLength = document.getElementById('reqLength');
        const reqUpper = document.getElementById('reqUpper');
        const reqLower = document.getElementById('reqLower');
        const reqNumber = document.getElementById('reqNumber');
        const reqSpecial = document.getElementById('reqSpecial');

        // ============================================
        // 1. ID NUMBER VALIDATION (13 digits only)
        // ============================================
        if (idInput) {
            idInput.addEventListener('input', function() {
                this.value = this.value.replace(/\D/g, '');
                
                if (this.value.length > 0 && this.value.length !== 13) {
                    idError.textContent = `❌ ID must be exactly 13 digits (currently ${this.value.length})`;
                    idError.style.color = 'red';
                    this.style.borderColor = 'red';
                } else if (this.value.length === 13) {
                    idError.textContent = '✅ Valid ID number';
                    idError.style.color = 'green';
                    this.style.borderColor = 'green';
                } else {
                    idError.textContent = '';
                    this.style.borderColor = '';
                }
            });
        }

        // ============================================
        // 2. NAME VALIDATION (Letters only)
        // ============================================
        if (nameInput) {
            nameInput.addEventListener('input', function() {
                const validName = this.value.replace(/[^a-zA-Z\s\-']/g, '');
                if (this.value !== validName) {
                    this.value = validName;
                    nameError.textContent = '❌ Only letters, spaces, hyphens, and apostrophes allowed';
                    nameError.style.color = 'red';
                    this.style.borderColor = 'red';
                } else if (this.value.length > 0 && this.value.length < 2) {
                    nameError.textContent = '❌ Name must be at least 2 characters';
                    nameError.style.color = 'red';
                    this.style.borderColor = 'red';
                } else if (this.value.length > 0) {
                    nameError.textContent = '✅ Valid name';
                    nameError.style.color = 'green';
                    this.style.borderColor = 'green';
                } else {
                    nameError.textContent = '';
                    this.style.borderColor = '';
                }
            });
        }

        // ============================================
        // 3. SURNAME VALIDATION (Letters only)
        // ============================================
        if (surnameInput) {
            surnameInput.addEventListener('input', function() {
                const validSurname = this.value.replace(/[^a-zA-Z\s\-']/g, '');
                if (this.value !== validSurname) {
                    this.value = validSurname;
                    surnameError.textContent = '❌ Only letters, spaces, hyphens, and apostrophes allowed';
                    surnameError.style.color = 'red';
                    this.style.borderColor = 'red';
                } else if (this.value.length > 0 && this.value.length < 2) {
                    surnameError.textContent = '❌ Surname must be at least 2 characters';
                    surnameError.style.color = 'red';
                    this.style.borderColor = 'red';
                } else if (this.value.length > 0) {
                    surnameError.textContent = '✅ Valid surname';
                    surnameError.style.color = 'green';
                    this.style.borderColor = 'green';
                } else {
                    surnameError.textContent = '';
                    this.style.borderColor = '';
                }
            });
        }

        // ============================================
        // 4. EMAIL VALIDATION (Must be @gmail.com)
        // ============================================
        if (emailInput) {
            emailInput.addEventListener('input', function() {
                const email = this.value;
                const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
                
                if (email.length > 0) {
                    if (emailPattern.test(email) && email.endsWith('@gmail.com')) {
                        emailError.textContent = '✅ Valid Gmail address';
                        emailError.style.color = 'green';
                        this.style.borderColor = 'green';
                    } else if (emailPattern.test(email) && !email.endsWith('@gmail.com')) {
                        emailError.textContent = '❌ Drivers must use @gmail.com';
                        emailError.style.color = 'red';
                        this.style.borderColor = 'red';
                    } else {
                        emailError.textContent = '❌ Invalid email format (e.g., name@gmail.com)';
                        emailError.style.color = 'red';
                        this.style.borderColor = 'red';
                    }
                } else {
                    emailError.textContent = '';
                    this.style.borderColor = '';
                }
            });
        }

        // ============================================
        // 5. CELL NUMBER VALIDATION (10 digits only)
        // ============================================
        if (cellInput) {
            cellInput.addEventListener('input', function() {
                this.value = this.value.replace(/\D/g, '');
                
                if (this.value.length > 10) {
                    this.value = this.value.slice(0, 10);
                }
                
                if (this.value.length > 0 && this.value.length < 10) {
                    cellError.textContent = `❌ Cell number must be 10 digits (currently ${this.value.length})`;
                    cellError.style.color = 'red';
                    this.style.borderColor = 'red';
                } else if (this.value.length === 10) {
                    if (this.value.startsWith('0')) {
                        cellError.textContent = '✅ Valid cell number';
                        cellError.style.color = 'green';
                        this.style.borderColor = 'green';
                    } else {
                        cellError.textContent = '❌ Cell number must start with 0';
                        cellError.style.color = 'red';
                        this.style.borderColor = 'red';
                    }
                } else {
                    cellError.textContent = '';
                    this.style.borderColor = '';
                }
            });
        }

        // ============================================
        // 6. VEHICLE REGISTRATION VALIDATION
        // ============================================
        if (vehicleRegInput) {
            vehicleRegInput.addEventListener('input', function() {
                const validReg = this.value.replace(/[^a-zA-Z0-9\s\-]/g, '');
                if (this.value !== validReg) {
                    this.value = validReg;
                    vehicleRegError.textContent = '❌ Only letters, numbers, spaces, and hyphens allowed';
                    vehicleRegError.style.color = 'red';
                    this.style.borderColor = 'red';
                } else if (this.value.length > 0 && this.value.length < 4) {
                    vehicleRegError.textContent = '❌ Registration too short';
                    vehicleRegError.style.color = 'red';
                    this.style.borderColor = 'red';
                } else if (this.value.length > 0) {
                    vehicleRegError.textContent = '✅ Valid registration format';
                    vehicleRegError.style.color = 'green';
                    this.style.borderColor = 'green';
                } else {
                    vehicleRegError.textContent = '';
                    this.style.borderColor = '';
                }
            });
        }

        // ============================================
        // 7. PASSWORD STRENGTH CHECKER (Real-time)
        // ============================================
        if (passwordInput && strengthFill && strengthText) {
            passwordInput.addEventListener('input', function() {
                const pwd = this.value;
                let metCount = 0;
                
                // Check each requirement
                const hasLength = pwd.length >= 8;
                const hasUpper = /[A-Z]/.test(pwd);
                const hasLower = /[a-z]/.test(pwd);
                const hasNumber = /[0-9]/.test(pwd);
                const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(pwd);
                
                // Update requirement list in real-time (✅ when met, ❌ when not)
                updateRequirement(reqLength, hasLength, 'At least 8 characters');
                updateRequirement(reqUpper, hasUpper, 'At least 1 uppercase letter');
                updateRequirement(reqLower, hasLower, 'At least 1 lowercase letter');
                updateRequirement(reqNumber, hasNumber, 'At least 1 number');
                updateRequirement(reqSpecial, hasSpecial, 'At least 1 special character');
                
                // Count met requirements
                metCount = [hasLength, hasUpper, hasLower, hasNumber, hasSpecial].filter(Boolean).length;
                let score = (metCount / 5) * 100;
                
                // Update strength bar
                strengthFill.style.width = score + '%';
                strengthFill.className = 'strength-fill';
                
                // Update strength text
                let level, colorClass;
                if (score === 0) {
                    level = 'Enter a strong password';
                    colorClass = '';
                } else if (score < 40) {
                    level = 'Weak - add more characters and variety';
                    colorClass = 'weak';
                } else if (score < 60) {
                    level = 'Medium - add more variety';
                    colorClass = 'medium';
                } else if (score < 80) {
                    level = 'Good - almost there!';
                    colorClass = 'good';
                } else {
                    level = '✅ Strong password!';
                    colorClass = 'strong';
                }
                
                strengthText.textContent = level;
                strengthText.className = 'strength-text ' + colorClass;
                strengthFill.classList.add(colorClass);
            });
        }

        // ✅ Function to update requirement icons in real-time
        function updateRequirement(element, met, text) {
            if (element) {
                if (met) {
                    element.textContent = '✅ ' + text;
                    element.className = 'met';
                } else {
                    element.textContent = '❌ ' + text;
                    element.className = '';
                }
            }
        }

        // ============================================
        // 8. PASSWORD MATCH CHECKER (Real-time)
        // ============================================
        const matchMessage = document.getElementById('password_match_message');

        if (confirmInput && passwordInput && matchMessage) {
            confirmInput.addEventListener('input', function() {
                if (this.value.length > 0) {
                    if (this.value === passwordInput.value) {
                        matchMessage.innerHTML = '✅ Passwords match';
                        matchMessage.style.color = 'green';
                    } else {
                        matchMessage.innerHTML = '❌ Passwords do not match';
                        matchMessage.style.color = 'red';
                    }
                } else {
                    matchMessage.innerHTML = '';
                }
            });
        }
    });
</script>

</body>
</html>