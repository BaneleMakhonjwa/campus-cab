<?php
session_start();
include_once __DIR__ . '/db_connect.php';
include 'admin_auth.php';

requireAdmin();

$filter = $_GET['filter'] ?? 'All';
$allowed = ['All', 'Requested', 'Accepted', 'In Progress', 'Completed', 'Cancelled'];
if (!in_array($filter, $allowed)) $filter = 'All';

$sql = "
    SELECT 
        r.*,
        s.studentFname,
        s.studentLname,
        st.staff_name,
        st.surname,
        d.DriverFname,
        d.DriverLname,
        d.vehicle_registration
    FROM ride r
    LEFT JOIN student s ON r.studentID = s.studentID
    LEFT JOIN staff st ON r.staff_id = st.staff_id
    LEFT JOIN driver d ON r.DriverID = d.DriverID
";

if ($filter !== 'All') {
    $sql .= " WHERE r.ride_status = ? ";
}

$sql .= " ORDER BY r.requested_at DESC LIMIT 200";

$stmt = $conn->prepare($sql);
if ($filter !== 'All') {
    $stmt->bind_param("s", $filter);
}
$stmt->execute();
$result = $stmt->get_result();

$pageTitle = "All Rides";
include 'header.php';
?>

<style>
.admin-page { max-width: 1300px; margin: 0 auto; padding: 35px 25px 60px; }
.admin-page h1 { color: #0c2d4d; font-size: 28px; margin: 0 0 8px; font-weight: 800; }
.admin-page .subtitle { color: #6b7280; margin: 0 0 25px; }

.filter-tabs { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 22px; }
.filter-tab {
    padding: 10px 18px; border-radius: 20px; background: #fff;
    border: 1px solid #e2e2dc; color: #0c2d4d; text-decoration: none;
    font-size: 14px; font-weight: 600; transition: all 0.25s ease;
}
.filter-tab:hover { background: #f8f9fa; }
.filter-tab.active { background: #0c2d4d; color: #fff; border-color: #0c2d4d; }

.table-wrap {
    background: #fff; border: 1px solid #e2e2dc; border-radius: 14px;
    overflow-x: auto; box-shadow: 0 4px 14px rgba(11,31,58,0.05);
}
table { width: 100%; border-collapse: collapse; min-width: 900px; }
th {
    background: #0c2d4d; color: #fff; padding: 14px 16px;
    text-align: left; font-size: 12px; text-transform: uppercase;
    letter-spacing: 0.4px; font-weight: 700;
}
td {
    padding: 14px 16px; border-bottom: 1px solid #f0f1f3;
    font-size: 13.5px; color: #172033;
}
tr:last-child td { border-bottom: none; }
tr:hover { background: #f8f9fa; }

.status-pill {
    display: inline-block; padding: 4px 12px; border-radius: 20px;
    font-size: 11px; font-weight: 700; text-transform: uppercase;
    letter-spacing: 0.4px;
}
.status-requested       { background: #fbecc9; color: #8a6d00; }
.status-accepted        { background: #dbe8fb; color: #185fa5; }
.status-driver-arriving { background: #dbe8fb; color: #185fa5; }
.status-in-progress     { background: #fef3c7; color: #b8860b; }
.status-completed       { background: #dcf1e9; color: #0f6e56; }
.status-cancelled       { background: #fbe2df; color: #b03a2e; }

.type-pill {
    display: inline-block; padding: 3px 10px; border-radius: 12px;
    font-size: 10.5px; font-weight: 700;
}
.type-ride   { background: #e0e7ef; color: #0c2d4d; }
.type-parcel { background: #ede9fe; color: #6d28d9; }

.empty {
    background: #fff; border: 1px solid #e2e2dc; border-radius: 14px;
    padding: 50px 30px; text-align: center; color: #6b7280;
}
.empty h3 { color: #0c2d4d; margin: 0 0 8px; }
</style>

<div class="admin-page">

    <h1>🚗 All Rides</h1>
    <p class="subtitle">Monitor every ride and parcel services on the platform.</p>

    <div class="filter-tabs">
        <?php foreach ($allowed as $f): ?>
            <a href="?filter=<?php echo $f; ?>" class="filter-tab <?php echo $filter === $f ? 'active' : ''; ?>">
                <?php echo $f; ?>
            </a>
        <?php endforeach; ?>
    </div>

    <?php if ($result->num_rows === 0): ?>

        <div class="empty">
            <h3>No rides found</h3>
            <p>There are no rides matching "<?php echo htmlspecialchars($filter); ?>".</p>
        </div>

    <?php else: ?>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Type</th>
                        <th>Passenger</th>
                        <th>Driver</th>
                        <th>Pickup</th>
                        <th>Destination</th>
                        <th>Fare</th>
                        <th>Status</th>
                        <th>Requested</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($r = $result->fetch_assoc()): ?>

                        <?php
                        // Passenger name
                        $passenger = '—';
                        if (!empty($r['studentFname'])) {
                            $passenger = trim($r['studentFname'] . ' ' . $r['studentLname']);
                        } elseif (!empty($r['staff_name'])) {
                            $passenger = trim($r['staff_name'] . ' ' . $r['surname']) . ' (staff)';
                        }

                        // Driver name
                        $driver = '—';
                        if (!empty($r['DriverFname'])) {
                            $driver = trim($r['DriverFname'] . ' ' . $r['DriverLname']);
                        }

                        $statusClass = strtolower(str_replace(' ', '-', $r['ride_status']));
                        $typeClass = strtolower($r['request_type']);
                        ?>

                        <tr>
                            <td>#<?php echo (int)$r['rideID']; ?></td>
                            <td>
                                <span class="type-pill type-<?php echo $typeClass; ?>">
                                    <?php echo htmlspecialchars($r['request_type']); ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($passenger); ?></td>
                            <td><?php echo htmlspecialchars($driver); ?></td>
                            <td><?php echo htmlspecialchars(substr($r['pickup_address'] ?? '—', 0, 30)); ?></td>
                            <td><?php echo htmlspecialchars(substr($r['destination_address'] ?? '—', 0, 30)); ?></td>
                            <td>R<?php echo number_format((float)($r['estimated_price'] ?? 0), 2); ?></td>
                            <td>
                                <span class="status-pill status-<?php echo $statusClass; ?>">
                                    <?php echo htmlspecialchars($r['ride_status']); ?>
                                </span>
                            </td>
                            <td>
                                <?php
                                if (!empty($r['requested_at'])) {
                                    echo date('d M Y H:i', strtotime($r['requested_at']));
                                } else {
                                    echo '—';
                                }
                                ?>
                            </td>
                        </tr>

                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

    <?php endif; ?>

</div>

<?php include 'footer.php'; ?>