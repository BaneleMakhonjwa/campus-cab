<?php
session_start();
include_once __DIR__ . '/db_connect.php';
include 'admin_auth.php';

requireAdmin();

$stmt = $conn->query("
    SELECT * FROM user_activity_log WHERE actor_type='Admin' ORDER BY created_at DESC LIMIT 200
");

$pageTitle = "Audit Log";
include 'header.php';
?>

<style>
.admin-page { max-width: 1200px; margin: 0 auto; padding: 35px 25px 60px; }
.admin-page h1 { color: #0c2d4d; font-size: 28px; margin: 0 0 8px; }
.admin-page .subtitle { color: #6b7280; margin: 0 0 25px; }

.log-table {
    width: 100%;
    background: #ffffff;
    border: 1px solid #e2e2dc;
    border-radius: 14px;
    overflow: hidden;
    border-collapse: collapse;
    box-shadow: 0 4px 14px rgba(11, 31, 58, 0.05);
}
.log-table th {
    background: #0c2d4d;
    color: #ffffff;
    padding: 14px 16px;
    text-align: left;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    font-weight: 700;
}
.log-table td {
    padding: 14px 16px;
    border-bottom: 1px solid #f0f1f3;
    font-size: 13.5px;
    color: #172033;
}
.log-table tr:last-child td { border-bottom: none; }
.log-table tr:hover { background: #f8f9fa; }

.role-badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
}
.role-super_admin { background: #fef3c7; color: #b8860b; }
.role-admin { background: #dbe8fb; color: #185fa5; }

.empty-log {
    background: #ffffff;
    border: 1px solid #e2e2dc;
    border-radius: 14px;
    padding: 50px 30px;
    text-align: center;
    color: #6b7280;
}
</style>

<div class="admin-page">

    <h1>📋 Audit Log</h1>
    <p class="subtitle">Track all administrative actions for accountability.</p>

    <?php
    $result = $conn->query("SELECT * FROM user_activity_log WHERE actor_type='Admin' ORDER BY created_at DESC LIMIT 200");
    ?>

    <?php if ($result && $result->num_rows > 0): ?>

        <table class="log-table">
            <thead>
                <tr>
                    <th>Date & Time</th>
                    <th>Admin</th>
                    <th>Role</th>
                    <th>Action</th>
                    <th>Target</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($log = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo date('d M Y H:i', strtotime($log['created_at'])); ?></td>
                        <td><?php echo htmlspecialchars($log['actor_name']); ?></td>
                        <td>
                            <span class="role-badge role-<?php echo $log['actor_type']; ?>">
                                <?php echo $log['actor_type'] === 'super_admin' ? '👑 Super' : 'Admin'; ?>
                            </span>
                        </td>
                        <td><strong><?php echo htmlspecialchars($log['action_type']); ?></strong></td>
                        <td>
                            <?php if ($log['target_type']): ?>
                                <?php echo htmlspecialchars($log['target_type'] . ' #' . $log['target_id']); ?>
                                <?php if ($log['description']): ?>
                                    <br><small style="color: #6b7280;"><?php echo htmlspecialchars($log['description']); ?></small>
                                <?php endif; ?>
                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

    <?php else: ?>

        <div class="empty-log">
            <h3>No audit log entries yet</h3>
            <p>Actions performed by admins will appear here.</p>
        </div>

    <?php endif; ?>

</div>

<?php include 'footer.php'; ?>