<?php
session_start();
$pageTitle = "Register";
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Choose Registration | Campus Cab</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .register-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 70vh;
            padding: 40px 20px;
        }

        .register-card {
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            max-width: 500px;
            width: 100%;
            text-align: center;
        }

        .register-card h1 {
            color: #2c3e50;
            font-size: 28px;
            margin-bottom: 5px;
        }

        .register-card p {
            color: #6c757d;
            font-size: 16px;
            margin-bottom: 25px;
        }

        .role-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin: 20px 0;
        }

        .role-option {
            background: #f8f9fa;
            padding: 25px 15px;
            border-radius: 10px;
            border: 2px solid transparent;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            color: #333;
            display: block;
        }

        .role-option:hover {
            background: #e9ecef;
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .role-option .icon {
            font-size: 40px;
            display: block;
            margin-bottom: 10px;
        }

        .role-option .title {
            font-size: 18px;
            font-weight: 600;
            display: block;
            margin-bottom: 5px;
        }

        .role-option .desc {
            font-size: 12px;
            color: #6c757d;
            display: block;
        }

        .role-option.student:hover {
            border-color: #007bff;
        }

        .role-option.driver:hover {
            border-color: #28a745;
        }

        .role-option.staff:hover {
            border-color: #ffc107;
        }

        .role-option.admin:hover {
            border-color: #dc3545;
        }

        .coming-soon {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .coming-soon:hover {
            transform: none !important;
            box-shadow: none !important;
        }

        .coming-soon .badge {
            display: inline-block;
            background: #dc3545;
            color: white;
            font-size: 10px;
            padding: 2px 10px;
            border-radius: 20px;
            margin-top: 5px;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #007bff;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        @media (max-width: 480px) {
            .role-grid {
                grid-template-columns: 1fr 1fr;
                gap: 10px;
            }

            .role-option {
                padding: 15px 10px;
            }

            .role-option .icon {
                font-size: 30px;
            }

            .role-option .title {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

    <div class="register-container">

        <div class="register-card">

            <h1>📝 Choose Registration Type</h1>
            <p>Select who you want to register as:</p>

            <div class="role-grid">

                <!-- STUDENT -->
                <a href="register_student.php" class="role-option student">
                    <span class="icon">🎓</span>
                    <span class="title">Student</span>
                    <span class="desc">Request rides & parcel collection</span>
                </a>

                <!-- DRIVER -->
                <a href="register_driver.php" class="role-option driver">
                    <span class="icon">🚗</span>
                    <span class="title">Driver</span>
                    <span class="desc">Drive and earn money</span>
                </a>

                <!-- STAFF (Coming Soon) -->
                <a href="register_staff.php" class="role-option staff" >
                    <span class="icon">👔</span>
                    <span class="title">Staff</span>
                    <span class="desc">Request rides and Parcel collection</span>
                </a>

                <!-- ADMIN (Coming Soon) -->
                <a href="#" class="role-option admin coming-soon" onclick="alert('Admin registration coming soon!'); return false;">
                    <span class="icon">🔐</span>
                    <span class="title">Admin</span>
                    <span class="desc">Full system control</span>
                    <span class="badge">Coming Soon</span>
                </a>

            </div>

            <p style="margin-top: 20px; font-size: 14px;">
                Already have an account?
                <a href="login.php" style="color: #007bff; text-decoration: none; font-weight: 600;">Login here</a>
            </p>

            <a href="index.php" class="back-link">← Back to Home</a>

        </div>

    </div>

    <?php include 'footer.php'; ?>

</body>
</html>