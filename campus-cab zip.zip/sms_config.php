<?php
// Africa's Talking configuration. Set CAMPUS_CAB_AT_USERNAME and CAMPUS_CAB_AT_API_KEY in the server environment.
require_once __DIR__ . '/vendor/autoload.php';
use AfricasTalking\SDK\AfricasTalking;

function sendVerificationSMS($phone, $code) {
    $username = getenv('CAMPUS_CAB_AT_USERNAME') ?: 'sandbox';
    $apiKey = getenv('CAMPUS_CAB_AT_API_KEY') ?: '';
    if ($apiKey === '') return false;
    try {
        $AT = new AfricasTalking($username, $apiKey);
        $sms = $AT->sms();
        $sms->send(['to' => $phone, 'message' => "Your Campus Cab verification code is: $code"]);
        return true;
    } catch (Throwable $e) {
        error_log('SMS sending failed: ' . $e->getMessage());
        return false;
    }
}
?>
