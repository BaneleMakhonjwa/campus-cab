<?php
session_start(); require_once __DIR__.'/db_connect.php'; header('Content-Type: application/json; charset=utf-8');
function json_response(array $d,int $s=200):void{http_response_code($s);echo json_encode($d,JSON_UNESCAPED_SLASHES);exit;}
$driverID=(int)($_SESSION['driver_id']??0);if($driverID<=0)json_response(['success'=>false,'code'=>'NOT_LOGGED_IN'],401);
$input=$_POST;if(!$input&&stripos($_SERVER['CONTENT_TYPE']??'','application/json')!==false){$x=json_decode(file_get_contents('php://input'),true);if(is_array($x))$input=$x;}
$rideID=(int)($input['ride_id']??$input['rideID']??0);$parcelID=(int)($input['parcel_id']??$input['parcelID']??0);$lat=$input['lat']??$input['latitude']??null;$lng=$input['lng']??$input['longitude']??null;
if(!is_numeric($lat)||!is_numeric($lng))json_response(['success'=>false,'code'=>'INVALID_COORDINATES'],400);$lat=(float)$lat;$lng=(float)$lng;if($lat<-90||$lat>90||$lng<-180||$lng>180)json_response(['success'=>false,'code'=>'OUT_OF_RANGE'],400);
if($rideID>0&&$parcelID>0)json_response(['success'=>false,'code'=>'INVALID_TARGET'],400);
$requestType='availability';
if($rideID>0){$q=$conn->prepare("SELECT rideID FROM ride WHERE rideID=? AND DriverID=? AND ride_status IN ('Accepted','Driver Arriving','In Progress') LIMIT 1");$q->bind_param('ii',$rideID,$driverID);$q->execute();if(!$q->get_result()->fetch_assoc()){ $q->close();json_response(['success'=>false,'code'=>'RIDE_NOT_ACTIVE'],409);} $q->close();$requestType='ride';}
elseif($parcelID>0){$q=$conn->prepare("SELECT parcel FROM parcel WHERE parcel=? AND DriverID=? AND parcel_status IN ('Accepted','In Progress') LIMIT 1");$q->bind_param('ii',$parcelID,$driverID);$q->execute();if(!$q->get_result()->fetch_assoc()){ $q->close();json_response(['success'=>false,'code'=>'INVALID_PARCEL'],403);} $q->close();$requestType='parcel';}
$stmt=$conn->prepare("INSERT INTO location (ride_id,driver_id,latitude,longitude,recorded_at,request_type) VALUES (NULLIF(?,0),?,?,?,NOW(),?)");$stmt->bind_param('iidds',$rideID,$driverID,$lat,$lng,$requestType);
if(!$stmt->execute())json_response(['success'=>false,'code'=>'DB_ERROR','message'=>'Could not save your GPS location.'],500);$stmt->close();
$online=$conn->prepare("UPDATE driver SET availability_status='Available' WHERE DriverID=? AND driverAccount_Status='Active'");$online->bind_param('i',$driverID);$online->execute();$online->close();
json_response(['success'=>true,'lat'=>$lat,'lng'=>$lng,'request_type'=>$requestType]);
?>
