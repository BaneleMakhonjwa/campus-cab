<?php
if (session_status() === PHP_SESSION_NONE) session_start();
include_once 'db_connect.php';

$activeRole = strtolower(trim((string)($_SESSION['role'] ?? '')));
$currentPage = basename($_SERVER['PHP_SELF'] ?? '');
$requestedAs = strtolower(trim((string)($_GET['as'] ?? '')));
$studentPages = ['student_dashboard.php'];
$staffPages = ['staff_dashboard.php','staff_profile.php','staff_ratings.php','staff_my_rides.php','staff_active_ride.php'];
$isStudent = (($requestedAs === 'student') || ($requestedAs === '' && ($activeRole === 'student' || in_array($currentPage, $studentPages, true)))) && isset($_SESSION['student_id']) && (int)$_SESSION['student_id'] > 0;
$isStaff = (($requestedAs === 'staff') || ($requestedAs === '' && ($activeRole === 'staff' || in_array($currentPage, $staffPages, true)))) && isset($_SESSION['staff_id']) && (int)$_SESSION['staff_id'] > 0;
$isDriver = isset($_SESSION['driver_id']) && (int)$_SESSION['driver_id'] > 0;
$isAdmin = $activeRole === 'admin' && isset($_SESSION['admin_id']) && (int)$_SESSION['admin_id'] > 0;
$driverPages = ['driver_dashboard.php','driver_ride_requests.php','driver_active_ride.php','driver_parcel_requests.php','driver_earnings.php','driver_rates.php','driver_emergency_contacts.php','driver_emergency_assistance.php','driver_messages.php'];
$isDriverPage = in_array($currentPage, $driverPages, true);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) . ' — Campus Cab' : 'Campus Cab & Delivery'; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="site-header">
    <a href="index.php" class="brand">
    <span class="brand-name">Campus<span>Cab</span></span>

</a>
<?php if ($isDriver && $isDriverPage): ?>
<!-- Driver Ride Notification Pop-up -->
<div id="rideNotificationModal" style="
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(12, 45, 77, 0.75);
    align-items: center;
    justify-content: center;
    z-index: 9999;
    padding: 20px;
">
    <div style="
        background: #ffffff;
        max-width: 460px;
        width: 100%;
        border-radius: 16px;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
        overflow: hidden;
        animation: popIn 0.3s ease;
    ">
        <!-- Header -->
        <div style="
            background: linear-gradient(135deg, #0c2d4d, #185fa5);
            color: #ffffff;
            padding: 20px 25px;
            text-align: center;
        ">
            <div style="font-size: 36px; margin-bottom: 5px;">🚗</div>
            <h2 style="margin: 0; font-size: 20px;">New Ride Request</h2>
            <p style="margin: 5px 0 0; opacity: 0.9; font-size: 13px;">You have 30 seconds to respond</p>
        </div>

        <!-- Ride details -->
        <div style="padding: 25px;">
            <div style="display: grid; gap: 14px;">
                <div>
                    <div style="font-size: 11px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.4px; font-weight: 700;">Passenger</div>
                    <div id="notifPassenger" style="font-size: 15px; font-weight: 700; color: #0c2d4d; margin-top: 3px;">—</div>
                </div>

                <div>
                    <div style="font-size: 11px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.4px; font-weight: 700;">Pickup</div>
                    <div id="notifPickup" style="font-size: 14px; color: #172033; margin-top: 3px;">—</div>
                </div>

                <div>
                    <div style="font-size: 11px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.4px; font-weight: 700;">Destination</div>
                    <div id="notifDestination" style="font-size: 14px; color: #172033; margin-top: 3px;">—</div>
                </div>

                <div style="display: flex; gap: 12px;">
                    <div style="flex: 1; background: #f8f9fa; padding: 12px; border-radius: 8px; text-align: center;">
                        <div style="font-size: 11px; color: #6b7280; font-weight: 700;">DISTANCE</div>
                        <div id="notifDistance" style="font-size: 16px; font-weight: 800; color: #0c2d4d; margin-top: 4px;">—</div>
                    </div>
                    <div style="flex: 1; background: #dcf1e9; padding: 12px; border-radius: 8px; text-align: center;">
                        <div style="font-size: 11px; color: #0f6e56; font-weight: 700;">EARNING</div>
                        <div id="notifPrice" style="font-size: 16px; font-weight: 800; color: #0f6e56; margin-top: 4px;">—</div>
                    </div>
                </div>
            </div>

            <!-- Countdown -->
            <div style="margin-top: 20px; text-align: center;">
                <div style="
                    width: 50px;
                    height: 50px;
                    border-radius: 50%;
                    background: #0c2d4d;
                    color: #ffffff;
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 20px;
                    font-weight: 800;
                " id="notifCountdown">30</div>
            </div>

            <!-- Actions -->
            <div style="display: flex; gap: 10px; margin-top: 20px;">
                <button id="notifReject" style="
                    flex: 1;
                    padding: 14px;
                    background: #b03a2e;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    font-size: 15px;
                    font-weight: 700;
                    cursor: pointer;
                ">❌ Reject</button>

                <button id="notifAccept" style="
                    flex: 1;
                    padding: 14px;
                    background: #0f6e56;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    font-size: 15px;
                    font-weight: 700;
                    cursor: pointer;
                ">✅ Accept</button>
            </div>
        </div>
    </div>
</div>

<style>
@keyframes popIn {
    from { transform: scale(0.9); opacity: 0; }
    to { transform: scale(1); opacity: 1; }
}
</style>

<script>
(function() {
    const modal = document.getElementById('rideNotificationModal');
    const notifPassenger = document.getElementById('notifPassenger');
    const notifPickup = document.getElementById('notifPickup');
    const notifDestination = document.getElementById('notifDestination');
    const notifDistance = document.getElementById('notifDistance');
    const notifPrice = document.getElementById('notifPrice');
    const notifCountdown = document.getElementById('notifCountdown');
    const btnAccept = document.getElementById('notifAccept');
    const btnReject = document.getElementById('notifReject');

    let currentRide = null;
    let countdownTimer = null;
    let secondsLeft = 30;
    let pingTimer = null;

    //  Ping to mark driver online every 20 seconds
    function ping() {
        fetch('driver_ping.php?action=ping').catch(() => {});
    }
    ping();
    pingTimer = setInterval(ping, 20000);

    //  Mark offline when leaving the page
    window.addEventListener('beforeunload', function() {
        navigator.sendBeacon('driver_ping.php?action=offline');
    });

    //  Check for new rides every 5 seconds
    function checkForRide() {
        if (currentRide) return; // already showing

        fetch('driver_ping.php?action=check_ride')
            .then(r => r.json())
            .then(data => {
                if (data.ride) {
                    showRide(data.ride);
                }
            })
            .catch(() => {});
    }
    setInterval(checkForRide, 5000);
    checkForRide();

    function showRide(ride) {
        currentRide = ride;

        notifPassenger.textContent = (ride.studentFname || 'Student') + ' ' + (ride.studentLname || '');
        notifPickup.textContent = ride.pickup_address || '—';
        notifDestination.textContent = ride.destination_address || '—';
        notifDistance.textContent = (ride.estimated_distance_km || '0') + ' km';
        notifPrice.textContent = 'R' + parseFloat(ride.estimated_price || 0).toFixed(2);

        modal.style.display = 'flex';

        secondsLeft = 30;
        notifCountdown.textContent = secondsLeft;

        clearInterval(countdownTimer);
        countdownTimer = setInterval(function() {
            secondsLeft--;
            notifCountdown.textContent = secondsLeft;

            if (secondsLeft <= 0) {
                clearInterval(countdownTimer);
                autoReject();
            }
        }, 1000);
    }

    function hideModal() {
        modal.style.display = 'none';
        currentRide = null;
        clearInterval(countdownTimer);
    }

    function autoReject() {
        if (!currentRide) return;

        const rideID = currentRide.rideID;
        hideModal();

        fetch('accept_ride.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'rideID=' + rideID + '&action=reject'
        }).catch(() => {});
    }

    btnReject.addEventListener('click', function() {
        if (!currentRide) return;

        const rideID = currentRide.rideID;
        hideModal();

        fetch('accept_ride.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'rideID=' + rideID + '&action=reject'
        }).catch(() => {});
    });

    btnAccept.addEventListener('click', function() {
        if (!currentRide) return;

        const rideID = currentRide.rideID;
        hideModal();

        fetch('accept_ride.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'rideID=' + rideID + '&action=accept'
        })
        .then(r => r.json())
        .then(data => {
    if (data.success) {
        window.location.href = data.redirect || ('driver_active_ride.php?id=' + rideID);
    } else {
        alert(data.message || 'Unable to accept ride');
    }
})
        .catch(() => {
            alert('Network error. Please try again.');
        });
    });
})();
</script>
<?php endif; ?>
    <nav>
        <?php if ($isStudent): ?>
            <a href="request.php?as=student">Request a Ride</a>
            <a href="my_rides.php?as=student">My Rides</a>
            <span class="who">Hi, <?php echo htmlspecialchars($_SESSION['student_name']); ?></span>
            <a href="logout.php" class="btn-outline">Log out</a>

        <?php elseif ($isStaff): ?>
            <a href="staff_dashboard.php">Dashboard</a>
            <a href="request.php?as=staff">Request a Ride</a>
            <a href="request_parcel.php?as=staff">Request a Parcel</a>
            <span class="who">Hi, <?php echo htmlspecialchars($_SESSION['staff_name'] ?? 'Staff'); ?></span>
            <a href="logout.php" class="btn-outline">Log out</a>

        <?php elseif ($isDriver): ?>
            <a href=""></a>
            <a href="driver_dashboard.php">Dashboard</a>
            <span class="who">Hi, <?php echo htmlspecialchars($_SESSION['driver_name']); ?></span>
            <a href="logout.php" class="btn-outline">Log out</a>

            <?php elseif ($isAdmin): ?>
            <a href=""></a>
            <a href="admin_dashboard.php">Dashboard</a>
            <span class="who">Hi, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>
            <a href="logout.php" class="btn-outline">Log out</a>
            
            
        <?php else: ?>
            <a href="index.php">Home</a>
            <a href="register.php">Register</a>
            <a href="login.php" class="btn-login">Login</a>
    <?php endif; ?>
    </nav>
</header>
<main>