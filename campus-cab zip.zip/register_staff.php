<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db_connect.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data — MATCHES FORM FIELD NAMES
    $staff_number = trim($_POST['staff_number']);
    $staff_name   = trim($_POST['staff_name']);
    $surname      = trim($_POST['surname']);
    $staff_email  = trim($_POST['staff_email']);
    $cell_number  = trim($_POST['cell_number']);
    $password     = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    $errors = [];

    // ============================================
    // VALIDATION
    // ============================================
    if (empty($staff_number) || empty($staff_name) || empty($surname) ||
        empty($staff_email) || empty($cell_number) || empty($password)) {
        $errors[] = "All fields are required.";
    }

    // Staff Number — 5 digits
    if (!preg_match('/^[0-9]{5}$/', $staff_number)) {
        $errors[] = "Staff Number must be exactly 5 digits (e.g., 20249).";
    }

    // Name
    if (!preg_match('/^[a-zA-Z\s\-]{2,}$/', $staff_name)) {
        $errors[] = "Name must contain only letters (minimum 2 characters).";
    }

    // Surname
    if (!preg_match('/^[a-zA-Z\s\-]{2,}$/', $surname)) {
        $errors[] = "Surname must contain only letters (minimum 2 characters).";
    }

    // Email — must be @ufh.ac.za
    if (!filter_var($staff_email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    } elseif (!str_ends_with($staff_email, '@ufh.ac.za')) {
        $errors[] = "Email must be a valid staff email ending with @ufh.ac.za";
    }

    // Cell — 10 digits starting with 0
    if (!preg_match('/^0[0-9]{9}$/', $cell_number)) {
        $errors[] = "Cell number must be exactly 10 digits starting with 0 (e.g., 0712345678).";
    }

    // Strong password
    $password_errors = [];
    if (strlen($password) < 8) $password_errors[] = "at least 8 characters long";
    if (!preg_match('/[A-Z]/', $password)) $password_errors[] = "at least 1 uppercase letter";
    if (!preg_match('/[a-z]/', $password)) $password_errors[] = "at least 1 lowercase letter";
    if (!preg_match('/[0-9]/', $password)) $password_errors[] = "at least 1 number";
    if (!preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) $password_errors[] = "at least 1 special character (!@#$%^&*)";

    if (!empty($password_errors)) {
        $errors[] = "Password must contain: " . implode(", ", $password_errors) . ".";
    } elseif ($password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    }

    // ============================================
    // CHECK DUPLICATES — using YOUR column names
    // ============================================
    if (empty($errors)) {

        // Check staff_email
        $check_email_sql = "SELECT staff_id FROM staff WHERE staff_email = ?";
        $check_email_stmt = $conn->prepare($check_email_sql);
        $check_email_stmt->bind_param("s", $staff_email);
        $check_email_stmt->execute();
        $check_email_stmt->store_result();

        if ($check_email_stmt->num_rows > 0) {
            $errors[] = "This email is already registered.";
        }
        $check_email_stmt->close();

        // Check staff_phone
        $check_cell_sql = "SELECT staff_id FROM staff WHERE staff_phone = ?";
        $check_cell_stmt = $conn->prepare($check_cell_sql);
        $check_cell_stmt->bind_param("s", $cell_number);
        $check_cell_stmt->execute();
        $check_cell_stmt->store_result();

        if ($check_cell_stmt->num_rows > 0) {
            $errors[] = "This cell number is already registered.";
        }
        $check_cell_stmt->close();
    }

    // ============================================
    // INSERT — using YOUR column names
    // ============================================
    if (!empty($errors)) {
        $error = implode("<br>", $errors);
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $insert_sql = "INSERT INTO staff 
            (staff_name, surname, staff_email, staff_phone, staffAccount_status, password) 
            VALUES (?, ?, ?, ?, 'Active', ?)";

        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param(
            "sssss",
            $staff_name,
            $surname,
            $staff_email,
            $cell_number,
            $hashed_password
        );

        if ($insert_stmt->execute()) {
            $success = "Registration successful! Welcome " . $staff_name . "! You can now login.";
        } else {
            $error = "Registration failed: " . $conn->error;
        }
        $insert_stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Registration | Campus Cab</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .registration-container { max-width: 600px; margin: 50px auto; padding: 20px; background: #fff; border-radius: 10px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
        .registration-header { text-align: center; margin-bottom: 30px; }
        .registration-header h1 { color: #2c3e50; margin-bottom: 5px; }
        .registration-header p { color: #6c757d; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-weight: bold; margin-bottom: 5px; }
        .form-group input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; box-sizing: border-box; }
        .form-group input:focus { border-color: #007bff; outline: none; box-shadow: 0 0 5px rgba(0,123,255,0.3); }
        .form-group small { display: block; color: #6c757d; font-size: 12px; margin-top: 5px; }
        .form-row { display: flex; gap: 15px; }
        .form-row .form-group { flex: 1; }
        .error-message { font-size: 12px; margin-top: 5px; display: block; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 5px; }
        .alert-danger { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .alert-success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .register-button { width: 100%; padding: 12px; background: #007bff; color: white; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; font-weight: 600; }
        .register-button:hover { background: #0056b3; }
        .login-link { text-align: center; margin-top: 15px; font-size: 14px; }
        .login-link a { color: #007bff; text-decoration: none; }
        .login-link a:hover { text-decoration: underline; }
        .password-strength { margin: 10px 0 20px 0; background: #f8f9fa; padding: 15px; border-radius: 8px; }
        .strength-bar { height: 8px; background: #e9ecef; border-radius: 4px; overflow: hidden; margin-bottom: 8px; }
        .strength-fill { height: 100%; width: 0%; transition: width 0.3s ease; }
        .strength-fill.weak { width: 25%; background: #dc3545; }
        .strength-fill.medium { width: 50%; background: #ffc107; }
        .strength-fill.good { width: 75%; background: #17a2b8; }
        .strength-fill.strong { width: 100%; background: #28a745; }
        .strength-text { font-size: 14px; margin: 0 0 10px 0; font-weight: bold; }
        .requirements { list-style: none; padding: 0; margin: 5px 0 0 0; font-size: 13px; }
        .requirements li { padding: 3px 0; color: #dc3545; }
        .requirements li.met { color: #28a745; font-weight: bold; }
        .btn-primary { display: inline-block; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px; }
        h2 { margin-top: 30px; margin-bottom: 15px; color: #2c3e50; border-bottom: 2px solid #eee; padding-bottom: 10px; }
        @media (max-width: 600px) { .form-row { flex-direction: column; gap: 0; } }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="registration-container">

    <div class="registration-header">
        <h1>👔 Staff Registration</h1>
        <p>Register as a staff member to manage campus operations.</p>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger">❌ <?php echo $error; ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success">
            ✅ <?php echo $success; ?>
            <br><br>
            <a href="login.php" class="btn-primary">🔑 Go to Login</a>
        </div>
    <?php endif; ?>

    <?php if (!$success): ?>
    <form action="" method="POST" id="registrationForm">

        <h2>👤 Staff Information</h2>

        <div class="form-group">
            <label for="staff_number">Staff Number *</label>
            <input type="text" id="staff_number" name="staff_number" placeholder="e.g., 20247" maxlength="5" required>
            <small>Must be exactly 5 digits</small>
            <span id="staff_error" class="error-message"></span>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="staff_name">Name *</label>
                <input type="text" id="staff_name" name="staff_name" placeholder="Enter your name" required>
                <span id="name_error" class="error-message"></span>
            </div>
            <div class="form-group">
                <label for="surname">Surname *</label>
                <input type="text" id="surname" name="surname" placeholder="Enter your surname" required>
                <span id="surname_error" class="error-message"></span>
            </div>
        </div>

        <div class="form-group">
            <label for="staff_email">Staff Email *</label>
            <input type="email" id="staff_email" name="staff_email" placeholder="staff@ufh.ac.za" required>
            <small>Must be a valid @ufh.ac.za email address</small>
            <span id="email_error" class="error-message"></span>
        </div>

        <div class="form-group">
            <label for="cell_number">Cellphone Number *</label>
            <input type="tel" id="cell_number" name="cell_number" placeholder="e.g., 0712345678" maxlength="10" required>
            <small>10 digits starting with 0</small>
            <span id="cell_error" class="error-message"></span>
        </div>

        <h2>🔐 Create Account Password</h2>

        <div class="form-row">
            <div class="form-group">
                <label for="password">Create Password *</label>
                <input type="password" id="password" name="password" placeholder="Min 8 characters" required>
                <small>8+ chars, uppercase, lowercase, number & special character</small>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm Password *</label>
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Re-enter your password" required>
                <span id="password_match_message"></span>
            </div>
        </div>

        <div class="password-strength">
            <div class="strength-bar">
                <div class="strength-fill" id="strengthFill"></div>
            </div>
            <p class="strength-text" id="strengthText">Enter a strong password</p>
            <ul class="requirements">
                <li id="reqLength">❌ At least 8 characters</li>
                <li id="reqUpper">❌ At least 1 uppercase letter</li>
                <li id="reqLower">❌ At least 1 lowercase letter</li>
                <li id="reqNumber">❌ At least 1 number</li>
                <li id="reqSpecial">❌ At least 1 special character</li>
            </ul>
        </div>

        <button type="submit" class="register-button">✅ Register as Staff</button>

        <p class="login-link">Already registered? <a href="login.php">Login here</a></p>
        <p class="login-link"><a href="register.php">← Change Role</a></p>

    </form>
    <?php endif; ?>

</div>

<?php include 'footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const staffInput = document.getElementById('staff_number');
    const nameInput = document.getElementById('staff_name');
    const surnameInput = document.getElementById('surname');
    const emailInput = document.getElementById('staff_email');
    const cellInput = document.getElementById('cell_number');
    const passwordInput = document.getElementById('password');
    const confirmInput = document.getElementById('confirm_password');

    const staffError = document.getElementById('staff_error');
    const nameError = document.getElementById('name_error');
    const surnameError = document.getElementById('surname_error');
    const emailError = document.getElementById('email_error');
    const cellError = document.getElementById('cell_error');

    const strengthFill = document.getElementById('strengthFill');
    const strengthText = document.getElementById('strengthText');
    const reqLength = document.getElementById('reqLength');
    const reqUpper = document.getElementById('reqUpper');
    const reqLower = document.getElementById('reqLower');
    const reqNumber = document.getElementById('reqNumber');
    const reqSpecial = document.getElementById('reqSpecial');

    if (staffInput) {
        staffInput.addEventListener('input', function() {
            this.value = this.value.replace(/\D/g, '');
            if (this.value.length > 0 && this.value.length !== 5) {
                staffError.textContent = `❌ Must be 5 digits (${this.value.length})`;
                staffError.style.color = 'red';
                this.style.borderColor = 'red';
            } else if (this.value.length === 5) {
                staffError.textContent = '✅ Valid';
                staffError.style.color = 'green';
                this.style.borderColor = 'green';
            } else {
                staffError.textContent = '';
                this.style.borderColor = '';
            }
        });
    }

    if (nameInput) {
        nameInput.addEventListener('input', function() {
            const v = this.value.replace(/[^a-zA-Z\s\-']/g, '');
            if (this.value !== v) {
                this.value = v;
                nameError.textContent = '❌ Letters only';
                nameError.style.color = 'red';
                this.style.borderColor = 'red';
            } else if (this.value.length > 0 && this.value.length < 2) {
                nameError.textContent = '❌ Min 2 characters';
                nameError.style.color = 'red';
                this.style.borderColor = 'red';
            } else if (this.value.length > 0) {
                nameError.textContent = '✅ Valid';
                nameError.style.color = 'green';
                this.style.borderColor = 'green';
            } else {
                nameError.textContent = '';
                this.style.borderColor = '';
            }
        });
    }

    if (surnameInput) {
        surnameInput.addEventListener('input', function() {
            const v = this.value.replace(/[^a-zA-Z\s\-']/g, '');
            if (this.value !== v) {
                this.value = v;
                surnameError.textContent = '❌ Letters only';
                surnameError.style.color = 'red';
                this.style.borderColor = 'red';
            } else if (this.value.length > 0 && this.value.length < 2) {
                surnameError.textContent = '❌ Min 2 characters';
                surnameError.style.color = 'red';
                this.style.borderColor = 'red';
            } else if (this.value.length > 0) {
                surnameError.textContent = '✅ Valid';
                surnameError.style.color = 'green';
                this.style.borderColor = 'green';
            } else {
                surnameError.textContent = '';
                this.style.borderColor = '';
            }
        });
    }

    if (emailInput) {
        emailInput.addEventListener('input', function() {
            const email = this.value;
            const pattern = /^[a-zA-Z0-9._%+-]+@ufh\.ac\.za$/;
            if (email.length > 0) {
                if (pattern.test(email)) {
                    emailError.textContent = '✅ Valid';
                    emailError.style.color = 'green';
                    this.style.borderColor = 'green';
                } else {
                    emailError.textContent = '❌ Must be @ufh.ac.za';
                    emailError.style.color = 'red';
                    this.style.borderColor = 'red';
                }
            } else {
                emailError.textContent = '';
                this.style.borderColor = '';
            }
        });
    }

    if (cellInput) {
        cellInput.addEventListener('input', function() {
            this.value = this.value.replace(/\D/g, '');
            if (this.value.length > 10) this.value = this.value.slice(0, 10);
            if (this.value.length > 0 && this.value.length < 10) {
                cellError.textContent = `❌ Must be 10 digits (${this.value.length})`;
                cellError.style.color = 'red';
                this.style.borderColor = 'red';
            } else if (this.value.length === 10) {
                if (this.value.startsWith('0')) {
                    cellError.textContent = '✅ Valid';
                    cellError.style.color = 'green';
                    this.style.borderColor = 'green';
                } else {
                    cellError.textContent = '❌ Must start with 0';
                    cellError.style.color = 'red';
                    this.style.borderColor = 'red';
                }
            } else {
                cellError.textContent = '';
                this.style.borderColor = '';
            }
        });
    }

    if (passwordInput && strengthFill) {
        passwordInput.addEventListener('input', function() {
            const pwd = this.value;
            const hasLength  = pwd.length >= 8;
            const hasUpper   = /[A-Z]/.test(pwd);
            const hasLower   = /[a-z]/.test(pwd);
            const hasNumber  = /[0-9]/.test(pwd);
            const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(pwd);

            updateReq(reqLength, hasLength, 'At least 8 characters');
            updateReq(reqUpper, hasUpper, 'At least 1 uppercase letter');
            updateReq(reqLower, hasLower, 'At least 1 lowercase letter');
            updateReq(reqNumber, hasNumber, 'At least 1 number');
            updateReq(reqSpecial, hasSpecial, 'At least 1 special character');

            const met = [hasLength, hasUpper, hasLower, hasNumber, hasSpecial].filter(Boolean).length;
            const score = (met / 5) * 100;
            strengthFill.style.width = score + '%';
            strengthFill.className = 'strength-fill';
            if (score < 40) { strengthFill.classList.add('weak'); strengthText.textContent = 'Weak'; }
            else if (score < 60) { strengthFill.classList.add('medium'); strengthText.textContent = 'Medium'; }
            else if (score < 80) { strengthFill.classList.add('good'); strengthText.textContent = 'Good'; }
            else { strengthFill.classList.add('strong'); strengthText.textContent = '✅ Strong password!'; }
        });
    }

    function updateReq(el, met, text) {
        if (!el) return;
        el.textContent = (met ? '✅ ' : '❌ ') + text;
        el.className = met ? 'met' : '';
    }

    const matchMessage = document.getElementById('password_match_message');
    if (confirmInput && passwordInput && matchMessage) {
        confirmInput.addEventListener('input', function() {
            if (this.value.length > 0) {
                if (this.value === passwordInput.value) {
                    matchMessage.innerHTML = '✅ Passwords match';
                    matchMessage.style.color = 'green';
                } else {
                    matchMessage.innerHTML = '❌ Passwords do not match';
                    matchMessage.style.color = 'red';
                }
            } else {
                matchMessage.innerHTML = '';
            }
        });
    }
});
</script>

</body>
</html>