<?php
/* CampusCab - save_parcel.php
 * Uses the actual parcel schema. Supports Student + Staff identities in
 * the same PHP session through an explicit passenger_type field.
 */
session_start();
require_once __DIR__ . '/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: request_parcel.php');
    exit;
}

$isStudent = isset($_SESSION['student_id']) && (int)$_SESSION['student_id'] > 0;
$isStaff   = isset($_SESSION['staff_id']) && (int)$_SESSION['staff_id'] > 0;
$requestedType = strtolower(trim((string)($_POST['passenger_type'] ?? $_POST['requester_type'] ?? '')));

if (!$isStudent && !$isStaff) {
    header('Location: login.php');
    exit;
}

if ($requestedType === 'student' && $isStudent) {
    $requesterType = 'student';
} elseif ($requestedType === 'staff' && $isStaff) {
    $requesterType = 'staff';
} elseif (strtolower((string)($_SESSION['role'] ?? '')) === 'student' && $isStudent) {
    $requesterType = 'student';
} elseif (strtolower((string)($_SESSION['role'] ?? '')) === 'staff' && $isStaff) {
    $requesterType = 'staff';
} elseif ($isStudent && !$isStaff) {
    $requesterType = 'student';
} elseif ($isStaff && !$isStudent) {
    $requesterType = 'staff';
} else {
    $_SESSION['parcel_errors'] = ['Please choose Student or Staff before submitting the parcel service.'];
    header('Location: request_parcel.php');
    exit;
}

$pickup = trim((string)($_POST['pickup_location'] ?? ''));
$description = trim((string)($_POST['parcel_description'] ?? ''));
$size = trim((string)($_POST['parcel_size'] ?? ''));
$recipientName = trim((string)($_POST['recipient_name'] ?? ''));
$recipientContact = trim((string)($_POST['recipient_contact'] ?? ''));
$campusDestination = trim((string)($_POST['campus_destination'] ?? ''));
$offCampusText = trim((string)($_POST['off_campus_text'] ?? ''));
$offLat = trim((string)($_POST['off_lat'] ?? ''));
$offLng = trim((string)($_POST['off_lng'] ?? ''));
$pickupLat = trim((string)($_POST['pickup_lat'] ?? ''));
$pickupLng = trim((string)($_POST['pickup_lng'] ?? ''));
$deliveryMethod = trim((string)($_POST['delivery_method'] ?? 'On-Campus'));

$errors = [];
if ($pickup === '' || $description === '' || $size === '' || $recipientName === '' || $recipientContact === '') {
    $errors[] = 'All required fields must be filled.';
}
if (!preg_match('/^0[0-9]{9}$/', $recipientContact)) {
    $errors[] = 'Recipient cell must be 10 digits starting with 0.';
}
if (!in_array($size, ['Small','Medium','Large','Extra Large'], true)) {
    $errors[] = 'Please select a valid parcel size.';
}
if ($deliveryMethod === 'Off-Campus') {
    if ($offCampusText === '') $errors[] = 'Please search for and select an off-campus destination.';
    $destination = $offCampusText;
} else {
    if ($campusDestination === '') $errors[] = 'Please select a campus residence.';
    $destination = $campusDestination;
}

// Enforce the Alice service area for both requester types when coordinates are supplied.
$minLat = -32.88; $maxLat = -32.70; $minLng = 26.75; $maxLng = 26.95;
foreach ([
    'pickup' => [$pickupLat, $pickupLng],
    'destination' => [$offLat, $offLng]
] as $label => [$latRaw, $lngRaw]) {
    if ($latRaw !== '' || $lngRaw !== '') {
        if (!is_numeric($latRaw) || !is_numeric($lngRaw) ||
            (float)$latRaw < $minLat || (float)$latRaw > $maxLat ||
            (float)$lngRaw < $minLng || (float)$lngRaw > $maxLng) {
            $errors[] = 'Parcel pickup and destination locations must be within Alice, Eastern Cape.';
            break;
        }
    }
}

if ($errors) {
    $_SESSION['parcel_errors'] = $errors;
    header('Location: request_parcel.php?as=' . $requesterType);
    exit;
}

$priceMap = ['Small'=>20.00, 'Medium'=>30.00, 'Large'=>45.00, 'Extra Large'=>60.00];
$estimatedPrice = $priceMap[$size];

try {
    if ($requesterType === 'student') {
        $studentID = (int)$_SESSION['student_id'];
        $staffID = null;
        $sql = "INSERT INTO parcel
            (studentID, staff_id, parcel_description, parcel_size, recipient_name, recipient_contact,
             pickup_location, destination, estimated_price, parcel_status, delivery_method)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Requested', ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('iissssssds', $studentID, $staffID, $description, $size,
            $recipientName, $recipientContact, $pickup, $destination, $estimatedPrice, $deliveryMethod);
    } else {
        $studentID = null;
        $staffID = (int)$_SESSION['staff_id'];
        $sql = "INSERT INTO parcel
            (studentID, staff_id, parcel_description, parcel_size, recipient_name, recipient_contact,
             pickup_location, destination, estimated_price, parcel_status, delivery_method)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Requested', ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('iissssssds', $studentID, $staffID, $description, $size,
            $recipientName, $recipientContact, $pickup, $destination, $estimatedPrice, $deliveryMethod);
    }

    $stmt->execute();
    $stmt->close();
    $_SESSION['parcel_success'] = 'Parcel service submitted successfully!';
    header('Location: my_Parcels.php?as=' . $requesterType);
    exit;
} catch (Throwable $e) {
    error_log('CampusCab save_parcel failed: ' . $e->getMessage());
    $_SESSION['parcel_errors'] = ['Parcel could not be saved. Database error: ' . $e->getMessage()];
    header('Location: request_parcel.php?as=' . $requesterType);
    exit;
}
