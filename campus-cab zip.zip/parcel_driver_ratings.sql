CREATE TABLE IF NOT EXISTS parcel_driver_ratings (
  ratingID INT NOT NULL AUTO_INCREMENT,
  parcel INT NOT NULL,
  studentID INT NULL,
  staff_id INT NULL,
  passenger_type ENUM('student','staff') NOT NULL DEFAULT 'student',
  DriverID INT NOT NULL,
  rating TINYINT NOT NULL,
  comment VARCHAR(500) NULL,
  rated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (ratingID),
  UNIQUE KEY unique_parcel_rating (parcel),
  KEY idx_parcel_driver_ratings_driver (DriverID),
  CONSTRAINT fk_parcel_driver_rating_parcel FOREIGN KEY (parcel) REFERENCES parcel(parcel) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_parcel_driver_rating_driver FOREIGN KEY (DriverID) REFERENCES driver(DriverID) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_parcel_driver_rating_student FOREIGN KEY (studentID) REFERENCES student(studentID) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_parcel_driver_rating_staff FOREIGN KEY (staff_id) REFERENCES staff(staff_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
