-- CampusCab actual database fix for staff parcel requests.
-- The supplied actual schema currently requires parcel.studentID and
-- has a foreign key to student. Staff parcels have no student owner,
-- so studentID must be nullable and the student-only FK must be removed.

ALTER TABLE parcel
    DROP FOREIGN KEY fk_parcel_student;

ALTER TABLE parcel
    MODIFY studentID INT NULL;
