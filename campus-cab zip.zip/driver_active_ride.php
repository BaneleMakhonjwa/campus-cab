<?php
session_start();
include_once __DIR__ . '/db_connect.php';

if (!isset($_SESSION['driver_id'])) {
    header("Location: login.php");
    exit;
}

$driverID = (int)$_SESSION['driver_id'];
$rideID   = (int)($_GET['id'] ?? 0);

if ($rideID <= 0) {
    header("Location: driver_dashboard.php");
    exit;
}

$message = '';
$messageType = '';

/* =========================================================
   HANDLE ACTIONS
   ========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';

    // -------------------------------
    // VERIFY PASSENGER PIN
    // -------------------------------
    if ($action === 'verify_pin') {

        $enteredPin = trim($_POST['pin'] ?? '');

        $stmt = $conn->prepare("
            SELECT studentID, staff_id
            FROM ride 
            WHERE rideID = ? AND DriverID = ?
            LIMIT 1
        ");
        $stmt->bind_param("ii", $rideID, $driverID);
        $stmt->execute();
        $res = $stmt->get_result();
        $rideRow = $res->fetch_assoc();
        $stmt->close();

        if (!$rideRow) {
            $message = "Ride not found.";
            $messageType = "error";
        } else {
            // Determine user type + ID
            if (!empty($rideRow['studentID'])) {
                $userType = 'student';
                $userID   = (int)$rideRow['studentID'];
            } elseif (!empty($rideRow['staff_id'])) {
                $userType = 'staff';
                $userID   = (int)$rideRow['staff_id'];
            } else {
                $userType = null;
                $userID   = null;
            }

            if (!$userType) {
                $message = "Cannot verify — passenger type unknown.";
                $messageType = "error";
            } else {
                // Look up the PIN hash in safety_pin
                $pinStmt = $conn->prepare("
                    SELECT pin_hash 
                    FROM safety_pin 
                    WHERE user_type = ? AND user_id = ?
                    LIMIT 1
                ");
                $pinStmt->bind_param("si", $userType, $userID);
                $pinStmt->execute();
                $pinRes = $pinStmt->get_result();
                $pinRow = $pinRes->fetch_assoc();
                $pinStmt->close();

                if (!$pinRow) {
                    $message = "No PIN set by passenger.";
                    $messageType = "error";
                } elseif (password_verify($enteredPin, $pinRow['pin_hash'])) {
                    // PIN correct — start the ride
                    $upd = $conn->prepare("
                        UPDATE ride
                        SET ride_status = 'In Progress',
                            started_at = NOW()
                        WHERE rideID = ? AND DriverID = ?
                    ");
                    $upd->bind_param("ii", $rideID, $driverID);
                    $upd->execute();
                    $upd->close();

                    // Mark ride as verified
                    $upd2 = $conn->prepare("
    INSERT INTO ride_passenger_verification 
        (rideID, verification_status, verified_at, verified_by_driver)
    VALUES (?, 'Verified', NOW(), ?)
    ON DUPLICATE KEY UPDATE
        verification_status = 'Verified',
        verified_at = NOW(),
        verified_by_driver = VALUES(verified_by_driver)
");
$upd2->bind_param("ii", $rideID, $driverID);
$upd2->execute();
$upd2->close();

                    $message = "✅ PIN verified! Ride started.";
                    $messageType = "success";
                } else {
                    $message = "❌ Incorrect PIN. Please ask the passenger again.";
                    $messageType = "error";
                }
            }
        }
    }

    // -------------------------------
    // COMPLETE RIDE
    // -------------------------------
    elseif ($action === 'complete_ride') {

        $upd = $conn->prepare("
            UPDATE ride
            SET ride_status = 'Completed',
                Completed_at = NOW(),
                driver_earning = ROUND(COALESCE(estimated_price, 0) * 0.80, 2),
                campus_commission = ROUND(COALESCE(estimated_price, 0) * 0.20, 2)
            WHERE rideID = ? AND DriverID = ?
        ");
        $upd->bind_param("ii", $rideID, $driverID);
        $upd->execute();
        $upd->close();

        // Free up driver
        $upd2 = $conn->prepare("
            UPDATE driver 
            SET availability_status = 'Available' 
            WHERE DriverID = ?
        ");
        $upd2->bind_param("i", $driverID);
        $upd2->execute();
        $upd2->close();

        $message = "🎉 Ride completed! You are now available again.";
        $messageType = "success";
    }

    // -------------------------------
    // CANCEL RIDE (driver)
    // -------------------------------
    elseif ($action === 'cancel_ride') {

        $upd = $conn->prepare("
            UPDATE ride
            SET ride_status = 'Cancelled',
                cancelled_at = NOW(),
                cancellation_reason = 'Cancelled by driver'
            WHERE rideID = ? AND DriverID = ?
              AND ride_status IN ('Requested','Accepted','Driver Arriving','In Progress')
        ");
        $upd->bind_param("ii", $rideID, $driverID);
        $upd->execute();
        $upd->close();

        // Free up the driver
        $upd2 = $conn->prepare("UPDATE driver SET availability_status = 'Available' WHERE DriverID = ?");
        $upd2->bind_param("i", $driverID);
        $upd2->execute();
        $upd2->close();

        header("Location: driver_dashboard.php");
        exit;
    }
}

/* =========================================================
   FETCH RIDE
   ========================================================= */
$stmt = $conn->prepare("
    SELECT
        r.rideID,
        r.studentID,
        r.staff_id,
        r.request_type,
        r.parcel_details,
        r.DriverID,
        r.pickup_address,
        r.pickup_latitude,
        r.pickup_longitude,
        r.destination_address,
        r.destination_latitude,
        r.destination_longitude,
        r.requested_at,
        r.accepted_at,
        r.started_at,
        r.Completed_at,
        r.ride_status,
        r.estimated_distance_km,
        r.estimated_duration_min,
        r.estimated_price,
        s.studentFname,
        s.studentLname,
        s.studentPhoneNo,
        st.staff_name,
        st.surname,
        st.staff_phone
    FROM ride r
    LEFT JOIN student s ON r.studentID = s.studentID
    LEFT JOIN staff st ON r.staff_id = st.staff_id
    WHERE r.rideID = ? AND r.DriverID = ?
    LIMIT 1
");
$stmt->bind_param("ii", $rideID, $driverID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: driver_dashboard.php");
    exit;
}

$ride = $result->fetch_assoc();
$stmt->close();

$statusClass = strtolower(str_replace(' ', '-', $ride['ride_status']));

// Passenger details
$passengerName = 'Passenger';
$passengerPhone = '';
if ($ride['studentID']) {
    $passengerName  = trim(($ride['studentFname'] ?? '') . ' ' . ($ride['studentLname'] ?? ''));
    $passengerPhone = $ride['studentPhoneNo'] ?? '';
} elseif ($ride['staff_id']) {
    $passengerName  = trim(($ride['staff_name'] ?? '') . ' ' . ($ride['surname'] ?? ''));
    $passengerPhone = $ride['staff_phone'] ?? '';
}

$pageTitle = "Active Ride #" . $rideID;
include 'header.php';
?>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<style>
.ride-page { max-width: 1000px; margin: 0 auto; padding: 35px 25px 60px; }
.ride-back {
    display: inline-flex; align-items: center; gap: 8px;
    background: #0c2d4d; color: #fff; text-decoration: none;
    padding: 10px 16px; border-radius: 8px; font-size: 13px;
    font-weight: 600; margin-bottom: 22px;
}
.ride-back:hover { background: #185fa5; }

.ride-head {
    display: flex; justify-content: space-between; align-items: flex-start;
    gap: 20px; flex-wrap: wrap; margin-bottom: 25px;
}
.ride-head h1 { color: #0c2d4d; font-size: 28px; font-weight: 800; margin: 0 0 6px; }
.ride-head p { color: #6b7280; font-size: 14px; margin: 0; }

.status-pill {
    padding: 8px 16px; border-radius: 20px; font-size: 12px;
    font-weight: 700; text-transform: uppercase; letter-spacing: 0.4px;
}
.status-accepted    { background: #dbe8fb; color: #185fa5; }
.status-in-progress { background: #fef3c7; color: #b8860b; }
.status-completed   { background: #dcf1e9; color: #0f6e56; }
.status-cancelled   { background: #fbe2df; color: #b03a2e; }

.alert {
    padding: 14px 18px; border-radius: 10px;
    margin-bottom: 20px; font-weight: 600; font-size: 14px;
}
.alert.success { background: #dcf1e9; color: #0f6e56; border-left: 4px solid #0f6e56; }
.alert.error   { background: #fbe2df; color: #b03a2e; border-left: 4px solid #b03a2e; }

.card {
    background: #fff; border: 1px solid #e2e2dc;
    border-radius: 14px; padding: 22px;
    box-shadow: 0 4px 14px rgba(11,31,58,0.05);
    margin-bottom: 18px;
}
.card h2 {
    color: #0c2d4d; font-size: 16px; font-weight: 700;
    margin: 0 0 16px; padding-bottom: 12px;
    border-bottom: 1px solid #f0f1f3;
}

#rideMap { height: 300px; border-radius: 10px; border: 1px solid #dfe3e8; }

.detail-row {
    display: flex; justify-content: space-between;
    padding: 10px 0; font-size: 14px;
    border-bottom: 1px solid #f8f9fa;
}
.detail-row:last-child { border-bottom: none; }
.detail-row .label { color: #6b7280; font-weight: 600; font-size: 13px; }
.detail-row .value { color: #172033; font-weight: 600; text-align: right; max-width: 65%; }

.passenger-card {
    display: flex; align-items: center; gap: 14px;
    padding: 15px; background: #f8f9fa; border-radius: 10px;
    margin-bottom: 15px;
}
.passenger-avatar {
    width: 54px; height: 54px; border-radius: 50%;
    background: #0c2d4d; color: #fff;
    display: flex; align-items: center; justify-content: center;
    font-weight: 800; font-size: 18px; flex-shrink: 0;
}
.passenger-info h3 { margin: 0 0 3px; color: #0c2d4d; font-size: 16px; }
.passenger-info p { margin: 0; color: #6b7280; font-size: 13px; }

.pin-box {
    background: linear-gradient(135deg, #0c2d4d, #185fa5);
    border-radius: 14px; padding: 28px; color: #fff;
    text-align: center;
}
.pin-box h3 { margin: 0 0 8px; font-size: 18px; }
.pin-box p { margin: 0 0 20px; opacity: 0.9; font-size: 13.5px; }
.pin-input {
    width: 100%; max-width: 240px; padding: 18px;
    font-size: 32px; text-align: center; letter-spacing: 12px;
    border: none; border-radius: 10px; font-weight: 800;
    color: #0c2d4d; font-family: inherit; margin-bottom: 15px;
}
.pin-input:focus { outline: 3px solid #e0a526; }

.btn {
    width: 100%; padding: 15px; border: none;
    border-radius: 10px; font-size: 15px; font-weight: 700;
    cursor: pointer; font-family: inherit;
}
.btn-verify   { background: #e0a526; color: #0c2d4d; }
.btn-verify:hover { background: #b8860b; }
.btn-complete { background: #0f6e56; color: #fff; }
.btn-complete:hover { background: #0b5a45; }
.btn-call {
    display: inline-flex; align-items: center; justify-content: center;
    gap: 8px; width: 100%; padding: 13px; background: #185fa5;
    color: #fff; text-decoration: none; border-radius: 8px;
    font-weight: 700; font-size: 14px; margin-top: 10px;
}
.btn-call:hover { background: #134a80; }

.timeline { list-style: none; padding: 0; margin: 0; }
.timeline li {
    position: relative; padding-left: 30px;
    padding-bottom: 18px; border-left: 2px solid #e5e8ea;
    margin-left: 8px;
}
.timeline li:last-child { border-left: none; padding-bottom: 0; }
.timeline li::before {
    content: ''; position: absolute; left: -7px; top: 0;
    width: 12px; height: 12px; border-radius: 50%;
    background: #fff; border: 3px solid #e5e8ea;
}
.timeline li.done::before { background: #0f6e56; border-color: #0f6e56; }
.timeline .step-title { font-size: 13.5px; font-weight: 700; color: #0c2d4d; }
.timeline .step-time { font-size: 11.5px; color: #6b7280; margin-top: 2px; }
</style>

<div class="ride-page">

    <a href="driver_dashboard.php" class="ride-back">← Back to Dashboard</a>

    <div class="ride-head">
        <div>
            <h1>🚗 Ride #<?php echo (int)$ride['rideID']; ?></h1>
            <p>Accepted on <?php echo date('d M Y, H:i', strtotime($ride['accepted_at'])); ?></p>
        </div>
        <span class="status-pill status-<?php echo $statusClass; ?>">
            <?php echo htmlspecialchars($ride['ride_status']); ?>
        </span>
    </div>

    <?php if ($message): ?>
        <div class="alert <?php echo $messageType; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>


    <!-- ============================================
         PICKUP + PIN VERIFICATION
         ============================================ -->
    <?php if (in_array($ride['ride_status'], ['Accepted','Driver Arriving','In Progress'], true)): ?>

        <div class="card">
            <h2>📍 Arrived at Pickup?</h2>

            <div class="passenger-card">
                <div class="passenger-avatar">
                    <?php echo strtoupper(substr($passengerName, 0, 1)); ?>
                </div>
                <div class="passenger-info">
                    <h3><?php echo htmlspecialchars($passengerName); ?></h3>
                    <p><?php echo htmlspecialchars($passengerPhone); ?></p>
                </div>
            </div>

            <div class="detail-row">
                <span class="label">Pickup Location</span>
                <span class="value"><?php echo htmlspecialchars($ride['pickup_address']); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Destination</span>
                <span class="value"><?php echo htmlspecialchars($ride['destination_address']); ?></span>
            </div>

            <?php if ($passengerPhone): ?>
                <a href="tel:<?php echo htmlspecialchars($passengerPhone); ?>" class="btn-call">
                    📞 Call Passenger
                </a>
            <?php endif; ?>

            <div style="margin-top: 22px;">
                <button type="button" id="arrivedButton" class="btn btn-verify" style="width:100%;margin-bottom:14px;">📍 I've Arrived</button>
                <div id="arrivalMessage" class="alert" style="display:none;margin-bottom:14px;"></div>
                <div class="pin-box">
                    <h3>🔐 Ask for the Safety PIN</h3>
                    <p>Ask your passenger for their 4-digit PIN before starting the trip.</p>

                    <form method="POST">
                        <input 
                            type="text" 
                            name="pin" 
                            class="pin-input" 
                            maxlength="4" 
                            inputmode="numeric"
                            pattern="[0-9]{4}"
                            placeholder="0000"
                            autofocus
                            required
                        >
                        <button type="submit" name="action" value="verify_pin" class="btn btn-verify">
                            ✅ Verify PIN & Start Ride
                        </button>
                    </form>
                </div>
            </div>

            <div style="margin-top: 22px; padding-top: 22px; border-top: 1px solid #f0f1f3;">
                <form method="POST" onsubmit="return confirm('Cancel this ride?');">
                    <input type="hidden" name="action" value="cancel_ride">
                    <button type="submit" style="
                        width:100%;padding:13px;background:#b03a2e;color:#fff;
                        border:none;border-radius:8px;font-weight:700;
                        cursor:pointer;font-family:inherit;
                    ">
                        ❌ Cancel This Ride
                    </button>
                </form>
            </div>
        </div>

    <?php endif; ?>


    <!-- ============================================
         IN PROGRESS
         ============================================ -->
    <?php if ($ride['ride_status'] === 'In Progress'): ?>

        <div class="card">
            <h2>🚗 Trip in Progress</h2>

            <div class="detail-row">
                <span class="label">Passenger</span>
                <span class="value"><?php echo htmlspecialchars($passengerName); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Phone</span>
                <span class="value"><?php echo htmlspecialchars($passengerPhone); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">From</span>
                <span class="value"><?php echo htmlspecialchars($ride['pickup_address']); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">To</span>
                <span class="value"><?php echo htmlspecialchars($ride['destination_address']); ?></span>
            </div>

            <?php if ($ride['estimated_price']): ?>
                <div class="detail-row">
                    <span class="label">Fare</span>
                    <span class="value">R<?php echo number_format((float)$ride['estimated_price'], 2); ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" style="margin-top: 20px;">
                <button type="submit" name="action" value="complete_ride" class="btn btn-complete">
                    🎉 Complete Ride
                </button>
            </form>
        </div>

    <?php endif; ?>


    <!-- ============================================
         COMPLETED
         ============================================ -->
    <?php if ($ride['ride_status'] === 'Completed'): ?>

        <div class="card" style="text-align: center;">
            <h2>🎉 Ride Completed</h2>
            <p style="color:#6b7280;font-size:14px;">
                Completed on <?php echo date('d M Y, H:i', strtotime($ride['Completed_at'])); ?>
            </p>
            <a href="driver_dashboard.php" class="btn btn-verify" style="display:inline-block;text-decoration:none;margin-top:15px;padding:12px 24px;width:auto;">
                ← Back to Dashboard
            </a>
        </div>

    <?php endif; ?>


    <!-- ============================================
         MAP
         ============================================ -->
    <div class="card">
        <h2>📍 Route Map</h2>
        <div id="rideMap"></div>
    </div>


    <!-- ============================================
         TIMELINE
         ============================================ -->
    <div class="card">
        <h2>Trip Timeline</h2>
        <ul class="timeline">
            <li class="done">
                <div class="step-title">Accepted</div>
                <div class="step-time">
                    <?php echo $ride['accepted_at'] ? date('d M Y, H:i', strtotime($ride['accepted_at'])) : '—'; ?>
                </div>
            </li>
            <li class="<?php echo $ride['started_at'] ? 'done' : ''; ?>">
                <div class="step-title">Trip Started</div>
                <div class="step-time">
                    <?php echo $ride['started_at'] ? date('d M Y, H:i', strtotime($ride['started_at'])) : 'Pending PIN verification'; ?>
                </div>
            </li>
            <li class="<?php echo $ride['Completed_at'] ? 'done' : ''; ?>">
                <div class="step-title">Completed</div>
                <div class="step-time">
                    <?php echo $ride['Completed_at'] ? date('d M Y, H:i', strtotime($ride['Completed_at'])) : 'Pending'; ?>
                </div>
            </li>
        </ul>
    </div>

</div>

<script>
const pickupLat = <?php echo $ride['pickup_latitude'] ?: 'null'; ?>;
const pickupLng = <?php echo $ride['pickup_longitude'] ?: 'null'; ?>;
const destLat   = <?php echo $ride['destination_latitude'] ?: 'null'; ?>;
const destLng   = <?php echo $ride['destination_longitude'] ?: 'null'; ?>;

const map = L.map('rideMap').setView([-32.7833, 26.8448], 14);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

const bounds = [];

if (pickupLat && pickupLng) {
    L.marker([pickupLat, pickupLng])
        .addTo(map)
        .bindPopup('<strong>📍 Pickup</strong><br><?php echo addslashes($ride['pickup_address']); ?>');
    bounds.push([pickupLat, pickupLng]);
}

if (destLat && destLng) {
    L.marker([destLat, destLng])
        .addTo(map)
        .bindPopup('<strong>🎯 Destination</strong><br><?php echo addslashes($ride['destination_address']); ?>');
    bounds.push([destLat, destLng]);
}

if (bounds.length > 0) map.fitBounds(bounds, { padding: [50, 50] });
</script>
<script>
// =========================================================
// DRIVER GPS TRACKING + ARRIVAL VERIFICATION
// =========================================================
const rideID = <?php echo (int)$rideID; ?>;
const rideStatus = <?php echo json_encode($ride['ride_status']); ?>;
const pickupLat = <?php echo $ride['pickup_latitude'] !== null ? json_encode((float)$ride['pickup_latitude']) : 'null'; ?>;
const pickupLng = <?php echo $ride['pickup_longitude'] !== null ? json_encode((float)$ride['pickup_longitude']) : 'null'; ?>;

const arrivalButton = document.getElementById('arrivedButton');
const arrivalMessage = document.getElementById('arrivalMessage');

function showArrivalMessage(message, type) {
    if (!arrivalMessage) return;
    arrivalMessage.textContent = message;
    arrivalMessage.className = 'alert ' + (type === 'success' ? 'success' : 'error');
    arrivalMessage.style.display = 'block';
}

function gpsErrorMessage(error) {
    switch (error.code) {
        case 1: return 'Location permission was denied. Allow location access for this site and try again.';
        case 2: return 'Your device could not determine its location. Turn on GPS/location services and try again.';
        case 3: return 'Getting your location took too long. Move somewhere with a clearer GPS signal and try again.';
        default: return 'Your device could not provide a GPS location. Please try again.';
    }
}

function getDriverPosition() {
    return new Promise((resolve, reject) => {
        if (!window.isSecureContext && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
            reject(new Error('Browser geolocation requires HTTPS (or localhost).'));
            return;
        }
        if (!navigator.geolocation) {
            reject(new Error('This browser does not support GPS location.'));
            return;
        }

        navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: true,
            timeout: 20000,
            maximumAge: 10000
        });
    });
}

async function sendLocation() {
    if (rideStatus !== 'Accepted' && rideStatus !== 'Driver Arriving' && rideStatus !== 'In Progress') return;
    try {
        const position = await getDriverPosition();
        const body = new URLSearchParams({
            ride_id: String(rideID),
            lat: String(position.coords.latitude),
            lng: String(position.coords.longitude),
            accuracy: String(position.coords.accuracy || '')
        });
        const response = await fetch('save_driver_location.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
            credentials: 'same-origin',
            body
        });
        const data = await response.json();
        if (!data.success) console.warn('Location save failed:', data.message);
    } catch (error) {
        console.warn('GPS update failed:', error);
    }
}

async function verifyArrival() {
    if (!arrivalButton) return;
    arrivalButton.disabled = true;
    arrivalButton.textContent = '📍 Checking your location…';
    if (arrivalMessage) arrivalMessage.style.display = 'none';

    try {
        const position = await getDriverPosition();
        const body = new URLSearchParams({
            ride_id: String(rideID),
            lat: String(position.coords.latitude),
            lng: String(position.coords.longitude),
            accuracy: String(position.coords.accuracy || '')
        });
        const response = await fetch('check_driver_arrival.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
            credentials: 'same-origin',
            body
        });
        const data = await response.json();

        if (!response.ok || !data.success) {
            showArrivalMessage(data.message || 'We could not verify your location. Please try again.', 'error');
            return;
        }

        showArrivalMessage('Arrival confirmed. You are at the pickup point. Please ask the passenger for their 4-digit safety PIN.', 'success');
        arrivalButton.textContent = '✅ Arrived at Pickup';
        arrivalButton.disabled = true;
    } catch (error) {
        showArrivalMessage(error.message || 'Something went wrong while checking your location. Please try again.', 'error');
    } finally {
        if (arrivalButton && !arrivalButton.disabled) arrivalButton.textContent = '📍 I've Arrived';
    }
}

if (arrivalButton) arrivalButton.addEventListener('click', verifyArrival);
if (rideStatus === 'Accepted' || rideStatus === 'Driver Arriving' || rideStatus === 'In Progress') {
    sendLocation();
    setInterval(sendLocation, 10000);
}
</script>

<?php include 'footer.php'; ?>