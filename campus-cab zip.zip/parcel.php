<?php
// Canonical parcel-delivery entry point. The older parcel form was replaced by request_parcel.php.
header('Location: request_parcel.php');
exit;
?>
