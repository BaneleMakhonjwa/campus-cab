<?php
session_start();
include_once __DIR__ . '/db_connect.php';

$requestedAs = strtolower(trim((string)($_GET['as'] ?? '')));
$hasStudent = isset($_SESSION['student_id']) && (int)$_SESSION['student_id'] > 0;
$hasStaff = isset($_SESSION['staff_id']) && (int)$_SESSION['staff_id'] > 0;
$activeRole = strtolower(trim((string)($_SESSION['role'] ?? '')));
if ($requestedAs === 'staff' && $hasStaff) { $isStudent=false; $isStaff=true; }
elseif ($requestedAs === 'student' && $hasStudent) { $isStudent=true; $isStaff=false; }
elseif ($activeRole === 'staff' && $hasStaff) { $isStudent=false; $isStaff=true; }
elseif ($activeRole === 'student' && $hasStudent) { $isStudent=true; $isStaff=false; }
elseif ($hasStudent) { $isStudent=true; $isStaff=false; }
elseif ($hasStaff) { $isStudent=false; $isStaff=true; }
else { header('Location: login.php'); exit; }

if ($isStudent) { $userID=(int)$_SESSION['student_id']; $userColumn='studentID'; $dashboardLink='student_dashboard.php'; $context='student'; }
else { $userID=(int)$_SESSION['staff_id']; $userColumn='staff_id'; $dashboardLink='staff_dashboard.php'; $context='staff'; }

$rideID = (int)($_GET['id'] ?? 0);

if ($rideID <= 0) {
    header("Location: " . $dashboardLink);
    exit;
}

// Fetch ride
$stmt = $conn->prepare("
    SELECT
        r.*,
        d.DriverFname, d.DriverLname, d.DriverPhoneNo, d.profile_picture,
        d.vehicle_registration, d.vehicle_make, d.vehicle_model
    FROM ride r
    LEFT JOIN driver d ON r.DriverID = d.DriverID
    WHERE r.rideID = ? AND r.$userColumn = ?
    LIMIT 1
");
$stmt->bind_param("ii", $rideID, $userID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: " . $dashboardLink);
    exit;
}

$ride = $result->fetch_assoc();
$stmt->close();

$driverName = 'Waiting for a driver...';
if (!empty($ride['DriverFname'])) {
    $driverName = trim($ride['DriverFname'] . ' ' . $ride['DriverLname']);
}

$statusClass = strtolower(str_replace(' ', '-', $ride['ride_status']));
$isActive = in_array($ride['ride_status'], ['Requested', 'Accepted', 'Driver Arriving', 'In Progress']);

$pageTitle = "Trip #" . $rideID;
include 'header.php';
?>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<style>
.trip-page { max-width: 1100px; margin: 0 auto; padding: 35px 25px 60px; }
.trip-back {
    display: inline-flex; align-items: center; gap: 8px;
    background: #0c2d4d; color: #fff; text-decoration: none;
    padding: 10px 16px; border-radius: 8px; font-size: 13px;
    font-weight: 600; margin-bottom: 22px;
}
.trip-back:hover { background: #185fa5; }

.trip-head {
    display: flex; justify-content: space-between; align-items: flex-start;
    gap: 20px; flex-wrap: wrap; margin-bottom: 25px;
}
.trip-head h1 { color: #0c2d4d; font-size: 28px; font-weight: 800; margin: 0 0 6px; }
.trip-head p { color: #6b7280; font-size: 14px; margin: 0; }

.status-pill {
    padding: 8px 16px; border-radius: 20px;
    font-size: 12px; font-weight: 700;
    text-transform: uppercase; letter-spacing: 0.4px;
}
.status-requested       { background: #fbecc9; color: #8a6d00; }
.status-accepted        { background: #dbe8fb; color: #185fa5; }
.status-driver-arriving { background: #dbe8fb; color: #185fa5; }
.status-in-progress     { background: #fef3c7; color: #b8860b; }
.status-completed       { background: #dcf1e9; color: #0f6e56; }
.status-cancelled       { background: #fbe2df; color: #b03a2e; }

.trip-grid { display: grid; grid-template-columns: 1.5fr 1fr; gap: 20px; }

.card {
    background: #fff; border: 1px solid #e2e2dc;
    border-radius: 14px; padding: 22px;
    box-shadow: 0 4px 14px rgba(11,31,58,0.05);
    margin-bottom: 18px;
}
.card h2 {
    color: #0c2d4d; font-size: 16px; font-weight: 700;
    margin: 0 0 16px; padding-bottom: 12px;
    border-bottom: 1px solid #f0f1f3;
}

#tripMap { height: 320px; border-radius: 10px; border: 1px solid #dfe3e8; }

.detail-row {
    display: flex; justify-content: space-between;
    padding: 10px 0; font-size: 14px;
    border-bottom: 1px solid #f8f9fa;
}
.detail-row:last-child { border-bottom: none; }
.detail-row .label { color: #6b7280; font-weight: 600; font-size: 13px; }
.detail-row .value { color: #172033; font-weight: 600; text-align: right; max-width: 60%; }

.driver-card {
    display: flex; align-items: center;
    gap: 15px; padding: 10px 0 18px;
    border-bottom: 1px solid #f0f1f3; margin-bottom: 15px;
}
.driver-avatar {
    width: 68px; height: 68px; border-radius: 50%;
    background: #0c2d4d; color: #fff;
    display: flex; align-items: center; justify-content: center;
    font-weight: 800; font-size: 22px;
    flex-shrink: 0; overflow: hidden;
}
.driver-avatar img { width: 100%; height: 100%; object-fit: cover; }
.driver-info h3 { color: #0c2d4d; font-size: 17px; font-weight: 700; margin: 0 0 4px; }
.driver-info p { color: #6b7280; font-size: 13px; margin: 0; }

.vehicle-card {
    background: #f8f9fa; border-radius: 10px;
    padding: 14px; text-align: center;
    margin-top: 10px;
}
.vehicle-card .plate {
    display: inline-block; padding: 6px 14px;
    background: #fff; border: 2px solid #0c2d4d;
    border-radius: 6px; font-weight: 800;
    letter-spacing: 1px; color: #0c2d4d;
    font-size: 16px; margin-bottom: 8px;
}
.vehicle-card p { color: #6b7280; font-size: 13px; margin: 3px 0; }

.btn-call {
    display: flex; align-items: center; justify-content: center;
    gap: 8px; width: 100%; padding: 13px;
    background: #0f6e56; color: #fff; text-decoration: none;
    border-radius: 8px; font-weight: 700; font-size: 14px;
    margin-top: 15px;
}
.btn-call:hover { background: #0b5a45; }

.timeline { list-style: none; padding: 0; margin: 0; }
.timeline li {
    position: relative; padding-left: 30px;
    padding-bottom: 18px; border-left: 2px solid #e5e8ea;
    margin-left: 8px;
}
.timeline li:last-child { border-left: none; padding-bottom: 0; }
.timeline li::before {
    content: ''; position: absolute; left: -7px; top: 0;
    width: 12px; height: 12px; border-radius: 50%;
    background: #fff; border: 3px solid #e5e8ea;
}
.timeline li.done::before { background: #0f6e56; border-color: #0f6e56; }
.timeline li.active::before { background: #e0a526; border-color: #e0a526; }
.timeline .step-title { font-size: 13.5px; font-weight: 700; color: #0c2d4d; }
.timeline .step-time { font-size: 11.5px; color: #6b7280; margin-top: 2px; }

.price-big {
    background: #dcf1e9; border-radius: 10px;
    padding: 16px; text-align: center; margin-top: 12px;
}
.price-big .label { color: #0f6e56; font-size: 12px; font-weight: 700; text-transform: uppercase; }
.price-big .amount { color: #0f6e56; font-size: 28px; font-weight: 800; margin-top: 4px; }

.waiting-box {
    text-align: center; padding: 30px 20px;
    background: #f8fafc; border-radius: 10px;
    color: #6b7280; font-size: 14px;
}
.waiting-box .spinner {
    display: inline-block; width: 40px; height: 40px;
    border: 4px solid #e5e8ea; border-top-color: #0c2d4d;
    border-radius: 50%; animation: spin 1s linear infinite;
    margin-bottom: 12px;
}
@keyframes spin { to { transform: rotate(360deg); } }

@media (max-width: 800px) {
    .trip-grid { grid-template-columns: 1fr; }
    .trip-head h1 { font-size: 22px; }
}
</style>

<div class="trip-page">

    <a href="<?php echo $dashboardLink; ?>" class="trip-back">← Back to Dashboard</a>

    <div class="trip-head">
        <div>
            <h1>
                <?php echo $ride['request_type'] === 'Parcel' ? '📦 Parcel' : '🚗 Ride'; ?>
                #<?php echo (int)$ride['rideID']; ?>
            </h1>
            <p>Requested on <?php echo date('d M Y, H:i', strtotime($ride['requested_at'])); ?></p>
        </div>
        <span class="status-pill status-<?php echo $statusClass; ?>">
            <?php echo htmlspecialchars($ride['ride_status']); ?>
        </span>
    </div>

    <div class="trip-grid">

        <!-- LEFT COLUMN -->
        <div>

            <!-- MAP -->
            <div class="card">
                <h2>📍 Live Map</h2>
                <div id="tripMap"></div>
            </div>

            <!-- TIMELINE -->
            <div class="card">
                <h2>Trip Timeline</h2>
                <ul class="timeline">
                    <li class="done">
                        <div class="step-title">Requested</div>
                        <div class="step-time">
                            <?php echo $ride['requested_at'] ? date('d M Y, H:i', strtotime($ride['requested_at'])) : '—'; ?>
                        </div>
                    </li>
                    <li class="<?php echo $ride['accepted_at'] ? 'done' : ($isActive ? 'active' : ''); ?>">
                        <div class="step-title">Driver Accepted</div>
                        <div class="step-time">
                            <?php echo $ride['accepted_at'] ? date('d M Y, H:i', strtotime($ride['accepted_at'])) : 'Waiting...'; ?>
                        </div>
                    </li>
                    <li class="<?php echo $ride['started_at'] ? 'done' : ''; ?>">
                        <div class="step-title">Trip Started</div>
                        <div class="step-time">
                            <?php echo $ride['started_at'] ? date('d M Y, H:i', strtotime($ride['started_at'])) : 'Pending'; ?>
                        </div>
                    </li>
                    <li class="<?php echo $ride['Completed_at'] ? 'done' : ''; ?>">
                        <div class="step-title">Completed</div>
                        <div class="step-time">
                            <?php echo $ride['Completed_at'] ? date('d M Y, H:i', strtotime($ride['Completed_at'])) : 'Pending'; ?>
                        </div>
                    </li>
                    <?php if ($ride['ride_status'] === 'Cancelled'): ?>
                        <li class="done" style="border-color: #b03a2e;">
                            <div class="step-title" style="color: #b03a2e;">Cancelled</div>
                            <div class="step-time"><?php echo htmlspecialchars($ride['cancellation_reason'] ?? 'No reason given'); ?></div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>

        </div>

        <!-- RIGHT COLUMN -->
        <div>

            <!-- DRIVER -->
            <div class="card">
                <h2>Your Driver</h2>

                <?php if ($ride['DriverID']): ?>
                    <div class="driver-card">
                        <div class="driver-avatar">
                            <?php if (!empty($ride['profile_picture']) && file_exists(__DIR__ . '/' . $ride['profile_picture'])): ?>
                                <img src="<?php echo htmlspecialchars($ride['profile_picture']); ?>" alt="">
                            <?php else: ?>
                                <?php echo strtoupper(substr($ride['DriverFname'],0,1) . substr($ride['DriverLname'],0,1)); ?>
                            <?php endif; ?>
                        </div>
                        <div class="driver-info">
                            <h3><?php echo htmlspecialchars($driverName); ?></h3>
                            <p><?php echo htmlspecialchars($ride['DriverPhoneNo'] ?? '—'); ?></p>
                        </div>
                    </div>

                    <?php if (!empty($ride['vehicle_registration'])): ?>
                        <div class="vehicle-card">
                            <div class="plate"><?php echo htmlspecialchars($ride['vehicle_registration']); ?></div>
                            <p><?php echo htmlspecialchars(trim(($ride['vehicle_make'] ?? '') . ' ' . ($ride['vehicle_model'] ?? ''))); ?></p>
                            <p>Colour: <?php echo htmlspecialchars($ride['colour'] ?? '—'); ?></p>
                        </div>
                    <?php endif; ?>
                    </div>

                    <?php if ($isActive && $ride['DriverPhoneNo']): ?>
                        <a href="tel:<?php echo htmlspecialchars($ride['DriverPhoneNo']); ?>" class="btn-call">
                            📞 Call Driver
                        </a>
                    <?php endif; ?>

                <?php else: ?>
                    <div class="waiting-box">
                        <div class="spinner"></div>
                        <p>Waiting for a driver to accept your request...</p>
                    </div>
                <?php endif; ?>
                            <!-- ============================================
                 SAFETY PIN — shown to passenger
                 ============================================ -->
            <?php 
            $showPin = $_SESSION['ride_pins'][$rideID] ?? null;
            if ($showPin && in_array($ride['ride_status'], ['Requested', 'Accepted', 'Driver Arriving'])): 
            ?>
            <div class="card" style="background: linear-gradient(135deg, #0c2d4d, #185fa5); color:#fff; border:none;">
                <h2 style="color:#fff;border-bottom-color:rgba(255,255,255,0.2);">🔐 Your Safety PIN</h2>

                <p style="font-size:14px;opacity:0.9;margin:0 0 16px;text-align:center;">
                    Share this PIN with your driver <strong>only</strong> when they arrive.
                </p>

                <div style="background:rgba(255,255,255,0.15);border-radius:12px;padding:20px;text-align:center;margin-bottom:15px;">
                    <div style="font-size:44px;font-weight:800;letter-spacing:14px;padding-left:14px;color:#e0a526;">
                        <?php echo htmlspecialchars($showPin); ?>
                    </div>
                </div>

                <p style="font-size:12.5px;opacity:0.85;text-align:center;margin:0;">
                    Do not share this PIN before your driver arrives.
                </p>
            </div>
            <?php endif; ?>

            <!-- ROUTE -->
            <div class="card">
                <h2>Route</h2>
                <div class="detail-row">
                    <span class="label">Pickup</span>
                    <span class="value"><?php echo htmlspecialchars($ride['pickup_address']); ?></span>
                </div>
                <div class="detail-row">
                    <span class="label">Destination</span>
                    <span class="value"><?php echo htmlspecialchars($ride['destination_address']); ?></span>
                </div>
                <?php if ($ride['estimated_distance_km']): ?>
                    <div class="detail-row">
                        <span class="label">Distance</span>
                        <span class="value"><?php echo htmlspecialchars($ride['estimated_distance_km']); ?> km</span>
                    </div>
                <?php endif; ?>
                <?php if ($ride['estimated_duration_min']): ?>
                    <div class="detail-row">
                        <span class="label">Duration</span>
                        <span class="value">~<?php echo (int)$ride['estimated_duration_min']; ?> min</span>
                    </div>
                <?php endif; ?>

                <?php if ($ride['estimated_price']): ?>
                    <div class="price-big">
                        <div class="label">Estimated Fare</div>
                        <div class="amount">R<?php echo number_format((float)$ride['estimated_price'], 2); ?></div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- ACTIONS -->
                        <!-- ACTIONS -->
            <?php if ($isActive): ?>
                <div class="card">
                    <h2>Need Help?</h2>

                    <a href="contact.php" style="display:block;text-align:center;padding:12px;background:#185fa5;color:#fff;border-radius:8px;text-decoration:none;font-weight:700;font-size:13.5px;margin-bottom:10px;">
                        ⚠️ Report an Issue
                    </a>

                    <button type="button" 
                            onclick="openCancelModal()"
                            style="display:block;width:100%;text-align:center;padding:12px;background:#b03a2e;color:#fff;border-radius:8px;border:none;font-weight:700;font-size:13.5px;cursor:pointer;font-family:inherit;">
                        ❌ Cancel Ride
                    </button>
                </div>
            <?php endif; ?>

            <!-- ============================================
                 COMPLETED — Rate + Pay
                 ============================================ -->
            <?php if ($ride['ride_status'] === 'Completed'): ?>

                <div class="card" style="text-align: center;">

                    <h2>🎉 Ride Completed</h2>

                    <p style="color:#6b7280;font-size:14px;margin:0 0 20px;">
                        Completed on 
                        <?php echo $ride['Completed_at'] ? date('d M Y, H:i', strtotime($ride['Completed_at'])) : '—'; ?>
                    </p>

                    <?php
                    // Check if already rated
                    $rateCheck = $conn->prepare("SELECT ratingID FROM driver_ratings WHERE rideID = ? LIMIT 1");
                    $rateCheck->bind_param("i", $rideID);
                    $rateCheck->execute();
                    $alreadyRated = $rateCheck->get_result()->num_rows > 0;
                    $rateCheck->close();
                    ?>

                    <?php if ($alreadyRated): ?>
                        <p style="color:#0f6e56;font-weight:600;">
                            ✅ You've already rated this ride.
                        </p>
                    <?php else: ?>
                        <a href="rate_driver.php?ride_id=<?php echo (int)$rideID; ?>&as=<?php echo urlencode($context); ?>" 
                           style="display:inline-block;padding:14px 32px;background:#e0a526;color:#0c2d4d;border-radius:10px;text-decoration:none;font-weight:700;font-size:15px;">
                            ⭐ Rate Your Driver
                        </a>
                    <?php endif; ?>

                    <!-- PAYMENT BLOCK -->
                    <?php
                    $payCheck = $conn->prepare("SELECT payment_status FROM payment WHERE ride_id = ? LIMIT 1");
                    $payCheck->bind_param("i", $rideID);
                    $payCheck->execute();
                    $payRow = $payCheck->get_result()->fetch_assoc();
                    $isPaid = $payRow && $payRow['payment_status'] === 'Paid';
                    $payCheck->close();
                    ?>

                    <div style="margin-top: 18px; padding-top: 18px; border-top: 1px solid #f0f1f3;">
                        <?php if ($isPaid): ?>
                            <p style="color:#0f6e56;font-weight:700;font-size:14px;">
                                ✅ Paid
                            </p>
                            <a href="my_payments.php" 
                               style="display:inline-block;margin-top:8px;padding:10px 22px;background:#6b7280;color:#fff;border-radius:8px;text-decoration:none;font-weight:700;font-size:13.5px;">
                                View Receipt
                            </a>
                        <?php else: ?>
                            <p style="color:#6b7280;font-size:13.5px;margin:0 0 12px;">
                                Complete payment for this ride:
                            </p>
                            <a href="process_payment.php?ride_id=<?php echo (int)$rideID; ?>" 
                               style="display:inline-block;padding:14px 32px;background:#0f6e56;color:#fff;border-radius:10px;text-decoration:none;font-weight:700;font-size:15px;">
                                💳 Pay R<?php echo number_format((float)$ride['estimated_price'], 2); ?>
                            </a>
                        <?php endif; ?>
                    </div>

                </div>

            <?php endif; ?>

        </div>
    </div>
</div>

<?php if ($isActive): ?>
<div id="cancelModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;align-items:center;justify-content:center;padding:20px;">
  <div style="background:#fff;border-radius:14px;max-width:460px;width:100%;padding:24px;box-shadow:0 15px 40px rgba(0,0,0,.25);">
    <h2 style="margin:0 0 8px;color:#0c2d4d;">Cancel Ride</h2>
    <p style="margin:0 0 16px;color:#6b7280;font-size:14px;">Please provide a reason for cancelling this ride.</p>
    <form method="POST" action="cancel_ride.php">
      <input type="hidden" name="rideID" value="<?php echo (int)$rideID; ?>">
      <input type="hidden" name="as" value="<?php echo htmlspecialchars($context); ?>">
      <textarea name="reason" required maxlength=500 placeholder="Reason for cancellation..." style="width:100%;min-height:100px;padding:12px;border:1px solid #dfe3e8;border-radius:8px;resize:vertical;font-family:inherit;box-sizing:border-box;"></textarea>
      <div style="display:flex;gap:10px;margin-top:14px;">
        <button type="button" onclick="closeCancelModal()" style="flex:1;padding:12px;border:1px solid #dfe3e8;background:#fff;border-radius:8px;font-weight:700;cursor:pointer;">Keep Ride</button>
        <button type="submit" style="flex:1;padding:12px;border:0;background:#b03a2e;color:#fff;border-radius:8px;font-weight:700;cursor:pointer;">Confirm Cancel</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<script>
function openCancelModal(){ const m=document.getElementById('cancelModal'); if(m)m.style.display='flex'; }
function closeCancelModal(){ const m=document.getElementById('cancelModal'); if(m)m.style.display='none'; }
const pickupLat = <?php echo $ride['pickup_latitude'] ?: 'null'; ?>;
const pickupLng = <?php echo $ride['pickup_longitude'] ?: 'null'; ?>;
const destLat   = <?php echo $ride['destination_latitude'] ?: 'null'; ?>;
const destLng   = <?php echo $ride['destination_longitude'] ?: 'null'; ?>;
const rideID    = <?php echo (int)$rideID; ?>;

const map = L.map('tripMap').setView([-32.7833, 26.8448], 13);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap'
}).addTo(map);

const bounds = [];

if (pickupLat && pickupLng) {
    L.marker([pickupLat, pickupLng])
        .addTo(map)
        .bindPopup('<strong>📍 Pickup</strong><br><?php echo addslashes($ride['pickup_address']); ?>');
    bounds.push([pickupLat, pickupLng]);
}

if (destLat && destLng) {
    L.marker([destLat, destLng])
        .addTo(map)
        .bindPopup('<strong>🎯 Destination</strong><br><?php echo addslashes($ride['destination_address']); ?>');
    bounds.push([destLat, destLng]);
}

if (bounds.length > 0) {
    map.fitBounds(bounds, { padding: [50, 50] });
}

// Live driver markers. The endpoint applies the map rule for this requester:
// before/after an active ride = all online drivers; while a ride is In Progress = only the current driver.
const carIcon = L.divIcon({
    html: '<div style="background:#0c2d4d;color:#fff;border-radius:50%;width:38px;height:38px;display:flex;align-items:center;justify-content:center;font-size:21px;border:3px solid #fff;box-shadow:0 2px 9px rgba(0,0,0,.35);">🚗</div>',
    className: '', iconSize: [38,38], iconAnchor: [19,19]
});
const driverMarkers = new Map();
let lastDriverPosition = null;

async function refreshDriverMarkers() {
    try {
        const response = await fetch('get_online_drivers.php', {
            credentials: 'same-origin', cache: 'no-store'
        });
        const data = await response.json();
        if (!data.success) return;

        const seen = new Set();
        let currentPosition = null;

        data.drivers.forEach(function(driver) {
            if (driver.latitude === null || driver.longitude === null) return;
            const id = String(driver.DriverID);
            seen.add(id);
            const position = [Number(driver.latitude), Number(driver.longitude)];
            let marker = driverMarkers.get(id);

            if (!marker) {
                marker = L.marker(position, {icon: carIcon}).addTo(map);
                driverMarkers.set(id, marker);
            } else {
                marker.setLatLng(position);
            }

            const label = driver.is_current_ride_driver ? '🚗 Your current driver' : '🚗 Available driver';
            marker.bindPopup('<strong>' + label + '</strong><br>' +
                (driver.DriverFname || '') + ' ' + (driver.DriverLname || '') + '<br>' +
                (driver.vehicle_make || '') + ' ' + (driver.vehicle_model || ''));

            if (driver.is_current_ride_driver) currentPosition = position;
        });

        driverMarkers.forEach(function(marker, id) {
            if (!seen.has(id)) {
                map.removeLayer(marker);
                driverMarkers.delete(id);
            }
        });

        // When a ride is in progress, keep the current driver's car in view.
        if (currentPosition && (!lastDriverPosition ||
            map.getBounds().contains(currentPosition) === false)) {
            map.panTo(currentPosition, {animate: true, duration: 0.5});
        }
        lastDriverPosition = currentPosition;
    } catch (error) {
        console.warn('Live driver marker refresh failed', error);
    }
}

refreshDriverMarkers();
setInterval(refreshDriverMarkers, 5000);
</script>

<?php include 'footer.php'; ?>