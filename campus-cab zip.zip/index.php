<?php
session_start();
include_once __DIR__ . '/db_connect.php';

$pageTitle = "Home";
include 'header.php';

$isLoggedIn = isset($_SESSION['student_id']) || isset($_SESSION['driver_id']);
?>

<section class="cc-hero">
    <div class="cc-hero-inner">
        <div class="cc-hero-text">
            <p class="cc-hero-label">— Welcome to Campus Cab</p>
            <h1>
                Your Safe, Reliable<br>
                Ride <span>Around Campus</span>
            </h1>
            <p class="cc-hero-desc">
                Campus Cab provides safe, convenient and affordable transport
                for students and staff. Get to your destination or parcel delivered with
                ease — on time, every time
            </p>

            <div class="cc-hero-buttons">
                <a href="login.php" class="cc-btn cc-btn-primary">
                    🚗 Book a Ride
                </a>
                <a href="#quick-access" class="cc-btn cc-btn-outline">
                    ℹ️ Learn More
                </a>
            </div>
        </div>

        <div class="cc-hero-image">
            <img src="assets/images/campus-cab-vehicle.png" alt="Campus Cab Vehicle" 
             onerror="this.src='https://placehold.co/600x400/1a1a2e/f5c518?text=Campus+Cab'">
        </div>
    </div>
</section>


<!-- ================= FEATURE BAR ================= -->
<section class="cc-features">
    <div class="cc-features-grid">

        <div class="cc-feature">
            <div class="cc-feature-icon">🛡️</div>
            <div>
                <h4>Safe &amp; Secure</h4>
                <p>Our drivers are verified-approved and your safety is our priority.</p>
            </div>
        </div>

        <div class="cc-feature">
            <div class="cc-feature-icon">⏰</div>
            <div>
                <h4>On-Time Service</h4>
                <p>We get you where you need to be, when you need to be there.</p>
            </div>
        </div>

        <div class="cc-feature">
            <div class="cc-feature-icon">👥</div>
            <div>
                <h4>For Everyone</h4>
                <p>Students and staff   — all are welcome.</p>
            </div>
        </div>

        <div class="cc-feature">
            <div class="cc-feature-icon">💰</div>
            <div>
                <h4>Affordable Rides</h4>
                <p>Quality transport at student-friendly rates.</p>
            </div>
        </div>

    </div>
</section>


<!-- QUICK ACCESS -->
<section class="cc-quick" id="quick-access">
    <div class="cc-quick-header">
        <h2>Quick Access</h2>
        <p>Everything you need, just a click away.</p>
    </div>

    <div class="cc-quick-layout">

        <!-- Quick Cards -->
        <div class="cc-quick-cards">

    <a href="login.php" class="cc-quick-card">
        <div class="cc-quick-icon">🚗</div>
        <h4>Book a Ride or parcel collection</h4>
        <p>Request and track your driver in just a few clicks.</p>
        <span class="cc-quick-arrow">→</span>
    </a>

    <a href="schedule.php" class="cc-quick-card">
        <div class="cc-quick-icon">📅</div>
        <h4>View Schedule</h4>
        <p>Check routes and operating times.</p>
        <span class="cc-quick-arrow">→</span>
    </a>

    <a href="contact.php" class="cc-quick-card">
        <div class="cc-quick-icon">📞</div>
        <h4>Contact Us</h4>
        <p>Email, phone, WhatsApp and social media.</p>
        <span class="cc-quick-arrow">→</span>
    </a>

    <a href="help.php" class="cc-quick-card">
        <div class="cc-quick-icon">❓</div>
        <h4>Help Center</h4>
        <p>FAQs, safety tips and support.</p>
        <span class="cc-quick-arrow">→</span>
    </a>

</div>

        <!-- Promo Banner -->
        <div class="cc-promo">
            <div class="cc-promo-content">
                <p class="cc-promo-tagline">Moving Our</p>
                <h3>Campus Forward</h3>
                <p class="cc-promo-desc">
                    Campus Cab is more than just a ride.
                    It's a part of your campus journey.
                </p>
                <p class="cc-promo-footer">
                    🎓 Safe Rides. Brighter Futures.
                </p>
            </div>
        </div>

    </div>
</section>

<?php include 'footer.php'; ?>