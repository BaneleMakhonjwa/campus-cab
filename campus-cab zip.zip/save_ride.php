<?php
/*
 * CampusCab - save_ride.php
 * Uses the ACTUAL campus_cab_db schema.
 *
 * Student ride:
 *   studentID = logged-in student ID
 *   staff_id  = NULL
 *
 * Staff ride:
 *   studentID = NULL
 *   staff_id  = logged-in staff ID
 *
 * IMPORTANT:
 * The actual database must allow ride.studentID to be NULL for staff rides:
 *   ALTER TABLE ride MODIFY studentID INT NULL;
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: request.php');
    exit;
}

$isStudent = isset($_SESSION['student_id']) && (int)$_SESSION['student_id'] > 0;
$isStaff   = isset($_SESSION['staff_id']) && (int)$_SESSION['staff_id'] > 0;

if (!$isStudent && !$isStaff) {
    header('Location: login.php');
    exit;
}

$sessionRole = strtolower(trim((string)($_SESSION['role'] ?? '')));
$requesterType = strtolower(trim((string)($_POST['passenger_type'] ?? $_POST['requester_type'] ?? '')));

// A session may legitimately contain more than one logged-in identity. The request
// page therefore sends the identity that this particular request belongs to.
if ($requesterType === 'staff' && $isStaff) {
    $passengerType = 'staff';
} elseif ($requesterType === 'student' && $isStudent) {
    $passengerType = 'student';
} elseif ($sessionRole === 'staff' && $isStaff) {
    $passengerType = 'staff';
} elseif ($sessionRole === 'student' && $isStudent) {
    $passengerType = 'student';
} elseif ($isStaff && !$isStudent) {
    $passengerType = 'staff';
} elseif ($isStudent && !$isStaff) {
    $passengerType = 'student';
} else {
    http_response_code(403);
    exit('Please choose whether this ride is for your Student or Staff account.');
}

/*
 * Accept the names used by the latest request.php as well as the canonical
 * database-oriented names. This is important because request.php currently
 * posts pickup, pickup_lat, pickup_lng, destination, dest_lat and dest_lng.
 */
$pickupAddress = trim((string)(
    $_POST['pickup_address']
    ?? $_POST['pickup_location']
    ?? $_POST['pickup_name']
    ?? $_POST['pickup']
    ?? ''
));

$destinationAddress = trim((string)(
    $_POST['destination_address']
    ?? $_POST['destination']
    ?? $_POST['destination_name']
    ?? ''
));

$pickupLatitude = $_POST['pickup_latitude']
    ?? $_POST['pickup_lat']
    ?? null;

$pickupLongitude = $_POST['pickup_longitude']
    ?? $_POST['pickup_lng']
    ?? null;

$destinationLatitude = $_POST['destination_latitude']
    ?? $_POST['destination_lat']
    ?? $_POST['dest_lat']
    ?? null;

$destinationLongitude = $_POST['destination_longitude']
    ?? $_POST['destination_lng']
    ?? $_POST['dest_lng']
    ?? null;

$distanceKm = $_POST['estimated_distance_km']
    ?? $_POST['distance_km']
    ?? $_POST['estimated_distance']
    ?? null;

$durationMin = $_POST['estimated_duration_min']
    ?? $_POST['duration_min']
    ?? $_POST['estimated_duration']
    ?? null;

$estimatedPrice = $_POST['estimated_price']
    ?? $_POST['price']
    ?? null;

if ($pickupAddress === '' || $destinationAddress === '') {
    $_SESSION['ride_error'] = 'Please provide both pickup and destination locations.';
    header('Location: request.php');
    exit;
}

function nullableFloat($value): ?float
{
    if ($value === null || $value === '' || !is_numeric($value)) {
        return null;
    }
    return (float)$value;
}

function nullableInt($value): ?int
{
    if ($value === null || $value === '' || !is_numeric($value)) {
        return null;
    }
    return (int)$value;
}

$pickupLatitude       = nullableFloat($pickupLatitude);
$pickupLongitude      = nullableFloat($pickupLongitude);
$destinationLatitude  = nullableFloat($destinationLatitude);
$destinationLongitude = nullableFloat($destinationLongitude);
$distanceKm           = nullableFloat($distanceKm);
$durationMin          = nullableInt($durationMin);
$estimatedPrice       = nullableFloat($estimatedPrice);

// Student location requests are restricted to the Alice, Eastern Cape service area.
// Staff requests remain unrestricted.
if ($passengerType === 'student' || $passengerType === 'staff') {
    $aliceMinLat = -32.88;
    $aliceMaxLat = -32.70;
    $aliceMinLng = 26.75;
    $aliceMaxLng = 26.95;
    foreach ([
        'pickup' => [$pickupLatitude, $pickupLongitude],
        'destination' => [$destinationLatitude, $destinationLongitude]
    ] as $label => [$lat, $lng]) {
        if ($lat !== null || $lng !== null) {
            if ($lat === null || $lng === null || $lat < $aliceMinLat || $lat > $aliceMaxLat || $lng < $aliceMinLng || $lng > $aliceMaxLng) {
                $_SESSION['ride_error'] = 'Ride pickup and destination locations must be within Alice, Eastern Cape.';
                header('Location: request.php?as=student');
                exit;
            }
        }
    }
}

$studentID = $passengerType === 'student'
    ? (int)$_SESSION['student_id']
    : null;

$staffID = $passengerType === 'staff'
    ? (int)$_SESSION['staff_id']
    : null;

if ($passengerType === 'student' && $studentID <= 0) {
    http_response_code(403);
    exit('Invalid student session.');
}

if ($passengerType === 'staff' && $staffID <= 0) {
    http_response_code(403);
    exit('Invalid staff session.');
}

/* Prevent duplicate active rides for the same requester. */
$ownerColumn = $passengerType === 'student' ? 'studentID' : 'staff_id';
$ownerID     = $passengerType === 'student' ? $studentID : $staffID;

$activeSql = "
    SELECT rideID
    FROM ride
    WHERE {$ownerColumn} = ?
      AND ride_status IN ('Requested', 'Accepted', 'Driver Arriving', 'In Progress')
      AND request_type = 'ride'
    ORDER BY requested_at DESC
    LIMIT 1
";

$activeStmt = $conn->prepare($activeSql);
if (!$activeStmt) {
    error_log('CampusCab save_ride validation prepare failed: ' . $conn->error);
    $_SESSION['ride_error'] = 'Unable to validate your ride request. Please try again.';
    header('Location: request.php');
    exit;
}

$activeStmt->bind_param('i', $ownerID);
$activeStmt->execute();
$activeResult = $activeStmt->get_result();
$activeRide = $activeResult->fetch_assoc();
$activeStmt->close();

if ($activeRide) {
    $_SESSION['ride_error'] = 'You already have an active ride request.';
    header('Location: my_rides.php?as=' . $passengerType);
    exit;
}

/* Insert only columns that exist in the actual ride table. */
$sql = "
    INSERT INTO ride (
        studentID,
        staff_id,
        passenger_type,
        DriverID,
        pickup_address,
        pickup_latitude,
        pickup_longitude,
        destination_address,
        destination_latitude,
        destination_longitude,
        requested_at,
        ride_status,
        estimated_distance_km,
        estimated_duration_min,
        estimated_price,
        request_type,
        parcel_details
    ) VALUES (
        ?, ?, ?, NULL, ?, ?, ?, ?, ?, ?, NOW(), 'Requested', ?, ?, ?, 'ride', NULL
    )
";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log('CampusCab save_ride insert prepare failed: ' . $conn->error);
    $_SESSION['ride_error'] = 'Unable to submit the ride request. Please try again.';
    header('Location: request.php');
    exit;
}

/* i i s s d d s d d d i d = 12 parameters */
$stmt->bind_param(
    'iissddsdddid',
    $studentID,
    $staffID,
    $passengerType,
    $pickupAddress,
    $pickupLatitude,
    $pickupLongitude,
    $destinationAddress,
    $destinationLatitude,
    $destinationLongitude,
    $distanceKm,
    $durationMin,
    $estimatedPrice
);

try {
    if (!$stmt->execute()) {
        throw new mysqli_sql_exception($stmt->error, $stmt->errno);
    }

    $rideID = (int)$conn->insert_id;
    $stmt->close();

    // Every requester needs a passenger PIN before a driver can start the ride.
    // Create one automatically if this account does not already have one.
    $pinType = $passengerType;
    $pinUserID = $passengerType === 'student' ? $studentID : $staffID;
    $pinStmt = $conn->prepare('SELECT pin_id, pin_hash FROM safety_pin WHERE user_type = ? AND user_id = ? LIMIT 1');
    if ($pinStmt) {
        $pinStmt->bind_param('si', $pinType, $pinUserID);
        $pinStmt->execute();
        $pinRow = $pinStmt->get_result()->fetch_assoc();
        $pinStmt->close();
        if (!$pinRow || empty($pinRow['pin_hash'])) {
            $plainPin = (string)random_int(1000, 9999);
            $pinHash = password_hash($plainPin, PASSWORD_DEFAULT);
            if ($pinRow) {
                $up = $conn->prepare('UPDATE safety_pin SET pin_hash = ?, updated_at = NOW() WHERE pin_id = ?');
                if ($up) { $up->bind_param('si', $pinHash, $pinRow['pin_id']); $up->execute(); $up->close(); }
            } else {
                $up = $conn->prepare('INSERT INTO safety_pin (user_type, user_id, pin_hash) VALUES (?, ?, ?)');
                if ($up) { $up->bind_param('sis', $pinType, $pinUserID, $pinHash); $up->execute(); $up->close(); }
            }
            $_SESSION['new_safety_pin'] = $plainPin;
            $_SESSION['new_safety_pin_type'] = $passengerType;
        }
    }

    /* Notification is optional; a notification failure must not undo the ride. */
    $notificationMessage = 'Ride requested. Waiting for a driver to accept your request.';

    $notificationSql = "
        INSERT INTO notifications (
            student_id,
            staff_id,
            driver_id,
            ride_id,
            parcel_id,
            notification_type,
            message,
            is_read,
            created_at
        ) VALUES (?, ?, NULL, ?, NULL, 'ride_requested', ?, 0, NOW())
    ";

    $notificationStmt = $conn->prepare($notificationSql);
    if ($notificationStmt) {
        $notificationStmt->bind_param(
            'iiis',
            $studentID,
            $staffID,
            $rideID,
            $notificationMessage
        );
        $notificationStmt->execute();
        $notificationStmt->close();
    }

    $_SESSION['ride_success'] = 'Your ride request has been submitted successfully.';

    /* Successful request goes to My Rides, not back to the request form. */
    header('Location: my_rides.php?as=' . $passengerType);
    exit;

} catch (Throwable $e) {
    if ($stmt) {
        $stmt->close();
    }

    error_log('CampusCab save_ride.php failed: ' . $e->getMessage());

    $_SESSION['ride_error'] =
        'Unable to submit the ride request. Please check your ride details and try again.';

    header('Location: request.php');
    exit;
}
?>
