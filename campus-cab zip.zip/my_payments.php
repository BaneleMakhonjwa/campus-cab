<?php
session_start();
include_once __DIR__ . '/db_connect.php';

$isStudent = isset($_SESSION['student_id']);
$isStaff   = isset($_SESSION['staff_id']);

if (!$isStudent && !$isStaff) {
    header('Location: login.php');
    exit;
}

$userID = $isStudent ? (int)$_SESSION['student_id'] : (int)$_SESSION['staff_id'];
$userColumn = $isStudent ? 'studentID' : 'staff_id';
$dashboardLink = $isStudent ? 'student_dashboard.php' : 'staff_dashboard.php';

$rows = [];

// Ride payments: payment.ride_id -> ride.rideID -> requester.
$stmt = $conn->prepare("
    SELECT
        p.payment_id AS payment_id,
        p.ride_id AS item_id,
        'Ride' AS item_type,
        p.item_cost,
        p.delivery_fee,
        p.total_amount,
        p.payment_method,
        p.payment_status,
        p.paid_at,
        r.pickup_address AS origin,
        r.destination_address AS destination
    FROM payment p
    INNER JOIN ride r ON p.ride_id = r.rideID
    WHERE r.$userColumn = ?
");
$stmt->bind_param('i', $userID);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
}
$stmt->close();

// Parcel payments: parcel_payment.parcel -> parcel.parcel -> requester.
$stmt = $conn->prepare("
    SELECT
        pp.payment_id AS payment_id,
        pp.parcel AS item_id,
        'Parcel' AS item_type,
        pp.item_cost,
        pp.delivery_fee,
        pp.total_amount,
        pp.payment_method,
        pp.payment_status,
        pp.paid_at,
        p.pickup_location AS origin,
        p.destination AS destination
    FROM parcel_payment pp
    INNER JOIN parcel p ON pp.parcel = p.parcel
    WHERE p.$userColumn = ?
");
$stmt->bind_param('i', $userID);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
}
$stmt->close();

usort($rows, static function ($a, $b) {
    $aTime = $a['paid_at'] ?? '';
    $bTime = $b['paid_at'] ?? '';
    $cmp = strcmp($bTime, $aTime);
    if ($cmp !== 0) {
        return $cmp;
    }
    return (int)$b['payment_id'] <=> (int)$a['payment_id'];
});

$totalSpent = 0.0;
$cardCount = 0;
$cashCount = 0;
foreach ($rows as $row) {
    if (strcasecmp((string)$row['payment_status'], 'Paid') === 0) {
        $totalSpent += (float)$row['total_amount'];
    }
    if (strcasecmp((string)$row['payment_method'], 'Card') === 0) {
        $cardCount++;
    }
    if (strcasecmp((string)$row['payment_method'], 'Cash') === 0) {
        $cashCount++;
    }
}

$pageTitle = 'Payment History';
include 'header.php';
?>

<style>
.pay-page { max-width: 900px; margin: 0 auto; padding: 35px 25px 60px; }
.pay-head { display: flex; justify-content: space-between; align-items: center; gap: 15px; flex-wrap: wrap; margin-bottom: 25px; }
.pay-head h1 { color: #0c2d4d; font-size: 28px; font-weight: 800; margin: 0; }
.btn { padding: 11px 20px; border-radius: 8px; text-decoration: none; font-weight: 700; font-size: 14px; }
.btn-primary { background: #0c2d4d; color: #fff; }
.btn-primary:hover { background: #185fa5; }
.stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 25px; }
.stat-card { background: #fff; padding: 20px; border-radius: 12px; text-align: center; border: 1px solid #e2e2dc; box-shadow: 0 4px 14px rgba(11,31,58,0.05); }
.stat-card .number { font-size: 22px; font-weight: 800; color: #0c2d4d; }
.stat-card .label { font-size: 11px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.4px; margin-top: 6px; font-weight: 700; }
.empty { background: #fff; border: 1px solid #e2e2dc; border-radius: 14px; padding: 60px 30px; text-align: center; color: #6b7280; }
.empty .icon { font-size: 50px; display: block; margin-bottom: 15px; }
.empty h3 { color: #0c2d4d; margin: 0 0 8px; }
.pay-card { background: #fff; border: 1px solid #e2e2dc; border-radius: 12px; padding: 20px; margin-bottom: 14px; box-shadow: 0 4px 14px rgba(11,31,58,0.05); }
.pay-card-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; padding-bottom: 12px; border-bottom: 1px solid #f0f1f3; margin-bottom: 12px; }
.pay-card-head h3 { color: #0c2d4d; font-size: 15px; margin: 0; }
.type-pill { padding: 4px 10px; border-radius: 20px; font-size: 10px; font-weight: 800; text-transform: uppercase; background: #e8eef7; color: #185fa5; }
.pay-status { padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
.pay-status.paid { background: #dcf1e9; color: #0f6e56; }
.pay-status.pending { background: #fbecc9; color: #8a6d00; }
.pay-status.failed { background: #fbe2df; color: #b03a2e; }
.detail-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 13.5px; gap: 15px; }
.detail-row .label { color: #6b7280; font-weight: 600; }
.detail-row .value { color: #172033; text-align: right; max-width: 70%; }
.detail-row.amount .value { color: #0f6e56; font-weight: 800; font-size: 16px; }
@media (max-width: 600px) { .stats { grid-template-columns: 1fr; } .detail-row { flex-direction: column; gap: 2px; } .detail-row .value { text-align: left; max-width: 100%; } }
</style>

<div class="pay-page">
    <div class="pay-head">
        <h1>📜 Payment History</h1>
        <a href="<?php echo htmlspecialchars($dashboardLink); ?>" class="btn btn-primary">← Back to Dashboard</a>
    </div>

    <div class="stats">
        <div class="stat-card">
            <div class="number">R<?php echo number_format($totalSpent, 2); ?></div>
            <div class="label">Total Paid</div>
        </div>
        <div class="stat-card">
            <div class="number"><?php echo $cardCount; ?></div>
            <div class="label">Card Payments</div>
        </div>
        <div class="stat-card">
            <div class="number"><?php echo $cashCount; ?></div>
            <div class="label">Cash Payments</div>
        </div>
    </div>

    <?php if (empty($rows)): ?>
        <div class="empty">
            <span class="icon">📭</span>
            <h3>No payment history yet</h3>
            <p>Complete a ride or parcel payment to see it here.</p>
        </div>
    <?php else: ?>
        <?php foreach ($rows as $p): ?>
            <?php $statusClass = strtolower(preg_replace('/[^a-z0-9]+/i', '-', (string)$p['payment_status'])); ?>
            <div class="pay-card">
                <div class="pay-card-head">
                    <div>
                        <h3><?php echo $p['item_type'] === 'Ride' ? 'Receipt for Ride #' : 'Receipt for Parcel #'; ?><?php echo (int)$p['item_id']; ?></h3>
                        <span class="type-pill"><?php echo htmlspecialchars($p['item_type']); ?></span>
                    </div>
                    <span class="pay-status <?php echo htmlspecialchars($statusClass); ?>">
                        <?php echo htmlspecialchars($p['payment_status']); ?>
                    </span>
                </div>

                <div class="detail-row">
                    <span class="label">Route</span>
                    <span class="value">
                        <?php echo htmlspecialchars((string)$p['origin']); ?>
                        →
                        <?php echo htmlspecialchars((string)$p['destination']); ?>
                    </span>
                </div>

                <div class="detail-row">
                    <span class="label">Method</span>
                    <span class="value"><?php echo htmlspecialchars((string)$p['payment_method']); ?></span>
                </div>

                <div class="detail-row">
                    <span class="label">Date</span>
                    <span class="value">
                        <?php echo !empty($p['paid_at']) ? date('d M Y, H:i', strtotime($p['paid_at'])) : '—'; ?>
                    </span>
                </div>

                <div class="detail-row amount">
                    <span class="label">Amount</span>
                    <span class="value">R<?php echo number_format((float)$p['total_amount'], 2); ?></span>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>
