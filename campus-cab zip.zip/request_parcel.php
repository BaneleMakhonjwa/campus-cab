<?php
session_start();
include_once __DIR__ . '/db_connect.php';

$requestedAs = strtolower(trim((string)($_GET['as'] ?? $_POST['passenger_type'] ?? '')));
$isStudent = isset($_SESSION['student_id']) && (int)$_SESSION['student_id'] > 0;
$isStaff   = isset($_SESSION['staff_id']) && (int)$_SESSION['staff_id'] > 0;
if (!$isStudent && !$isStaff) { header('Location: login.php'); exit; }

if ($requestedAs === 'staff' && $isStaff) {
    $userID = (int)$_SESSION['staff_id'];
    $dashboardLink = 'staff_dashboard.php';
    $parcelRequester = 'staff';
} elseif ($requestedAs === 'student' && $isStudent) {
    $userID = (int)$_SESSION['student_id'];
    $dashboardLink = 'student_dashboard.php';
    $parcelRequester = 'student';
} elseif (strtolower((string)($_SESSION['role'] ?? '')) === 'staff' && $isStaff) {
    $userID = (int)$_SESSION['staff_id'];
    $dashboardLink = 'staff_dashboard.php';
    $parcelRequester = 'staff';
} elseif ($isStudent) {
    $userID = (int)$_SESSION['student_id'];
    $dashboardLink = 'student_dashboard.php';
    $parcelRequester = 'student';
} else {
    $userID = (int)$_SESSION['staff_id'];
    $dashboardLink = 'staff_dashboard.php';
    $parcelRequester = 'staff';
}
$aliceOnlySearch = true;

$locations = [];
$result = $conn->query("SELECT location_id, name, latitude, longitude FROM campus_location ORDER BY name");
while ($row = $result->fetch_assoc()) $locations[] = $row;

$pageTitle = 'Parcel Services';
include 'header.php';
?>
<style>
.parcel-page{max-width:900px;margin:0 auto;padding:35px 25px 60px}.parcel-header h1{color:#0c2d4d;font-size:28px;font-weight:800;margin:0 0 6px}.parcel-header p{color:#6b7280;font-size:15px;margin:0 0 30px}.parcel-card,.driver-card{background:#fff;border:1px solid #e2e2dc;border-radius:14px;padding:30px;box-shadow:0 4px 14px rgba(11,31,58,.05);margin-bottom:20px}.parcel-section-title{color:#0c2d4d;font-size:16px;font-weight:700;margin:0 0 16px;padding-bottom:10px;border-bottom:1px solid #f0f1f3}.form-group{margin-bottom:18px}.form-group label{display:block;font-weight:600;font-size:14px;color:#0c2d4d;margin-bottom:6px}.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px;border:1px solid #dfe3e8;border-radius:8px;font-size:15px;font-family:inherit;box-sizing:border-box}.form-group small{display:block;color:#6b7280;font-size:12px;margin-top:5px}.form-row{display:grid;grid-template-columns:1fr 1fr;gap:15px}.toggle-row{display:flex;gap:10px;margin-bottom:18px}.toggle-btn{cursor:pointer;flex:1;padding:12px;border:2px solid #dfe3e8;background:#fff;border-radius:8px;cursor:pointer;font-weight:600;font-size:14px;color:#6b7280}.toggle-btn.active{border-color:#0c2d4d;background:#0c2d4d;color:#fff}.location-results{display:none;position:relative;z-index:1000;border:1px solid #dfe3e8;border-top:none;border-radius:0 0 8px 8px;background:#fff;box-shadow:0 6px 14px rgba(11,31,58,.12);max-height:240px;overflow-y:auto}.location-result{padding:10px 12px;cursor:pointer;border-bottom:1px solid #f0f1f3}.location-result:hover{background:#f5f8fb}.location-result small{display:block;color:#6b7280;font-size:11px;margin-top:3px}.btn-submit{width:100%;padding:14px;background:#0c2d4d;color:#fff;border:none;border-radius:8px;font-size:15px;font-weight:700;cursor:pointer;margin-top:10px}.btn-back{display:inline-block;padding:10px 18px;background:#6b7280;color:#fff;text-decoration:none;border-radius:8px;font-size:13px;font-weight:600;margin-bottom:20px}@media(max-width:600px){.form-row{grid-template-columns:1fr}.parcel-card,.driver-card{padding:20px}}
</style>
<div class="parcel-page">
<a href="<?php echo htmlspecialchars($dashboardLink); ?>" class="btn-back">← Back to Dashboard</a>
<div class="parcel-header"><h1>📦 Parcel Services</h1><p>Have a parcel collected from campus and delivered to your chosen destination.</p></div>
<?php if (!empty($_SESSION['parcel_errors'])): ?>
<div style="max-width:900px;margin:0 auto 18px;padding:14px 18px;background:#fff1f1;border:1px solid #e3a1a1;border-radius:10px;color:#8a1c1c;font-weight:600;">
<?php foreach ($_SESSION['parcel_errors'] as $parcelError): ?>
<div>⚠️ <?php echo htmlspecialchars($parcelError); ?></div>
<?php endforeach; unset($_SESSION['parcel_errors']); ?>
</div>
<?php endif; ?>
<form method="POST" action="save_parcel.php" id="parcelForm">
<input type="hidden" name="passenger_type" value="<?php echo htmlspecialchars($parcelRequester ?? (strtolower((string)($_SESSION['role'] ?? 'student')) === 'staff' ? 'staff' : 'student')); ?>">
<div class="parcel-card">
<h2 class="parcel-section-title">📍 Pickup Point</h2>
<div class="form-group">
<label for="pickupSearch">Search for a pickup location</label>
<input type="text" id="pickupSearch" placeholder="Search an address, place or landmark in Alice..." autocomplete="off">
<div id="pickupResults" class="location-results"></div>
<small>Search for a location, or choose a campus residence/saved campus location below.</small>
</div>
<div class="form-group">
<label for="pickupCampus">Campus residences / saved campus locations</label>
<select id="pickupCampus">
<option value="">-- Select Campus Location --</option>
<?php foreach($locations as $loc): ?><option value="<?php echo htmlspecialchars($loc['name']); ?>" data-lat="<?php echo htmlspecialchars($loc['latitude']); ?>" data-lng="<?php echo htmlspecialchars($loc['longitude']); ?>"><?php echo htmlspecialchars($loc['name']); ?></option><?php endforeach; ?>
<option value="Main Gate">Main Gate</option><option value="Courier Guy Offices">Courier Guy Offices</option><option value="Post Office">Post Office</option>
</select>
<input type="hidden" id="pickup_location" name="pickup_location" required>
<input type="hidden" id="pickup_lat" name="pickup_lat"><input type="hidden" id="pickup_lng" name="pickup_lng">
</div>
</div>
<div class="parcel-card">
<h2 class="parcel-section-title">📦 Parcel Details</h2>
<div class="form-group"><label for="parcel_description">Parcel Description *</label><textarea id="parcel_description" name="parcel_description" rows="3" placeholder="e.g., Small box with books" required></textarea></div>
<div class="form-row"><div class="form-group"><label for="parcel_size">Parcel Size *</label><select id="parcel_size" name="parcel_size" required><option value="">-- Select Size --</option><option>Small</option><option>Medium</option><option>Large</option><option>Extra Large</option></select></div><div class="form-group"><label for="recipient_contact">Recipient Cell *</label><input type="tel" id="recipient_contact" name="recipient_contact" placeholder="0712345678" maxlength="10" required></div></div>
<div class="form-group"><label for="recipient_name">Recipient Name *</label><input type="text" id="recipient_name" name="recipient_name" placeholder="Who receives the parcel?" required></div>
</div>
<div class="parcel-card">
<h2 class="parcel-section-title">🎯 Destination</h2>
<div class="toggle-row"><button type="button" class="toggle-btn active" id="btnOnCampus">🏠 On Campus</button><button type="button" class="toggle-btn" id="btnOffCampus">🗺️ Off Campus</button></div>
<div id="onCampusBlock"><div class="form-group"><label for="campus_destination">Campus residences / saved campus locations *</label><select id="campus_destination" name="campus_destination"><option value="">-- Select Campus Location --</option><?php foreach($locations as $loc): ?><option value="<?php echo htmlspecialchars($loc['name']); ?>" data-lat="<?php echo htmlspecialchars($loc['latitude']); ?>" data-lng="<?php echo htmlspecialchars($loc['longitude']); ?>"><?php echo htmlspecialchars($loc['name']); ?></option><?php endforeach; ?></select></div></div>
<div id="offCampusBlock" style="display:none"><div class="form-group"><label for="offCampusSearch">Search for an off-campus destination *</label><input type="text" id="offCampusSearch" placeholder="Search an address, place or landmark in Alice..." autocomplete="off"><div id="destinationResults" class="location-results"></div><small>Start typing at least 3 characters, then select your destination from the results.</small></div><input type="hidden" id="off_lat" name="off_lat"><input type="hidden" id="off_lng" name="off_lng"><input type="hidden" id="off_campus_text" name="off_campus_text"><input type="hidden" id="delivery_method" name="delivery_method" value="On-Campus"></div>
</div>
<button type="submit" class="btn-submit">✅ Submit Parcel Service</button>
</form></div>
<script>
const ALICE_VIEWBOX = '26.75,-32.70,26.95,-32.88';
const ALICE_ONLY_SEARCH = <?php echo $aliceOnlySearch ? 'true' : 'false'; ?>;

function esc(v) {
    return String(v).replace(/[&<>'"]/g, c => ({
        '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;'
    }[c]));
}

function setPickup(name, lat = '', lng = '') {
    document.getElementById('pickup_location').value = name || '';
    document.getElementById('pickupSearch').value = name || '';
    document.getElementById('pickup_lat').value = lat;
    document.getElementById('pickup_lng').value = lng;
    document.getElementById('pickupCampus').value = '';
    document.getElementById('pickupResults').style.display = 'none';
}

function setDestination(type) {
    const onCampus = type === 'oncampus';
    const onBtn = document.getElementById('btnOnCampus');
    const offBtn = document.getElementById('btnOffCampus');
    const onBlock = document.getElementById('onCampusBlock');
    const offBlock = document.getElementById('offCampusBlock');
    const method = document.getElementById('delivery_method');

    onBtn.classList.toggle('active', onCampus);
    offBtn.classList.toggle('active', !onCampus);
    onBlock.style.display = onCampus ? 'block' : 'none';
    offBlock.style.display = onCampus ? 'none' : 'block';
    method.value = onCampus ? 'On-Campus' : 'Off-Campus';

    if (onCampus) {
        document.getElementById('off_campus_text').value = '';
        document.getElementById('off_lat').value = '';
        document.getElementById('off_lng').value = '';
    } else {
        document.getElementById('campus_destination').value = '';
        setTimeout(() => document.getElementById('offCampusSearch').focus(), 50);
    }
}

function setupSearch(inputId, resultsId, type) {
    const input = document.getElementById(inputId);
    const results = document.getElementById(resultsId);
    let timer = null;

    input.addEventListener('input', function () {
        clearTimeout(timer);
        const q = input.value.trim();

        if (type === 'pickup') {
            document.getElementById('pickup_location').value = '';
            document.getElementById('pickupCampus').value = '';
        } else {
            document.getElementById('off_campus_text').value = '';
            document.getElementById('off_lat').value = '';
            document.getElementById('off_lng').value = '';
        }

        if (q.length < 3) {
            results.innerHTML = '';
            results.style.display = 'none';
            return;
        }

        timer = setTimeout(async () => {
            try {
                const params = new URLSearchParams({
                    format: 'json',
                    q: ALICE_ONLY_SEARCH ? (q + ', Alice, Eastern Cape, South Africa') : q,
                    countrycodes: 'za',
                    limit: '5',
                    addressdetails: '1'
                });
                if (ALICE_ONLY_SEARCH) {
                    params.set('bounded', '1');
                    params.set('viewbox', ALICE_VIEWBOX);
                }

                const response = await fetch(
                    'https://nominatim.openstreetmap.org/search?' + params.toString(),
                    { headers: { 'Accept': 'application/json', 'Accept-Language': 'en' } }
                );
                if (!response.ok) throw new Error('Search failed');

                const data = await response.json();
                results.innerHTML = '';

                if (!data.length) {
                    results.innerHTML = '<div class="location-result">No locations found. Try a different search.</div>';
                    results.style.display = 'block';
                    return;
                }

                data.forEach(place => {
                    const item = document.createElement('div');
                    item.className = 'location-result';
                    item.innerHTML = '<strong>' + esc(place.display_name.split(',').slice(0,2).join(', ')) +
                        '</strong><small>' + esc(place.display_name) + '</small>';

                    item.addEventListener('mousedown', function (event) {
                        event.preventDefault();
                    });

                    item.addEventListener('click', function () {
                        if (type === 'pickup') {
                            setPickup(place.display_name, place.lat, place.lon);
                        } else {
                            document.getElementById('off_campus_text').value = place.display_name;
                            document.getElementById('off_lat').value = place.lat;
                            document.getElementById('off_lng').value = place.lon;
                            input.value = place.display_name;
                            results.style.display = 'none';
                        }
                    });
                    results.appendChild(item);
                });

                results.style.display = 'block';
            } catch (error) {
                results.innerHTML = '<div class="location-result">Location search is temporarily unavailable.</div>';
                results.style.display = 'block';
            }
        }, 400);
    });

    document.addEventListener('click', function (event) {
        if (event.target !== input && !results.contains(event.target)) {
            results.style.display = 'none';
        }
    });
}

document.getElementById('btnOnCampus').addEventListener('click', function (event) {
    event.preventDefault();
    event.stopPropagation();
    setDestination('oncampus');
});

document.getElementById('btnOffCampus').addEventListener('click', function (event) {
    event.preventDefault();
    event.stopPropagation();
    setDestination('offcampus');
});

document.getElementById('pickupCampus').addEventListener('change', function () {
    const option = this.options[this.selectedIndex];
    if (this.value) setPickup(option.textContent.trim(), option.dataset.lat || '', option.dataset.lng || '');
});

document.getElementById('campus_destination').addEventListener('change', function () {
    if (this.value) {
        const option = this.options[this.selectedIndex];
        document.getElementById('off_campus_text').value = this.value;
        document.getElementById('off_lat').value = option.dataset.lat || '';
        document.getElementById('off_lng').value = option.dataset.lng || '';
    }
});

setupSearch('pickupSearch', 'pickupResults', 'pickup');
setupSearch('offCampusSearch', 'destinationResults', 'destination');

document.getElementById('parcelForm').addEventListener('submit', function (event) {
    if (!document.getElementById('pickup_location').value) {
        event.preventDefault();
        alert('Please select or search for a pickup location.');
        return;
    }

    const method = document.getElementById('delivery_method').value;
    const campusDestination = document.getElementById('campus_destination').value.trim();
    const destinationText = document.getElementById('off_campus_text').value.trim();

    // On-campus destinations must come from the campus-residence selector.
    // Off-campus destinations must come from the location search.
    // Do not reject a valid selection because the other destination control is empty.
    if (method === 'On-Campus' && !campusDestination) {
        event.preventDefault();
        alert('Please select a campus residence for the destination.');
        return;
    }

    if (method === 'Off-Campus' && !destinationText) {
        event.preventDefault();
        alert('Please search for and select an off-campus destination.');
    }
});
</script>
<?php include 'footer.php'; ?>
