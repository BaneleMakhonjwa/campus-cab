<?php
session_start();
$role = $_SESSION['role'] ?? '';
$routes = ['student'=>'student_dashboard.php','staff'=>'staff_dashboard.php','driver'=>'driver_dashboard.php','admin'=>'admin_dashboard.php'];
header('Location: ' . ($routes[$role] ?? 'login.php'));
exit;
?>