<?php
session_start();
if (empty($_SESSION['staff_id'])) { header('Location: login.php?role=staff'); exit; }
$id=(int)($_GET['id'] ?? $_GET['ride_id'] ?? 0);
if ($id<=0) { header('Location: my_rides.php?as=staff'); exit; }
header('Location: trip.php?id='.$id.'&as=staff');
exit;
