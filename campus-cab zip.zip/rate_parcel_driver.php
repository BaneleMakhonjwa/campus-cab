<?php
session_start();
require_once __DIR__ . '/db_connect.php';

$requestedAs = strtolower(trim((string)($_GET['as'] ?? $_POST['as'] ?? '')));
$hasStudent = !empty($_SESSION['student_id']);
$hasStaff = !empty($_SESSION['staff_id']);
$activeRole = strtolower(trim((string)($_SESSION['role'] ?? '')));
if ($requestedAs === 'staff' && $hasStaff) $context='staff';
elseif ($requestedAs === 'student' && $hasStudent) $context='student';
elseif ($activeRole === 'staff' && $hasStaff) $context='staff';
elseif ($activeRole === 'student' && $hasStudent) $context='student';
elseif ($hasStudent) $context='student';
elseif ($hasStaff) $context='staff';
else { header('Location: login.php'); exit; }

$userID = $context === 'student' ? (int)$_SESSION['student_id'] : (int)$_SESSION['staff_id'];
$parcelID = (int)($_GET['parcel_id'] ?? $_POST['parcel_id'] ?? 0);
if ($parcelID <= 0) { header('Location: my_Parcels.php?as='.$context); exit; }

$ownerColumn = $context === 'student' ? 'p.studentID' : 'p.staff_id';
$stmt=$conn->prepare("SELECT p.parcel AS parcelID,p.DriverID,p.parcel_status,p.recipient_name,d.DriverFname,d.DriverLname,d.profile_picture FROM parcel p LEFT JOIN driver d ON p.DriverID=d.DriverID WHERE p.parcel=? AND $ownerColumn=? AND p.parcel_status='Delivered' LIMIT 1");
$stmt->bind_param('ii',$parcelID,$userID); $stmt->execute(); $res=$stmt->get_result();
if(!$res || $res->num_rows===0){$stmt->close();header('Location: my_Parcels.php?as='.$context);exit;}
$parcel=$res->fetch_assoc(); $stmt->close();

$check=$conn->prepare('SELECT ratingID FROM parcel_driver_ratings WHERE parcel=? LIMIT 1');
$check->bind_param('i',$parcelID);$check->execute();$already=$check->get_result()->num_rows>0;$check->close();
if($already){$_SESSION['parcel_success']='This parcel has already been rated.';header('Location: my_Parcels.php?as='.$context);exit;}

$message='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $rating=(int)($_POST['rating']??0); $comment=trim($_POST['comment']??'');
  if($rating<1||$rating>5)$message='Please choose a rating between 1 and 5 stars.';
  else{
    $studentID=$context==='student'?$userID:null; $staffID=$context==='staff'?$userID:null; $type=$context;
    $ins=$conn->prepare('INSERT INTO parcel_driver_ratings (parcel,studentID,staff_id,passenger_type,DriverID,rating,comment,rated_at) VALUES (?,?,?,?,?,?,?,NOW())');
    $ins->bind_param('iiisiss',$parcelID,$studentID,$staffID,$type,$parcel['DriverID'],$rating,$comment);
    if($ins->execute()){ $ins->close(); $_SESSION['parcel_success']='Thank you for rating your parcel delivery driver!'; header('Location: my_Parcels.php?as='.$context); exit; }
    $message='Failed to save rating: '.($conn->error); $ins->close();
  }
}
$pageTitle='Rate Parcel Driver'; include 'header.php';
?>
<style>.rate-page{max-width:600px;margin:0 auto;padding:45px 20px}.rate-card{background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:28px;box-shadow:0 4px 14px rgba(11,31,58,.05)}.stars{display:flex;gap:8px;margin:18px 0}.stars input{display:none}.stars label{font-size:38px;color:#d1d5db;cursor:pointer}.stars label:hover,.stars input:checked+label{color:#e0a526}.comment{width:100%;min-height:120px;border:1px solid #d1d5db;border-radius:9px;padding:12px;box-sizing:border-box}.btn{margin-top:16px;width:100%;border:0;border-radius:9px;padding:13px;background:#0c2d4d;color:#fff;font-weight:700;cursor:pointer}.back{display:inline-block;margin-bottom:18px;color:#0c2d4d;font-weight:700;text-decoration:none}.error{background:#fde8e6;color:#a1261d;padding:12px;border-radius:8px;margin-bottom:15px}</style>
<div class="rate-page"><a class="back" href="my_Parcels.php?as=<?php echo htmlspecialchars($context); ?>">← Back to Parcel Services</a><div class="rate-card"><h1>Rate Your Parcel Driver</h1><p>Parcel #<?php echo $parcelID; ?> · <?php echo htmlspecialchars(trim(($parcel['DriverFname']??'').' '.($parcel['DriverLname']??''))); ?></p><?php if($message): ?><div class="error"><?php echo htmlspecialchars($message); ?></div><?php endif; ?><form method="post"><input type="hidden" name="parcel_id" value="<?php echo $parcelID; ?>"><input type="hidden" name="as" value="<?php echo htmlspecialchars($context); ?>"><div class="stars"><?php for($i=1;$i<=5;$i++): ?><input id="star<?php echo $i; ?>" type="radio" name="rating" value="<?php echo $i; ?>"><label for="star<?php echo $i; ?>">★</label><?php endfor; ?></div><textarea class="comment" name="comment" maxlength="500" placeholder="Tell us about your parcel delivery (optional)"></textarea><button class="btn" type="submit">Submit Rating</button></form></div></div><?php include 'footer.php'; ?>