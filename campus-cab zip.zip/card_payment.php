<?php
session_start();
require_once __DIR__ . '/db_connect.php';

$isStudent = isset($_SESSION['student_id']);
$isStaff   = isset($_SESSION['staff_id']);
if (!$isStudent && !$isStaff) {
    header('Location: login.php');
    exit;
}

$userID = $isStudent ? (int)$_SESSION['student_id'] : (int)$_SESSION['staff_id'];
$requesterType = $isStudent ? 'Student' : 'Staff';
$dashboard = $isStudent ? 'student_dashboard.php' : 'staff_dashboard.php';
$type = strtolower((string)($_GET['type'] ?? $_POST['type'] ?? ''));
$itemID = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

if (!in_array($type, ['ride', 'parcel'], true) || $itemID <= 0) {
    header('Location: ' . $dashboard);
    exit;
}

$userColumn = $isStudent ? 'studentID' : 'staff_id';
$amount = 0.00;
$origin = '';
$destination = '';
$label = ucfirst($type);
$existingPayment = null;

if ($type === 'ride') {
    $sql = "SELECT rideID, estimated_price, ride_status, pickup_address, destination_address
            FROM ride
            WHERE rideID = ? AND $userColumn = ? AND ride_status = 'Completed'
            LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ii', $itemID, $userID);
    $stmt->execute();
    $item = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$item) {
        header('Location: my_rides.php');
        exit;
    }
    $amount = (float)$item['estimated_price'];
    $origin = (string)$item['pickup_address'];
    $destination = (string)$item['destination_address'];

    $stmt = $conn->prepare("SELECT payment_id, payment_status, payment_method, total_amount FROM payment WHERE ride_id = ? LIMIT 1");
    $stmt->bind_param('i', $itemID);
    $stmt->execute();
    $existingPayment = $stmt->get_result()->fetch_assoc();
    $stmt->close();
} else {
    $sql = "SELECT parcel, estimated_price, parcel_status, pickup_location, destination
            FROM parcel
            WHERE parcel = ? AND $userColumn = ? AND parcel_status = 'Delivered'
            LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ii', $itemID, $userID);
    $stmt->execute();
    $item = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$item) {
        header('Location: my_Parcels.php');
        exit;
    }
    $amount = (float)$item['estimated_price'];
    $origin = (string)$item['pickup_location'];
    $destination = (string)$item['destination'];

    $stmt = $conn->prepare("SELECT payment_id, payment_status, payment_method, total_amount FROM parcel_payment WHERE parcel = ? LIMIT 1");
    $stmt->bind_param('i', $itemID);
    $stmt->execute();
    $existingPayment = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

if ($existingPayment && strcasecmp((string)$existingPayment['payment_status'], 'Paid') === 0) {
    header('Location: my_payments.php');
    exit;
}

// The actual DB has one saved card per requester.
$stmt = $conn->prepare("SELECT payment_method_id, cardholder_name, card_brand, card_last4, expiry_month, expiry_year FROM payment_method WHERE requester_type = ? AND requester_id = ? LIMIT 1");
$stmt->bind_param('si', $requesterType, $userID);
$stmt->execute();
$savedCard = $stmt->get_result()->fetch_assoc();
$stmt->close();

$error = '';

function validLuhn(string $number): bool {
    $sum = 0;
    $alternate = false;
    for ($i = strlen($number) - 1; $i >= 0; $i--) {
        $n = (int)$number[$i];
        if ($alternate) {
            $n *= 2;
            if ($n > 9) $n -= 9;
        }
        $sum += $n;
        $alternate = !$alternate;
    }
    return $sum % 10 === 0;
}

function cardBrand(string $number): string {
    if (preg_match('/^4/', $number)) return 'Visa';
    if (preg_match('/^(5[1-5]|2[2-7])/', $number)) return 'Mastercard';
    if (preg_match('/^3[47]/', $number)) return 'American Express';
    return 'Card';
}

function saveCard(mysqli $conn, string $requesterType, int $userID, string $holder, string $brand, string $last4, int $month, int $year): void {
    $stmt = $conn->prepare("SELECT payment_method_id FROM payment_method WHERE requester_type = ? AND requester_id = ? LIMIT 1");
    $stmt->bind_param('si', $requesterType, $userID);
    $stmt->execute();
    $existing = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($existing) {
        $id = (int)$existing['payment_method_id'];
        $stmt = $conn->prepare("UPDATE payment_method SET cardholder_name=?, card_brand=?, card_last4=?, expiry_month=?, expiry_year=?, updated_at=NOW() WHERE payment_method_id=? AND requester_type=? AND requester_id=?");
        $stmt->bind_param('sssiiisi', $holder, $brand, $last4, $month, $year, $id, $requesterType, $userID);
        $stmt->execute();
        $stmt->close();
        return;
    }

    $result = $conn->query("SELECT COALESCE(MAX(payment_method_id), 0) + 1 AS next_id FROM payment_method");
    $nextID = (int)$result->fetch_assoc()['next_id'];
    $stmt = $conn->prepare("INSERT INTO payment_method (payment_method_id, requester_type, requester_id, cardholder_name, card_brand, card_last4, expiry_month, expiry_year, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param('isisssii', $nextID, $requesterType, $userID, $holder, $brand, $last4, $month, $year);
    $stmt->execute();
    $stmt->close();
}

function recordRidePayment(mysqli $conn, int $rideID, float $amount, string $method, ?array $existing): void {
    if ($existing) {
        $paymentID = (int)$existing['payment_id'];
        $stmt = $conn->prepare("UPDATE payment SET payment_method=?, payment_status='Paid', paid_at=NOW(), item_cost=0, delivery_fee=?, total_amount=? WHERE payment_id=? AND ride_id=?");
        $stmt->bind_param('sddii', $method, $amount, $amount, $paymentID, $rideID);
        $stmt->execute();
        $stmt->close();
        return;
    }
    // payment.payment_id is not AUTO_INCREMENT in the actual database export.
    $result = $conn->query("SELECT COALESCE(MAX(payment_id), 0) + 1 AS next_id FROM payment");
    $paymentID = (int)$result->fetch_assoc()['next_id'];
    $stmt = $conn->prepare("INSERT INTO payment (payment_id, ride_id, item_cost, delivery_fee, total_amount, payment_method, payment_status, paid_at) VALUES (?, ?, 0, ?, ?, ?, 'Paid', NOW())");
    $stmt->bind_param('iidds', $paymentID, $rideID, $amount, $amount, $method);
    $stmt->execute();
    $stmt->close();
}

function recordParcelPayment(mysqli $conn, int $parcelID, float $amount, string $method, ?array $existing): void {
    if ($existing) {
        $paymentID = (int)$existing['payment_id'];
        $stmt = $conn->prepare("UPDATE parcel_payment SET payment_method=?, payment_status='Paid', paid_at=NOW(), item_cost=?, delivery_fee=0, total_amount=? WHERE payment_id=? AND parcel=?");
        $stmt->bind_param('sddii', $method, $amount, $amount, $paymentID, $parcelID);
        $stmt->execute();
        $stmt->close();
        return;
    }
    $stmt = $conn->prepare("INSERT INTO parcel_payment (parcel, item_cost, delivery_fee, total_amount, payment_method, payment_status, paid_at) VALUES (?, ?, 0, ?, ?, 'Paid', NOW())");
    $stmt->bind_param('idds', $parcelID, $amount, $amount, $method);
    $stmt->execute();
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $useSaved = isset($_POST['use_saved_card']) && $_POST['use_saved_card'] === '1';
    $saveForLater = isset($_POST['save_card']) && $_POST['save_card'] === '1';

    if ($useSaved) {
        if (!$savedCard) {
            $error = 'No saved card is available. Please enter a new card.';
        } else {
            $expiryYear = (int)$savedCard['expiry_year'];
            $expiryMonth = (int)$savedCard['expiry_month'];
            $nowYear = (int)date('Y');
            $nowMonth = (int)date('n');
            if ($expiryYear < $nowYear || ($expiryYear === $nowYear && $expiryMonth < $nowMonth)) {
                $error = 'Your saved card has expired. Please enter a new card.';
            } else {
                $method = 'Card';
                if ($type === 'ride') recordRidePayment($conn, $itemID, $amount, $method, $existingPayment);
                else recordParcelPayment($conn, $itemID, $amount, $method, $existingPayment);
                header('Location: my_payments.php');
                exit;
            }
        }
    } else {
        $holder = trim((string)($_POST['cardholder_name'] ?? ''));
        $number = preg_replace('/\D+/', '', (string)($_POST['card_number'] ?? ''));
        $expiryMonth = (int)($_POST['expiry_month'] ?? 0);
        $expiryYear = (int)($_POST['expiry_year'] ?? 0);
        $cvv = preg_replace('/\D+/', '', (string)($_POST['cvv'] ?? ''));

        $currentYear = (int)date('Y');
        $currentMonth = (int)date('n');
        if ($holder === '' || strlen($holder) > 100) $error = 'Enter the cardholder name.';
        elseif (strlen($number) < 13 || strlen($number) > 19 || !validLuhn($number)) $error = 'Enter a valid card number.';
        elseif ($expiryMonth < 1 || $expiryMonth > 12 || $expiryYear < $currentYear || ($expiryYear === $currentYear && $expiryMonth < $currentMonth)) $error = 'Enter a valid, non-expired expiry date.';
        elseif (!in_array(strlen($cvv), [3,4], true)) $error = 'Enter a valid CVV.';
        else {
            $brand = cardBrand($number);
            $last4 = substr($number, -4);
            if ($saveForLater) {
                saveCard($conn, $requesterType, $userID, $holder, $brand, $last4, $expiryMonth, $expiryYear);
            }
            if ($type === 'ride') recordRidePayment($conn, $itemID, $amount, 'Card', $existingPayment);
            else recordParcelPayment($conn, $itemID, $amount, 'Card', $existingPayment);
            header('Location: my_payments.php');
            exit;
        }
    }
}

$pageTitle = 'Card Payment';
include 'header.php';
?>
<style>
.card-pay-wrap{max-width:760px;margin:40px auto;padding:0 18px}.card-pay{background:#fff;border-radius:18px;padding:30px;box-shadow:0 8px 30px rgba(11,31,58,.10)}.pay-head{display:flex;justify-content:space-between;gap:20px;align-items:flex-start;margin-bottom:22px}.pay-head h1{margin:0;color:#0c2d4d}.amount{font-size:26px;font-weight:800;color:#0f6e56}.saved{border:1px solid #d9e5df;background:#f5faf7;border-radius:12px;padding:16px;margin-bottom:22px}.field{margin-bottom:16px}.field label{display:block;font-weight:700;color:#263746;margin-bottom:7px}.field input,.field select{width:100%;box-sizing:border-box;padding:12px;border:1px solid #cfd8dc;border-radius:9px;font-size:15px}.grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px}.error{background:#fff1f0;color:#a12620;border:1px solid #f0c4c0;padding:12px;border-radius:9px;margin-bottom:18px}.actions{display:flex;gap:12px;align-items:center;margin-top:22px}.btn{border:0;border-radius:9px;padding:13px 20px;font-weight:800;cursor:pointer}.btn-primary{background:#0f6e56;color:#fff}.btn-secondary{background:#edf2f5;color:#263746}.muted{color:#66757f;font-size:13px}@media(max-width:650px){.grid{grid-template-columns:1fr}.pay-head{display:block}.amount{margin-top:10px}}
</style>
<div class="card-pay-wrap">
  <div class="card-pay">
    <div class="pay-head">
      <div>
        <h1>💳 Card Payment</h1>
        <p class="muted"><?php echo htmlspecialchars($label); ?> #<?php echo (int)$itemID; ?></p>
        <p class="muted"><?php echo htmlspecialchars($origin); ?> → <?php echo htmlspecialchars($destination); ?></p>
      </div>
      <div class="amount">R<?php echo number_format($amount, 2); ?></div>
    </div>

    <?php if ($error): ?><div class="error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <?php if ($savedCard): ?>
      <div class="saved">
        <strong>Saved card</strong>
        <div style="margin-top:6px"><?php echo htmlspecialchars($savedCard['card_brand']); ?> ending in <strong><?php echo htmlspecialchars($savedCard['card_last4']); ?></strong> · expires <?php echo sprintf('%02d/%04d', (int)$savedCard['expiry_month'], (int)$savedCard['expiry_year']); ?></div>
        <form method="post" style="margin-top:12px">
          <input type="hidden" name="type" value="<?php echo htmlspecialchars($type); ?>">
          <input type="hidden" name="id" value="<?php echo (int)$itemID; ?>">
          <input type="hidden" name="use_saved_card" value="1">
          <button class="btn btn-primary" type="submit">Use saved card</button>
        </form>
      </div>
    <?php endif; ?>

    <h3>Enter card details</h3>
    <form method="post" autocomplete="off">
      <input type="hidden" name="type" value="<?php echo htmlspecialchars($type); ?>">
      <input type="hidden" name="id" value="<?php echo (int)$itemID; ?>">
      <div class="field"><label for="cardholder_name">Cardholder name</label><input id="cardholder_name" name="cardholder_name" maxlength="100" required></div>
      <div class="field"><label for="card_number">Card number</label><input id="card_number" name="card_number" inputmode="numeric" autocomplete="cc-number" maxlength="19" placeholder="1234 5678 9012 3456" required></div>
      <div class="grid">
        <div class="field"><label for="expiry_month">Expiry month</label><select id="expiry_month" name="expiry_month" required><option value="">MM</option><?php for($m=1;$m<=12;$m++): ?><option value="<?php echo $m; ?>"><?php echo sprintf('%02d',$m); ?></option><?php endfor; ?></select></div>
        <div class="field"><label for="expiry_year">Expiry year</label><select id="expiry_year" name="expiry_year" required><option value="">YYYY</option><?php for($y=(int)date('Y');$y<=((int)date('Y')+15);$y++): ?><option value="<?php echo $y; ?>"><?php echo $y; ?></option><?php endfor; ?></select></div>
        <div class="field"><label for="cvv">CVV</label><input id="cvv" name="cvv" inputmode="numeric" autocomplete="cc-csc" maxlength="4" required></div>
      </div>
      <label style="display:flex;gap:9px;align-items:center;margin-top:4px"><input type="checkbox" name="save_card" value="1"> Save this card for future payments</label>
      <p class="muted" style="margin-top:14px">For security, CampusCab stores only the card brand, last four digits and expiry details. The full card number and CVV are not stored.</p>
      <div class="actions"><button class="btn btn-primary" type="submit">Pay R<?php echo number_format($amount,2); ?></button><a class="btn btn-secondary" href="my_payments.php" style="text-decoration:none">Cancel</a></div>
    </form>
  </div>
</div>
<?php include 'footer.php'; ?>
