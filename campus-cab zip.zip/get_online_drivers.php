<?php
session_start();
require_once __DIR__ . '/db_connect.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['student_id']) && !isset($_SESSION['staff_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

/*
 * Map visibility rule:
 * - Normally show every Active + Available driver with a recent location.
 * - Once this requester has a ride in progress, show ONLY the driver assigned
 *   to that current ride.
 * - As soon as that ride is Completed/Cancelled, the normal online-driver list
 *   becomes visible again.
 */
$userColumn = isset($_SESSION['student_id']) ? 'studentID' : 'staff_id';
$userID = (int)(isset($_SESSION['student_id']) ? $_SESSION['student_id'] : $_SESSION['staff_id']);

$currentRideDriverID = 0;
$rideStmt = $conn->prepare("SELECT DriverID FROM ride WHERE $userColumn = ? AND ride_status = 'In Progress' AND DriverID IS NOT NULL ORDER BY started_at DESC, rideID DESC LIMIT 1");
if ($rideStmt) {
    $rideStmt->bind_param('i', $userID);
    $rideStmt->execute();
    $rideRow = $rideStmt->get_result()->fetch_assoc();
    $rideStmt->close();
    if ($rideRow && !empty($rideRow['DriverID'])) {
        $currentRideDriverID = (int)$rideRow['DriverID'];
    }
}

$where = "d.driverAccount_Status='Active'";
$types = '';
$params = [];

if ($currentRideDriverID > 0) {
    // During an active ride, the assigned driver is the only marker that is shown.
    // Do not require the driver's availability flag here.
    $where .= " AND d.DriverID = ?";
    $types = 'i';
    $params[] = $currentRideDriverID;
} else {
    // No active ride: restore the complete online/available driver map.
    $where .= " AND d.availability_status='Available'";
}

$sql = "SELECT d.DriverID,d.DriverFname,d.DriverLname,d.profile_picture,d.vehicle_registration,d.vehicle_make,d.vehicle_model,d.availability_status,
               l.latitude,l.longitude,l.recorded_at
        FROM driver d
        LEFT JOIN location l ON l.location_id=(
            SELECT l2.location_id
            FROM location l2
            WHERE l2.driver_id=d.DriverID
              AND (l2.request_type='availability' OR l2.request_type='ride' OR l2.request_type IS NULL)
            ORDER BY l2.recorded_at DESC,l2.location_id DESC
            LIMIT 1
        )
        WHERE $where
        ORDER BY d.DriverFname,d.DriverLname";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Unable to load driver locations']);
    exit;
}

if ($types !== '') {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$drivers = [];

while ($row = $result->fetch_assoc()) {
    $row['DriverID'] = (int)$row['DriverID'];
    $row['latitude'] = $row['latitude'] !== null ? (float)$row['latitude'] : null;
    $row['longitude'] = $row['longitude'] !== null ? (float)$row['longitude'] : null;
    $row['is_current_ride_driver'] = $currentRideDriverID > 0 && $row['DriverID'] === $currentRideDriverID;
    $drivers[] = $row;
}
$stmt->close();

echo json_encode([
    'success' => true,
    'drivers' => $drivers,
    'current_ride_active' => $currentRideDriverID > 0,
    'current_ride_driver_id' => $currentRideDriverID > 0 ? $currentRideDriverID : null,
    'server_time' => date('c')
], JSON_UNESCAPED_SLASHES);
