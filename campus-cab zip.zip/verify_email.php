<?php
session_start();
include_once __DIR__ . '/db_connect.php';

$message = 'Email verification is not required by the active Campus Cab database schema. Your account can be used directly after registration.';
$message_type = 'success';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Verification | Campus Cab</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="container verify-container">
        <div class="verify-box">
            <h1>📧 Email Verification</h1>
            
            <?php if ($message_type === 'success'): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($message); ?>
                    <br><br>
                    <a href="login_student.php" class="btn-primary">🔑 Login Now</a>
                </div>
            <?php else: ?>
                <div class="alert alert-danger">
                    <?php echo htmlspecialchars($message); ?>
                    <br><br>
                    <a href="register_student.php" class="btn-secondary">📝 Register Again</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>