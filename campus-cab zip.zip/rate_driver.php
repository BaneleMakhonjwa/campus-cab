<?php
session_start();
include_once __DIR__ . '/db_connect.php';

// Multiple identities may coexist in one session. The requester context is explicit.
$activeRole = strtolower(trim((string)($_SESSION['role'] ?? '')));
$requestedAs = strtolower(trim((string)($_GET['as'] ?? '')));
$hasStudent = !empty($_SESSION['student_id']);
$hasStaff = !empty($_SESSION['staff_id']);
if ($requestedAs === 'staff' && $hasStaff) { $isStudent=false; $isStaff=true; }
elseif ($requestedAs === 'student' && $hasStudent) { $isStudent=true; $isStaff=false; }
elseif ($activeRole === 'staff' && $hasStaff) { $isStudent=false; $isStaff=true; }
elseif ($activeRole === 'student' && $hasStudent) { $isStudent=true; $isStaff=false; }
elseif ($hasStudent) { $isStudent=true; $isStaff=false; }
elseif ($hasStaff) { $isStudent=false; $isStaff=true; }
else { header('Location: login.php'); exit; }

$rideID = (int)($_GET['ride_id'] ?? 0);

if ($rideID <= 0) {
    header("Location: index.php");
    exit;
}

// Fetch ride based on passenger type
if ($isStudent) {
    $userID = (int)$_SESSION['student_id'];
    $stmt = $conn->prepare("
        SELECT 
            r.rideID, r.DriverID, r.studentID, r.staff_id, r.ride_status,
            d.DriverFname, d.DriverLname, d.profile_picture,
            d.vehicle_registration, d.vehicle_make, d.vehicle_model
        FROM ride r
        LEFT JOIN driver d ON r.DriverID = d.DriverID
        WHERE r.rideID = ? AND r.studentID = ? AND r.ride_status = 'Completed'
        LIMIT 1
    ");
    $stmt->bind_param("ii", $rideID, $userID);
} else {
    $userID = (int)$_SESSION['staff_id'];
    $stmt = $conn->prepare("
        SELECT 
            r.rideID, r.DriverID, r.studentID, r.staff_id, r.ride_status,
            d.DriverFname, d.DriverLname, d.profile_picture,
            d.vehicle_registration, d.vehicle_make, d.vehicle_model
        FROM ride r
        LEFT JOIN driver d ON r.DriverID = d.DriverID
        WHERE r.rideID = ? AND r.staff_id = ? AND r.ride_status = 'Completed'
        LIMIT 1
    ");
    $stmt->bind_param("ii", $rideID, $userID);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: index.php");
    exit;
}

$ride = $result->fetch_assoc();
$stmt->close();

// Check if already rated
$check = $conn->prepare("SELECT ratingID FROM driver_ratings WHERE rideID = ? LIMIT 1");
$check->bind_param("i", $rideID);
$check->execute();
$alreadyRated = $check->get_result()->num_rows > 0;
$check->close();

if ($alreadyRated) {
    header("Location: trip.php?id=" . $rideID . "&as=" . ($isStaff ? "staff" : "student"));
    exit;
}

$driverName = trim(($ride['DriverFname'] ?? '') . ' ' . ($ride['DriverLname'] ?? ''));
$message = '';

// Handle submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $rating = (int)($_POST['rating'] ?? 0);
    $comment = trim($_POST['comment'] ?? '');

    if ($rating < 1 || $rating > 5) {
        $message = "Please choose a rating between 1 and 5 stars.";
    } else {

        // Determine passenger type
        if ($isStudent) {
            $passengerType = 'student';
            $studentIDVal  = $userID;
            $staffIDVal    = null;
        } else {
            $passengerType = 'staff';
            $studentIDVal  = null;
            $staffIDVal    = $userID;
        }

        $insert = $conn->prepare("
            INSERT INTO driver_ratings 
                (rideID, studentID, staff_id, passenger_type, DriverID, rating, comment, rated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $insert->bind_param(
            "iiisiss",
            $rideID,
            $studentIDVal,
            $staffIDVal,
            $passengerType,
            $ride['DriverID'],
            $rating,
            $comment
        );

        if ($insert->execute()) {
            $insert->close();
            $_SESSION['ride_success'] = "Thank you for rating your driver!";
            header("Location: trip.php?id=" . $rideID . "&as=" . ($isStaff ? "staff" : "student"));
            exit;
        } else {
            $message = "Failed to save rating: " . $conn->error;
        }
    }
}

$pageTitle = "Rate Your Driver";
include 'header.php';
?>

<style>
.rate-page { max-width: 600px; margin: 0 auto; padding: 50px 25px 60px; }
.rate-back {
    display: inline-flex; align-items: center; gap: 8px;
    background: #0c2d4d; color: #fff; text-decoration: none;
    padding: 10px 16px; border-radius: 8px; font-size: 13px;
    font-weight: 600; margin-bottom: 22px;
}
.rate-back:hover { background: #185fa5; }
.rate-card {
    background: #fff; border: 1px solid #e2e2dc;
    border-radius: 16px; padding: 40px 30px;
    box-shadow: 0 4px 20px rgba(11,31,58,0.08);
    text-align: center;
}
.driver-avatar {
    width: 90px; height: 90px; border-radius: 50%;
    background: #0c2d4d; color: #fff;
    display: flex; align-items: center; justify-content: center;
    font-weight: 800; font-size: 30px;
    margin: 0 auto 18px; overflow: hidden;
}
.driver-avatar img { width: 100%; height: 100%; object-fit: cover; }
.rate-card h1 { color: #0c2d4d; font-size: 24px; margin: 0 0 6px; font-weight: 800; }
.rate-card .subtitle { color: #6b7280; font-size: 14px; margin: 0 0 25px; }
.stars { display: flex; justify-content: center; gap: 10px; margin-bottom: 25px; direction: rtl; }
.stars input { display: none; }
.stars label {
    font-size: 46px; color: #e5e8ea;
    cursor: pointer; transition: color 0.15s ease, transform 0.15s ease;
}
.stars label:hover,
.stars label:hover ~ label,
.stars input:checked ~ label {
    color: #e0a526; transform: scale(1.1);
}
.comment-box {
    width: 100%; min-height: 110px; padding: 14px;
    border: 1px solid #dfe3e8; border-radius: 10px;
    font-family: inherit; font-size: 14.5px;
    resize: vertical; margin-bottom: 20px; box-sizing: border-box;
}
.comment-box:focus {
    outline: none; border-color: #185fa5;
    box-shadow: 0 0 0 3px rgba(24,95,165,0.15);
}
.btn-submit {
    width: 100%; padding: 15px;
    background: #0c2d4d; color: #fff;
    border: none; border-radius: 10px;
    font-size: 15.5px; font-weight: 700;
    cursor: pointer; font-family: inherit;
}
.btn-submit:hover { background: #185fa5; }
.msg.error {
    background: #fbe2df; color: #b03a2e;
    padding: 12px 14px; border-radius: 8px;
    font-size: 13.5px; font-weight: 600;
    margin-bottom: 18px;
}
</style>

<div class="rate-page">

    <a href="trip.php?id=<?php echo (int)$rideID; ?>" class="rate-back">← Back to Trip</a>

    <div class="rate-card">

        <div class="driver-avatar">
            <?php if (!empty($ride['profile_picture']) && file_exists(__DIR__ . '/' . $ride['profile_picture'])): ?>
                <img src="<?php echo htmlspecialchars($ride['profile_picture']); ?>" alt="">
            <?php else: ?>
                <?php echo strtoupper(substr($ride['DriverFname'], 0, 1) . substr($ride['DriverLname'], 0, 1)); ?>
            <?php endif; ?>
        </div>

        <h1>How was your ride?</h1>
        <p class="subtitle">
            Rate <strong><?php echo htmlspecialchars($driverName); ?></strong><br>
            <?php echo htmlspecialchars(trim(($ride['vehicle_make'] ?? '') . ' ' . ($ride['vehicle_model'] ?? ''))); ?>
            <?php if ($ride['vehicle_registration']): ?> · <?php echo htmlspecialchars($ride['vehicle_registration']); ?><?php endif; ?>
        </p>

        <?php if ($message): ?>
            <div class="msg error"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <form method="POST">

            <div class="stars">
                <input type="radio" id="star5" name="rating" value="5" required>
                <label for="star5">★</label>

                <input type="radio" id="star4" name="rating" value="4">
                <label for="star4">★</label>

                <input type="radio" id="star3" name="rating" value="3">
                <label for="star3">★</label>

                <input type="radio" id="star2" name="rating" value="2">
                <label for="star2">★</label>

                <input type="radio" id="star1" name="rating" value="1">
                <label for="star1">★</label>
            </div>

            <textarea 
                name="comment" 
                class="comment-box" 
                placeholder="Share a comment about your driver (optional)..."
                maxlength="500"
            ></textarea>

            <button type="submit" class="btn-submit">✅ Submit Rating</button>

        </form>

    </div>

</div>

<?php include 'footer.php'; ?>