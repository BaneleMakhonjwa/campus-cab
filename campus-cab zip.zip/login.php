<?php
session_start();
include 'db_connect.php';

$pageTitle = "Login";

$error = "";
$selectedRole = $_GET['role'] ?? "student";
$allowedRoles = ["student", "driver", "staff", "admin"];
if (!in_array($selectedRole, $allowedRoles, true)) $selectedRole = "student";
$email = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $selectedRole = $_POST['role'] ?? "student";
    $email = trim($_POST['email'] ?? "");
    $password = $_POST['password'] ?? "";

    if (empty($email) || empty($password)) {
        $error = "Please enter your email and password.";
    } else {

        // STUDENT LOGIN
        if ($selectedRole == "student") {

            $stmt = mysqli_prepare(
                $conn,
                "SELECT * FROM student
                 WHERE studentEmail = ?
                 AND studentAccount_status = 'Active'"
            );

            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);

            $result = mysqli_stmt_get_result($stmt);
            $student = mysqli_fetch_assoc($result);

            if ($student && password_verify($password, $student['password'])) {

                // Keep other authenticated identities in the same session so a user can
                // operate as a requester and driver at the same time. The selected role
                // controls the login landing page; page-specific routes use their own ID.
                $_SESSION['student_id'] = $student['studentID'];
                $_SESSION['student_name'] = $student['studentFname'] . ' ' . $student['studentLname'];
                $_SESSION['role'] = "student";

                header("Location: student_dashboard.php");
                exit;

            } else {
                $error = "Incorrect email or password.";
            }

            mysqli_stmt_close($stmt);
        }

        // DRIVER LOGIN
        elseif ($selectedRole == "driver") {

            $stmt = mysqli_prepare(
                $conn,
                "SELECT * FROM driver
                 WHERE DriverEmail = ?
                 AND driverAccount_Status = 'Active'
                 "
            );

            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);

            $result = mysqli_stmt_get_result($stmt);
            $driver = mysqli_fetch_assoc($result);

            if ($driver && password_verify($password, $driver['password'])) {

                // Do not clear requester identities: a driver may also be logged in as a
                // student or staff member in the same browser session.
                $_SESSION['driver_id'] = $driver['DriverID'];
                $_SESSION['driver_name'] = $driver['DriverFname'] . ' ' . $driver['DriverLname'];
                $_SESSION['role'] = "driver";

                header("Location: driver_dashboard.php");
                exit;

            } else {
                $error = "Incorrect email or password.";
            }

            mysqli_stmt_close($stmt);
        }

        // STAFF LOGIN
        elseif ($selectedRole == "staff") {

            $stmt = mysqli_prepare(
                $conn,
                "SELECT staff_id, staff_name, surname, staff_email, staffAccount_status, password
                 FROM staff
                 WHERE staff_email = ?
                 LIMIT 1"
            );

            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);

            $result = mysqli_stmt_get_result($stmt);
            $staff = mysqli_fetch_assoc($result);

            if (!$staff) {
                $error = "Incorrect email or password.";
            } elseif (strcasecmp((string)$staff['staffAccount_status'], 'Active') !== 0) {
                $error = "Your staff account is inactive. Please contact an administrator.";
            } elseif (!password_verify($password, (string)$staff['password'])) {
                $error = "Incorrect email or password.";
            } else {
                // Preserve student/driver identities so multiple roles can coexist.
                $_SESSION['staff_id'] = $staff['staff_id'];
                $_SESSION['staff_name'] = $staff['staff_name'] . ' ' . $staff['surname'];
                $_SESSION['role'] = "staff";

                header("Location: staff_dashboard.php");
                exit;
            }

            mysqli_stmt_close($stmt);
        }

        // ADMIN LOGIN
        elseif ($selectedRole == "admin") {

            // The actual database contains two admin rows with the same email.
            // One of them has an empty password, so do not LIMIT 1 and accidentally
            // select the unusable row. Check every matching admin record.
            $stmt = mysqli_prepare(
                $conn,
                "SELECT adminID, adminFname, adminLname, admin_email, adminPWD
                 FROM admin
                 WHERE admin_email = ?
                 ORDER BY CASE WHEN adminPWD IS NULL OR adminPWD = '' THEN 1 ELSE 0 END, adminID"
            );

            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);

            $result = mysqli_stmt_get_result($stmt);
            $admin = null;

            while ($candidate = mysqli_fetch_assoc($result)) {
                $storedPassword = (string)($candidate['adminPWD'] ?? '');

                if ($storedPassword !== '' &&
                    (password_verify($password, $storedPassword) || $password === $storedPassword)) {
                    $admin = $candidate;
                    break;
                }
            }

            if ($admin) {
                // Admin login also preserves other identities for multi-role testing/use.
                $_SESSION['admin_id'] = $admin['adminID'];
                $_SESSION['admin_username'] = $admin['admin_email'];
                $_SESSION['admin_name'] = $admin['adminFname'] . ' ' . $admin['adminLname'];
                $_SESSION['admin_role'] = 'admin';
                $_SESSION['role'] = "admin";

                header("Location: admin_dashboard.php");
                exit;

            } else {
                $error = "Incorrect email or password.";
            }

            mysqli_stmt_close($stmt);
        }

        // INVALID ROLE
        else {
            $error = "Invalid role selected.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) . ' — Campus Cab' : 'Campus Cab & Delivery'; ?></title>
    <link rel="stylesheet" href="style.css">

    <style>
        .login-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 70vh;
            padding: 40px 20px;
        }

        .auth-card {
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            max-width: 500px;
            width: 100%;
        }

        .auth-card h1 {
            text-align: center;
            color: #2c3e50;
            font-size: 28px;
            margin-bottom: 5px;
        }

        .auth-card h2 {
            text-align: center;
            color: #6c757d;
            font-size: 18px;
            font-weight: normal;
            margin-bottom: 25px;
        }

        .auth-card .msg {
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .auth-card .msg.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .role-options {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
            margin: 15px 0 20px 0;
        }

        .role-options label {
            background: #f8f9fa;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
            border: 2px solid transparent;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .role-options label:hover {
            background: #e9ecef;
        }

        .role-options input[type="radio"] {
            margin-right: 5px;
        }

        .role-options label:has(input:checked) {
            border-color: #007bff;
            background: #e7f1ff;
        }

        .auth-card label {
            display: block;
            font-weight: 600;
            margin: 15px 0 5px 0;
            font-size: 14px;
            color: #333;
        }

        .auth-card input[type="email"],
        .auth-card input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
            transition: border-color 0.3s ease;
        }

        .auth-card input[type="email"]:focus,
        .auth-card input[type="password"]:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 5px rgba(0,123,255,0.3);
        }

        .login-buttons {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }

        .login-buttons button {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .login-buttons button[type="submit"] {
            background: #007bff;
            color: white;
        }

        .login-buttons button[type="submit"]:hover {
            background: #0056b3;
        }

        .login-buttons .cancel-button {
            background: #6c757d;
            color: white;
        }

        .login-buttons .cancel-button:hover {
            background: #5a6268;
        }

        .login-links {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
        }

        .login-links p {
            margin: 8px 0;
        }

        .login-links a {
            color: #007bff;
            text-decoration: none;
            font-weight: 600;
        }

        .login-links a:hover {
            text-decoration: underline;
        }

        @media (max-width: 480px) {
            .auth-card {
                padding: 25px;
            }
            .role-options {
                grid-template-columns: 1fr 1fr;
            }
            .login-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>

    <?php include 'header.php'; ?>

    <div class="container">
        <div class="login-wrapper">

            <div class="auth-card">

                <h1>🚗 Campus Cab</h1>
                <h2>Login to your account</h2>

                <?php if (!empty($error)): ?>
                    <div class="msg error">❌ <?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>

                <form method="POST" action="login.php" autocomplete="off">

                    <p><strong>Choose your role:</strong></p>

                    <div class="role-options">
                        <label>
                            <input type="radio" name="role" value="student"
                                <?php if ($selectedRole == "student") echo "checked"; ?> required>
                            🎓 Student
                        </label>

                        <label>
                            <input type="radio" name="role" value="driver"
                                <?php if ($selectedRole == "driver") echo "checked"; ?>>
                            🚗 Driver
                        </label>

                        <label>
                            <input type="radio" name="role" value="staff"
                                <?php if ($selectedRole == "staff") echo "checked"; ?>>
                            👔 Staff
                        </label>

                        <label>
                            <input type="radio" name="role" value="admin"
                                <?php if ($selectedRole == "admin") echo "checked"; ?>>
                            🔐 Admin
                        </label>
                    </div>

                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email"
                        placeholder="Enter your email address"
                        value="" autocomplete="off" required>

                    <label for="password">Password</label>
                    <input type="password" id="password" name="password"
                        placeholder="Enter your password" value="" autocomplete="new-password" required>

                    <div class="login-buttons">
                        <button type="submit" name="login">🔑 LOGIN</button>
                        <button type="reset" class="cancel-button">✖ CANCEL</button>
                    </div>

                    <div class="login-links">
                        <p><a href="forgot_password.php">🔓 Forgot password?</a></p>
                        <p>Don't have an account? <a href="register.php">Register here</a></p>
                    </div>

                </form>

            </div>

        </div>
    </div>

    <?php include 'footer.php'; ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    const roleRadios = document.querySelectorAll('input[name="role"]');

    roleRadios.forEach(function (radio) {
        radio.addEventListener('change', function () {
            if (!this.checked) return;

            // Force a real page refresh with the selected role.
            // This prevents email/password values from another role
            // being carried over.
            window.location.href = 'login.php?role=' + encodeURIComponent(this.value);
        });
    });

    // Always start the freshly selected role with empty credentials.
    const email = document.getElementById('email');
    const password = document.getElementById('password');

    if (email) email.value = '';
    if (password) password.value = '';
});
</script>

\n<script>\n(function () {\n    function switchRole(role) {\n        window.location.replace('login.php?role=' + encodeURIComponent(role));\n    }\n\n    document.querySelectorAll('input[name="role"]').forEach(function (radio) {\n        radio.addEventListener('change', function () {\n            switchRole(this.value);\n        });\n    });\n\n    // Never retain previously entered login credentials after loading this page.\n    var email = document.getElementById('email');\n    var password = document.getElementById('password');\n    if (email) email.value = '';\n    if (password) password.value = '';\n})();\n</script>\n</body>
</html>