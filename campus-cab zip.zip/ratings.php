<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$as = strtolower(trim((string)($_GET['as'] ?? '')));
if ($as === 'student' && !empty($_SESSION['student_id'])) { header('Location: student_ratings.php?as=student'); exit; }
if ($as === 'staff' && !empty($_SESSION['staff_id'])) { header('Location: staff_ratings.php?as=staff'); exit; }
if (!empty($_SESSION['student_id']) && (($_SESSION['role'] ?? '') === 'student')) { header('Location: student_ratings.php?as=student'); exit; }
if (!empty($_SESSION['staff_id']) && (($_SESSION['role'] ?? '') === 'staff') ) { header('Location: staff_ratings.php?as=staff'); exit; }
header('Location: login.php'); exit;
