<?php
session_start(); require_once __DIR__ . '/db_connect.php';
if (!isset($_SESSION['student_id']) && !isset($_SESSION['staff_id'])) { header('Location: login.php'); exit; }
$pageTitle='Available Drivers'; include 'header.php';
?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"><script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<div style="max-width:1100px;margin:0 auto;padding:35px 25px 60px"><h1 style="color:#0c2d4d">Live Driver Map</h1><p style="color:#6b7280">Drivers who are online for requests appear here in real time.</p><div id="liveDriversMap" style="height:520px;border-radius:14px;border:1px solid #e2e2dc;margin-top:22px"></div><div id="driverCount" style="margin-top:12px;color:#6b7280;font-size:13px"></div></div>
<script>
const map=L.map('liveDriversMap').setView([-32.7833,26.8448],13); L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(map);
const carIcon = L.divIcon({
    html: '<div style="background:#0c2d4d;color:#fff;border-radius:50%;width:38px;height:38px;display:flex;align-items:center;justify-content:center;font-size:21px;border:3px solid #fff;box-shadow:0 2px 9px rgba(0,0,0,.35);">🚗</div>',
    className: '',
    iconSize: [38, 38],
    iconAnchor: [19, 19]
});
const markers=new Map();
function refresh(){fetch('get_online_drivers.php',{credentials:'same-origin',cache:'no-store'}).then(r=>r.json()).then(d=>{if(!d.success)return;const seen=new Set();d.drivers.forEach(x=>{if(x.latitude===null||x.longitude===null)return;const id=String(x.DriverID);seen.add(id);let m=markers.get(id);if(!m){m=L.marker([x.latitude,x.longitude], {icon: carIcon}).addTo(map);markers.set(id,m)}else m.setLatLng([x.latitude,x.longitude]);m.bindPopup('<strong>🚗 '+x.DriverFname+' '+x.DriverLname+'</strong><br>'+(x.vehicle_make||'')+' '+(x.vehicle_model||'')+'<br>● Online');});markers.forEach((m,id)=>{if(!seen.has(id)){map.removeLayer(m);markers.delete(id)}});document.getElementById('driverCount').textContent=d.drivers.length+' driver'+(d.drivers.length===1?'':'s')+' online';}).catch(()=>{})} refresh(); setInterval(refresh,5000);
</script><?php include 'footer.php'; ?>