# CampusCab

This build is audited against the **actual `campus_cab_db` export supplied for the XAMPP database**, not the original project schema.

## XAMPP setup

1. Put this folder in `C:\xampp\htdocs\campus-cab`.
2. Make sure MariaDB/MySQL is running in XAMPP.
3. Use the database that already contains your live CampusCab data.
4. Check `db_connect.php` only if your host, port, username, password, or database name differs from the defaults.
5. Open `http://localhost/campus-cab/`.

Do **not** import the removed project schema or old migration scripts over your existing database.

## Database source of truth

`actual_database_export.sql` is the export supplied for this audit and is included only as a reference. The PHP application does not import it automatically.

See `SCHEMA_AUDIT.md` for the exact schema decisions and limitations.

## Important live-schema limitations

- Ride payments remain in `payment` through `ride_id`; parcel payments are stored separately in `parcel_payment` through `parcel`.
- Location rows identify a ride/driver and request type, but not a parcel ID; parcel live tracking therefore uses the driver's latest parcel location.
- The live database has no approval, OTP, reset-token, or online/last-seen driver columns. The application uses the fields that actually exist.
