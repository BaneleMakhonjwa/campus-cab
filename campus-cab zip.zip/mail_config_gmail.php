<?php
// mail_config_gmail.php - Gmail SMTP Configuration for Drivers

// ✅ Load PHPMailer files from src folder
require_once __DIR__ . '/src/Exception.php';
require_once __DIR__ . '/src/PHPMailer.php';
require_once __DIR__ . '/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function sendVerificationEmailGmail($email, $name, $token) {
    $mail = new PHPMailer(true);

    try {
        // ✅ GMAIL SMTP SETTINGS (FOR DRIVERS)
        $mail->SMTPDebug = 0; 
        $mail->Debugoutput = 'html';                     // 0 = no debug, 2 = full debug
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = getenv('CAMPUS_CAB_SMTP_USER') ?: '';   // ✅ YOUR GMAIL ADDRESS
        $mail->Password   = getenv('CAMPUS_CAB_SMTP_PASS') ?: ''; // ✅ THE APP PASSWORD
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Alternative: Use TLS on port 587
        // $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        // $mail->Port       = 465;

        // Recipients
        $mail->setFrom($mail->Username ?: 'no-reply@localhost', 'Campus Cab');
        $mail->addAddress($email, $name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Verify Your Campus Cab Driver Account';

        $verification_link = rtrim(getenv('CAMPUS_CAB_BASE_URL') ?: 'http://localhost/campus-cab', '/') . '/verify_email.php?token=' . urlencode($token);

        $mail->Body = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #2c3e50; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; border: 1px solid #ddd; }
                .button { display: inline-block; padding: 12px 24px; background-color: #28a745; color: white; text-decoration: none; border-radius: 5px; }
                .footer { text-align: center; color: #666; font-size: 12px; padding: 20px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>🚗 Campus Cab</h1>
                </div>
                <div class='content'>
                    <h2>Welcome Driver $name!</h2>
                    <p>Thank you for registering as a driver with Campus Cab.</p>
                    <p>Please click the button below to verify your email address:</p>
                    <p style='text-align: center;'>
                        <a href='$verification_link' class='button'>Verify Email</a>
                    </p>
                    <p>Or copy and paste this link in your browser:</p>
                    <p><a href='$verification_link'>$verification_link</a></p>
                    <p>This link will expire in 24 hours.</p>
                </div>
                <div class='footer'>
                    <p>© 2024 Campus Cab. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        ";

        $mail->AltBody = "Welcome Driver $name!\n\nPlease verify your email by clicking this link:\n$verification_link\n\nThis link will expire in 24 hours.";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Gmail email sending failed: " . $mail->ErrorInfo);
        return false;
    }
}
?>