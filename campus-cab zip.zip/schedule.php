<?php
session_start();
include_once __DIR__ . '/db_connect.php';

$pageTitle = "Schedule";
include 'header.php';

$isLoggedIn = isset($_SESSION['student_id']) || isset($_SESSION['driver_id']);
?>

<!-- ================= HERO ================= -->
<section class="cc-hero" style="padding: 60px 20px;">
    <div class="cc-hero-inner" style="grid-template-columns: 1fr; text-align: center;">
        <div class="cc-hero-text">
            <p class="cc-hero-label">— Ride Schedule</p>
            <h1>Know When to <span>Ride</span></h1>
            <p class="cc-hero-desc" style="margin-left: auto; margin-right: auto;">
                Plan your trips around campus with our daily schedule, rush hours,
                and operating times. Stay ahead of the crowd.
            </p>
        </div>
    </div>
</section>


<!-- ================= TODAY'S STATUS ================= -->
<section class="cc-features">
    <div class="cc-features-grid">
        <div class="cc-feature">
            <div class="cc-feature-icon">🟢</div>
            <div>
                <h4>Service Status</h4>
                <p><strong style="color: #0f6e56;">Active Now</strong> — Drivers on duty</p>
            </div>
        </div>

        <div class="cc-feature">
            <div class="cc-feature-icon">🕐</div>
            <div>
                <h4>Operating Hours</h4>
                <p>Mon – Thur: 06:00 – 22:00<br>Fri – Sun: 07:00 – 02:00</p>
            </div>
        </div>

        <div class="cc-feature">
            <div class="cc-feature-icon">🚗</div>
            <div>
                <h4>Active Vehicles</h4>
                <p><strong>8 vehicles</strong> currently on route</p>
            </div>
        </div>

        <div class="cc-feature">
            <div class="cc-feature-icon">⏱️</div>
            <div>
                <h4>Average Wait</h4>
                <p>~5 minutes at main stops</p>
            </div>
        </div>
    </div>
</section>


<!-- ================= WEEKLY SCHEDULE ================= -->
<section class="cc-quick">
    <div class="cc-quick-header">
        <h2>Weekly Schedule</h2>
        <p>Operating hours and frequency for the week ahead.</p>
    </div>

    <div class="activity-table-wrapper" style="max-width: 1200px; margin: 0 auto; overflow-x: auto; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
        <table class="activity-table" style="min-width: 700px;">
            <thead>
                <tr>
                    <th>Day</th>
                    <th>Opening</th>
                    <th>Closing</th>
                    <th>Frequency</th>
                    <th>Peak Hours</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $schedule = [
                    ['Monday',    '06:00', '22:00', 'Every 10 min', '07:00 – 09:00, 16:00 – 18:00', 'Normal'],
                    ['Tuesday',   '06:00', '22:00', 'Every 10 min', '07:00 – 09:00, 16:00 – 18:00', 'Normal'],
                    ['Wednesday', '06:00', '22:00', 'Every 10 min', '07:00 – 09:00, 16:00 – 18:00', 'Normal'],
                    ['Thursday',  '06:00', '22:00', 'Every 10 min', '07:00 – 09:00, 16:00 – 18:00', 'Normal'],
                    ['Friday',    '06:00', '02:00', 'Every 8 min',  '07:00 – 09:00, 21:00 – 02:00', 'Busy'],
                    ['Saturday',  '07:00', '02:00', 'Every 5 min', '10:00 – 12:00, 20:00 – 02:00', 'Busy'],
                    ['Sunday',    '07:00', '02:00', 'Every 30 min', '09:00 – 13:00',                'Relaxed'],
                ];

                $today = date('l');

                foreach ($schedule as $row):
                    $isToday = ($row[0] === $today);
                    $statusClass = strtolower($row[5]);
                ?>
                <tr style="<?php echo $isToday ? 'background: #fff9db; font-weight: 600;' : ''; ?>">
                    <td>
                        <?php echo $row[0]; ?>
                        <?php if ($isToday): ?>
                            <span style="background: #f5c518; color: #0f1e3d; padding: 2px 8px; border-radius: 12px; font-size: 10px; margin-left: 6px; font-weight: 700;">TODAY</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo $row[1]; ?></td>
                    <td><?php echo $row[2]; ?></td>
                    <td><?php echo $row[3]; ?></td>
                    <td><?php echo $row[4]; ?></td>
                    <td>
                        <span class="status-badge status-<?php echo $statusClass; ?>">
                            <?php echo $row[5]; ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>


<!-- ================= RUSH HOURS ================= -->
<section class="cc-quick" style="background: #f8f9fa;">
    <div class="cc-quick-header">
        <h2>⏰ Rush Hours</h2>
        <p>These are the busiest times – plan ahead if you can.</p>
    </div>

    <div class="cc-quick-cards" style="max-width: 1200px; margin: 0 auto; grid-template-columns: repeat(3, 1fr);">

        <div class="cc-quick-card" style="border-left: 5px solid #dc3545;">
            <div class="cc-quick-icon">🌅</div>
            <h4>Morning Rush</h4>
            <p style="font-weight: 600; color: #dc3545; margin-bottom: 8px;">07:00 – 09:00</p>
            <p>Students, Lecturers heading to morning lectures and staff clocking in. Expect longer waits.</p>
        </div>

        <div class="cc-quick-card" style="border-left: 5px solid #fd7e14;">
            <div class="cc-quick-icon">🌇</div>
            <h4>Evening Rush</h4>
            <p style="font-weight: 600; color: #dc3545; margin-bottom: 8px;">16:00 – 18:30</p>
            <p>End of lectures and library trips. Highest demand.</p>
            
        </div>

        <div class="cc-quick-card" style="border-left: 5px solid #dc3545;">
            <div class="cc-quick-icon">🌆</div>
            <h4>Night Rush</h4>
            <p style="font-weight: 600; color: #dc3545; margin-bottom: 8px;">21:00 – 02:00</p>
            <p>Mostly friday and saturday nights when students go out.</p>
        </div>

    </div>
</section>


<!-- ================= POPULAR ROUTES ================= -->
<section class="cc-quick">
    <div class="cc-quick-header">
        <h2>Popular Routes</h2>
        <p>Most requested trips on campus.</p>
    </div>

    <div class="cc-quick-cards" style="max-width: 1200px; margin: 0 auto; grid-template-columns: repeat(2, 1fr);">

        <div class="cc-quick-card">
            <div class="cc-quick-icon">📍</div>
            <h4>Lecture Hall → Residences</h4>
            <p>Most popular route during morning and evening rush.</p>
            <span style="color: #0f6e56; font-weight: 600; font-size: 13px;">⏱️ ~4 min trip</span>
        </div>

        <div class="cc-quick-card">
            <div class="cc-quick-icon">📍</div>
            <h4> campus → Disco/KK's</h4>
            <p>Late night rides popular among students.</p>
            <span style="color: #0f6e56; font-weight: 600; font-size: 13px;">⏱️ ~8 min trip</span>
        </div>

        <div class="cc-quick-card">
            <div class="cc-quick-icon">📍</div>
            <h4>Town → Campus</h4>
            <p>Popular beginning of the month or when students recieve allowances.</p>
            <span style="color: #0f6e56; font-weight: 600; font-size: 13px;">⏱️ ~8 min trip</span>
        </div>

        <div class="cc-quick-card">
            <div class="cc-quick-icon">📍</div>
            <h4>Bus Rank → Campus</h4>
            <p>For students arriving and leaving campus.</p>
            <span style="color: #0f6e56; font-weight: 600; font-size: 13px;">⏱️ ~10 min trip</span>
        </div>

    </div>
</section>


<!-- ================= CTA ================= -->
<section class="cc-quick" style="background: linear-gradient(135deg, #0f1e3d 0%, #1a2b52 100%); text-align: center;">
    <div class="cc-quick-header" style="margin-bottom: 25px;">
        <h2 style="color: white;">Ready to Book Your Ride?</h2>
        <p style="color: rgba(255,255,255,0.8);">We're ready when you are.</p>
    </div>

    <div class="cc-hero-buttons" style="justify-content: center;">
        <a href="register.php" class="cc-btn cc-btn-primary">📝 Register</a>
        <?php if (!$isLoggedIn): ?>
            <a href="login.php" class="cc-btn cc-btn-outline">🔑 Login</a>
        <?php endif; ?>
    </div>
</section>

<?php include 'footer.php'; ?>