<?php
session_start();
require_once __DIR__ . '/db_connect.php';

$isStudent = isset($_SESSION['student_id']);
$isStaff   = isset($_SESSION['staff_id']);
if (!$isStudent && !$isStaff) { header('Location: login.php'); exit; }

$userID = $isStudent ? (int)$_SESSION['student_id'] : (int)$_SESSION['staff_id'];
$userColumn = $isStudent ? 'studentID' : 'staff_id';
$dashboard = $isStudent ? 'student_dashboard.php' : 'staff_dashboard.php';
$rideID = (int)($_GET['ride_id'] ?? $_POST['ride_id'] ?? 0);
if ($rideID <= 0) { header('Location: ' . $dashboard); exit; }

$st = $conn->prepare("SELECT rideID AS item_id, estimated_price AS amount, ride_status, pickup_address AS origin, destination_address AS destination FROM ride WHERE rideID=? AND $userColumn=? AND ride_status='Completed' LIMIT 1");
$st->bind_param('ii', $rideID, $userID);
$st->execute();
$item = $st->get_result()->fetch_assoc();
$st->close();
if (!$item) { header('Location: ' . $dashboard); exit; }

$amount = (float)$item['amount'];
$check = $conn->prepare("SELECT payment_id,payment_status,payment_method,total_amount,paid_at FROM payment WHERE ride_id=? LIMIT 1");
$check->bind_param('i', $rideID);
$check->execute();
$existing = $check->get_result()->fetch_assoc();
$check->close();

if ($existing && strcasecmp((string)$existing['payment_status'], 'Paid') === 0) {
    header('Location: payment_success.php?ride_id=' . $rideID);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $method = (string)($_POST['payment_method'] ?? 'Cash');
    if (!in_array($method, ['Cash', 'Card'], true)) $method = 'Cash';

    if ($method === 'Card') {
        header('Location: card_payment.php?type=ride&id=' . $rideID);
        exit;
    }

    if ($existing) {
        $paymentID = (int)$existing['payment_id'];
        $u = $conn->prepare("UPDATE payment SET payment_method='Cash', payment_status='Paid', paid_at=NOW(), item_cost=0, delivery_fee=?, total_amount=? WHERE payment_id=? AND ride_id=?");
        $u->bind_param('ddii', $amount, $amount, $paymentID, $rideID);
        $u->execute();
        $u->close();
    } else {
        // payment_id is not AUTO_INCREMENT in the actual database export.
        $result = $conn->query("SELECT COALESCE(MAX(payment_id),0)+1 AS next_id FROM payment");
        $paymentID = (int)$result->fetch_assoc()['next_id'];
        $i = $conn->prepare("INSERT INTO payment (payment_id, ride_id, item_cost, delivery_fee, total_amount, payment_method, payment_status, paid_at) VALUES (?, ?, 0, ?, ?, 'Cash', 'Paid', NOW())");
        $i->bind_param('iidd', $paymentID, $rideID, $amount, $amount);
        $i->execute();
        $i->close();
    }
    header('Location: payment_success.php?ride_id=' . $rideID);
    exit;
}

$pageTitle = 'Ride Payment';
include 'header.php';
?>
<div style="max-width:650px;margin:40px auto;padding:25px;background:#fff;border-radius:14px;box-shadow:0 5px 20px rgba(0,0,0,.08)">
    <h1>💳 Ride Payment</h1>
    <p>Ride #<?php echo $rideID; ?></p>
    <p><strong>Amount: R<?php echo number_format($amount,2); ?></strong></p>
    <form method="post">
        <input type="hidden" name="ride_id" value="<?php echo $rideID; ?>">
        <label for="payment_method">Payment method</label>
        <select id="payment_method" name="payment_method" style="display:block;width:100%;padding:12px;margin:8px 0 18px">
            <option value="Cash">Cash</option>
            <option value="Card">Card</option>
        </select>
        <button type="submit" style="padding:12px 20px;border:0;border-radius:8px;background:#0f6e56;color:#fff;font-weight:700">Continue</button>
    </form>
    <p style="margin-top:20px;color:#666">Choosing Card opens the secure CampusCab card-payment page, where you can enter a new card or use your saved card.</p>
</div>
<?php include 'footer.php'; ?>
