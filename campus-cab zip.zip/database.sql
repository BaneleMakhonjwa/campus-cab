CREATE DATABASE IF NOT EXISTS campus_cab_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campus_cab_db;
SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS ride_passenger_verification, safety_pin, driver_ratings, payment, location,
  driver_messages, driver_emergency_contacts, parcel, ride, vehicle, campus_location,
  audit_log, admin, staff, driver, student;

CREATE TABLE student (
  studentID INT AUTO_INCREMENT PRIMARY KEY,
  studentNumber VARCHAR(20) UNIQUE,
  studentFname VARCHAR(50) NOT NULL,
  studentLname VARCHAR(50) NOT NULL,
  studentEmail VARCHAR(120) NOT NULL UNIQUE,
  studentPhoneNo VARCHAR(20) NOT NULL UNIQUE,
  studentAccount_status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  password VARCHAR(255) NOT NULL,
  verification_token VARCHAR(64) NULL,
  token_expiry DATETIME NULL,
  email_verified TINYINT(1) NOT NULL DEFAULT 0,
  reset_token VARCHAR(255) NULL,
  reset_expiry DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE staff (
  staffID INT AUTO_INCREMENT PRIMARY KEY,
  staffNumber VARCHAR(30) UNIQUE,
  staffFname VARCHAR(50) NOT NULL,
  staffLname VARCHAR(50) NOT NULL,
  staffEmail VARCHAR(120) NOT NULL UNIQUE,
  staffPhoneNo VARCHAR(20) NOT NULL UNIQUE,
  staffAccount_status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  staffPwd VARCHAR(255) NOT NULL,
  reset_token VARCHAR(255) NULL,
  reset_expiry DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE admin (
  adminID INT AUTO_INCREMENT PRIMARY KEY,
  adminUsername VARCHAR(50) NOT NULL UNIQUE,
  adminFname VARCHAR(50) NOT NULL,
  adminLname VARCHAR(50) NOT NULL,
  adminEmail VARCHAR(120) NOT NULL UNIQUE,
  adminPwd VARCHAR(255) NOT NULL,
  adminRole ENUM('admin','super_admin') NOT NULL DEFAULT 'admin',
  accountStatus ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  createdBy INT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX(createdBy),
  CONSTRAINT fk_admin_creator FOREIGN KEY(createdBy) REFERENCES admin(adminID) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO admin (adminUsername,adminFname,adminLname,adminEmail,adminPwd,adminRole,accountStatus) VALUES
('admin','Campus','Administrator','admin@campuscab.local','$2y$12$iEor4p7q39ikxJN/hPiUXOzj8Js8rT3NPgvCe5C1n6.c4Pe9s8uWS','super_admin','Active');

CREATE TABLE audit_log (
  logID INT AUTO_INCREMENT PRIMARY KEY,
  userID INT NULL,
  userRole VARCHAR(30) NULL,
  userName VARCHAR(120) NULL,
  action VARCHAR(255) NOT NULL,
  targetType VARCHAR(50) NULL,
  targetID INT NULL,
  targetName VARCHAR(150) NULL,
  logDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX(logDate)
) ENGINE=InnoDB;

CREATE TABLE driver (
  DriverID INT AUTO_INCREMENT PRIMARY KEY,
  DriverFname VARCHAR(50) NOT NULL,
  DriverLname VARCHAR(50) NOT NULL,
  DriverEmail VARCHAR(120) NOT NULL UNIQUE,
  DriverPhoneNo VARCHAR(20) NOT NULL UNIQUE,
  DriverIDNumber VARCHAR(30) UNIQUE,
  DriverGender VARCHAR(20) NULL,
  DriverAddress VARCHAR(255) NULL,
  driverAccount_Status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  approval_status ENUM('Pending','Approved','Rejected','Suspended') NOT NULL DEFAULT 'Pending',
  licence_number VARCHAR(50) NULL UNIQUE,
  availability_status ENUM('Available','Unavailable') NOT NULL DEFAULT 'Unavailable',
  DriverPwd VARCHAR(255) NOT NULL,
  DriverPhoto VARCHAR(255) NULL,
  VehicleReg VARCHAR(30) NULL,
  VehicleModel VARCHAR(60) NULL,
  vehicle_type VARCHAR(40) NULL,
  vehicle_color VARCHAR(30) NULL,
  vehicle_capacity INT NULL,
  vehicle_make VARCHAR(60) NULL,
  VehiclePhoto VARCHAR(255) NULL,
  verification_token VARCHAR(64) NULL,
  token_expiry DATETIME NULL,
  email_verified TINYINT(1) NOT NULL DEFAULT 0,
  verification_otp VARCHAR(10) NULL,
  otp_expiry DATETIME NULL,
  phone_verified TINYINT(1) NOT NULL DEFAULT 0,
  is_online TINYINT(1) NOT NULL DEFAULT 0,
  last_seen DATETIME NULL,
  reviewed_by INT NULL,
  reviewed_at DATETIME NULL,
  review_notes TEXT NULL,
  reset_token VARCHAR(255) NULL,
  reset_expiry DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX(reviewed_by),
  INDEX(is_online,last_seen)
) ENGINE=InnoDB;

CREATE TABLE campus_location (
  location_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  latitude DECIMAL(10,7) NOT NULL,
  longitude DECIMAL(10,7) NOT NULL
) ENGINE=InnoDB;

INSERT INTO campus_location(name,latitude,longitude) VALUES
('Beda Hall',-32.7830000,26.8430000),
('Steve Biko Hall',-32.7810000,26.8400000),
('Chris Hani Hall',-32.7845000,26.8410000),
('Student Village',-32.7855000,26.8465000),
('Main Library',-32.7850000,26.8460000),
('Science Building',-32.7845000,26.8455000),
('Admin Building',-32.7838000,26.8442000),
('Sports Field',-32.7862000,26.8420000),
('Main Gate',-32.7800000,26.8390000),
('Student Centre',-32.7833000,26.8448000);

CREATE TABLE vehicle (
  vehicle_id INT AUTO_INCREMENT PRIMARY KEY,
  DriverID INT NOT NULL,
  registration_no VARCHAR(30) NOT NULL UNIQUE,
  make VARCHAR(60) NULL,
  model VARCHAR(60) NULL,
  colour VARCHAR(30) NULL,
  capacity INT NULL,
  FOREIGN KEY(DriverID) REFERENCES driver(DriverID) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE ride (
  rideID INT AUTO_INCREMENT PRIMARY KEY,
  studentID INT NULL,
  staffID INT NULL,
  DriverID INT NULL,
  requester_type ENUM('Student','Staff') NOT NULL DEFAULT 'Student',
  request_type ENUM('Ride','Parcel') NOT NULL DEFAULT 'Ride',
  parcel_details TEXT NULL,
  pickup_address VARCHAR(250) NULL,
  pickup_latitude DECIMAL(10,7) NULL,
  pickup_longitude DECIMAL(10,7) NULL,
  destination_address VARCHAR(250) NULL,
  destination_latitude DECIMAL(10,7) NULL,
  destination_longitude DECIMAL(10,7) NULL,
  requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  accepted_at DATETIME NULL,
  accepted_by INT NULL,
  started_at DATETIME NULL,
  Completed_at DATETIME NULL,
  ride_status ENUM('Requested','Accepted','Driver Arriving','In Progress','Completed','Cancelled') NOT NULL DEFAULT 'Requested',
  cancellation_reason VARCHAR(255) NULL,
  cancelled_at DATETIME NULL,
  estimated_distance_km DECIMAL(8,2) NULL,
  estimated_duration_min INT NULL,
  estimated_price DECIMAL(10,2) NULL,
  driver_earning DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  campus_commission DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  driver_earnings DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  paid_out TINYINT(1) NOT NULL DEFAULT 0,
  notified_drivers TEXT NULL,
  INDEX(studentID), INDEX(staffID), INDEX(DriverID), INDEX(ride_status), INDEX(requested_at),
  FOREIGN KEY(studentID) REFERENCES student(studentID) ON DELETE SET NULL,
  FOREIGN KEY(staffID) REFERENCES staff(staffID) ON DELETE SET NULL,
  FOREIGN KEY(DriverID) REFERENCES driver(DriverID) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE parcel (
  parcelID INT AUTO_INCREMENT PRIMARY KEY,
  studentID INT NULL,
  staffID INT NULL,
  DriverID INT NULL,
  parcel_description TEXT NOT NULL,
  parcel_size ENUM('Small','Medium','Large','Extra Large') NOT NULL,
  recipient_name VARCHAR(120) NOT NULL,
  recipient_contact VARCHAR(20) NOT NULL,
  pickup_location VARCHAR(255) NOT NULL,
  destination VARCHAR(255) NOT NULL,
  delivery_method ENUM('On-Campus','Off-Campus') NOT NULL DEFAULT 'On-Campus',
  estimated_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  parcel_status ENUM('Requested','Accepted','In Progress','Completed','Cancelled') NOT NULL DEFAULT 'Requested',
  requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  accepted_at DATETIME NULL,
  completed_at DATETIME NULL,
  cancelled_at DATETIME NULL,
  cancellation_reason VARCHAR(255) NULL,
  INDEX(studentID), INDEX(staffID), INDEX(DriverID), INDEX(parcel_status), INDEX(requested_at),
  FOREIGN KEY(studentID) REFERENCES student(studentID) ON DELETE SET NULL,
  FOREIGN KEY(staffID) REFERENCES staff(staffID) ON DELETE SET NULL,
  FOREIGN KEY(DriverID) REFERENCES driver(DriverID) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE location (
  location_id INT AUTO_INCREMENT PRIMARY KEY,
  ride_id INT NULL,
  parcel_id INT NULL,
  driver_id INT NOT NULL,
  latitude DECIMAL(10,7) NOT NULL,
  longitude DECIMAL(10,7) NOT NULL,
  recorded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX(ride_id), INDEX(parcel_id), INDEX(driver_id,recorded_at),
  FOREIGN KEY(ride_id) REFERENCES ride(rideID) ON DELETE CASCADE,
  FOREIGN KEY(parcel_id) REFERENCES parcel(parcelID) ON DELETE CASCADE,
  FOREIGN KEY(driver_id) REFERENCES driver(DriverID) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE payment (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  ride_id INT NULL UNIQUE,
  parcel_id INT NULL UNIQUE,
  studentID INT NULL,
  staffID INT NULL,
  passenger_type ENUM('student','staff') NULL,
  item_cost DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  delivery_fee DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  total_amount DECIMAL(10,2) NOT NULL,
  payment_method ENUM('Cash','Card','EFT') NOT NULL DEFAULT 'Cash',
  payment_status ENUM('Pending','Paid','Failed') NOT NULL DEFAULT 'Pending',
  paid_at DATETIME NULL,
  FOREIGN KEY(ride_id) REFERENCES ride(rideID) ON DELETE CASCADE,
  FOREIGN KEY(parcel_id) REFERENCES parcel(parcelID) ON DELETE CASCADE,
  FOREIGN KEY(studentID) REFERENCES student(studentID) ON DELETE SET NULL,
  FOREIGN KEY(staffID) REFERENCES staff(staffID) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE driver_ratings (
  ratingID INT AUTO_INCREMENT PRIMARY KEY,
  rideID INT NOT NULL UNIQUE,
  studentID INT NULL,
  staff_id INT NULL,
  passenger_type ENUM('student','staff') NOT NULL,
  DriverID INT NOT NULL,
  rating TINYINT NOT NULL,
  comment VARCHAR(500) NULL,
  rated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX(DriverID),
  FOREIGN KEY(rideID) REFERENCES ride(rideID) ON DELETE CASCADE,
  FOREIGN KEY(studentID) REFERENCES student(studentID) ON DELETE SET NULL,
  FOREIGN KEY(staff_id) REFERENCES staff(staffID) ON DELETE SET NULL,
  FOREIGN KEY(DriverID) REFERENCES driver(DriverID) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE safety_pin (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_type ENUM('student','staff') NOT NULL,
  user_id INT NOT NULL,
  pin_hash VARCHAR(255) NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_safety_user(user_type,user_id)
) ENGINE=InnoDB;

CREATE TABLE ride_passenger_verification (
  rideID INT PRIMARY KEY,
  verification_status ENUM('Pending','Verified') NOT NULL DEFAULT 'Pending',
  verified_at DATETIME NULL,
  verified_by_driver INT NULL,
  FOREIGN KEY(rideID) REFERENCES ride(rideID) ON DELETE CASCADE,
  FOREIGN KEY(verified_by_driver) REFERENCES driver(DriverID) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE driver_emergency_contacts (
  contactID INT AUTO_INCREMENT PRIMARY KEY,
  DriverID INT NOT NULL,
  contact_name VARCHAR(120) NOT NULL,
  relationship VARCHAR(60) NOT NULL,
  phone_number VARCHAR(20) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX(DriverID),
  FOREIGN KEY(DriverID) REFERENCES driver(DriverID) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE driver_messages (
  messageID INT AUTO_INCREMENT PRIMARY KEY,
  DriverID INT NOT NULL,
  sender_type VARCHAR(30) NOT NULL DEFAULT 'Admin',
  subject VARCHAR(255) NOT NULL,
  message_text TEXT NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX(DriverID),
  FOREIGN KEY(DriverID) REFERENCES driver(DriverID) ON DELETE CASCADE
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS=1;
