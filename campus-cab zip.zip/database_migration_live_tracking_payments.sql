-- CampusCab upgrade for live driver tracking and parcel payments.
-- Safe for an existing CampusCab database. The checks make this migration
-- repeatable on databases that already contain some of the newer columns.
USE campus_cab_db;
SET @db := DATABASE();

-- location.parcel_id
SET @sql := IF(NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='location' AND COLUMN_NAME='parcel_id'), 'ALTER TABLE location ADD COLUMN parcel_id INT NULL AFTER ride_id', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF(NOT EXISTS (SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='location' AND INDEX_NAME='idx_location_parcel_id'), 'ALTER TABLE location ADD INDEX idx_location_parcel_id (parcel_id)', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF(NOT EXISTS (SELECT 1 FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=@db AND TABLE_NAME='location' AND CONSTRAINT_NAME='fk_location_parcel'), 'ALTER TABLE location ADD CONSTRAINT fk_location_parcel FOREIGN KEY (parcel_id) REFERENCES parcel(parcelID) ON DELETE CASCADE', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- payment.parcel_id must exist before studentID/staffID/passenger_type are positioned after it.
SET @sql := IF(NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='payment' AND COLUMN_NAME='parcel_id'), 'ALTER TABLE payment ADD COLUMN parcel_id INT NULL AFTER ride_id', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF(NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='payment' AND COLUMN_NAME='studentID'), 'ALTER TABLE payment ADD COLUMN studentID INT NULL AFTER parcel_id', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF(NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='payment' AND COLUMN_NAME='staffID'), 'ALTER TABLE payment ADD COLUMN staffID INT NULL AFTER studentID', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF(NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='payment' AND COLUMN_NAME='passenger_type'), 'ALTER TABLE payment ADD COLUMN passenger_type ENUM(''student'',''staff'') NULL AFTER staffID', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- Existing ride payments must allow parcel-only rows to have ride_id = NULL.
SET @sql := IF(EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='payment' AND COLUMN_NAME='ride_id' AND IS_NULLABLE='NO'), 'ALTER TABLE payment MODIFY ride_id INT NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF(NOT EXISTS (SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='payment' AND INDEX_NAME='uq_payment_parcel'), 'ALTER TABLE payment ADD UNIQUE KEY uq_payment_parcel (parcel_id)', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF(NOT EXISTS (SELECT 1 FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=@db AND TABLE_NAME='payment' AND CONSTRAINT_NAME='fk_payment_parcel'), 'ALTER TABLE payment ADD CONSTRAINT fk_payment_parcel FOREIGN KEY (parcel_id) REFERENCES parcel(parcelID) ON DELETE CASCADE', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF(NOT EXISTS (SELECT 1 FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=@db AND TABLE_NAME='payment' AND CONSTRAINT_NAME='fk_payment_student'), 'ALTER TABLE payment ADD CONSTRAINT fk_payment_student FOREIGN KEY (studentID) REFERENCES student(studentID) ON DELETE SET NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF(NOT EXISTS (SELECT 1 FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=@db AND TABLE_NAME='payment' AND CONSTRAINT_NAME='fk_payment_staff'), 'ALTER TABLE payment ADD CONSTRAINT fk_payment_staff FOREIGN KEY (staffID) REFERENCES staff(staffID) ON DELETE SET NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
