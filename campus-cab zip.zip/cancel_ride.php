<?php
session_start();
include_once __DIR__ . '/db_connect.php';

$requestedAs = strtolower(trim((string)($_POST['as'] ?? $_GET['as'] ?? '')));
$isStudent = isset($_SESSION['student_id']) && (int)$_SESSION['student_id'] > 0;
$isStaff   = isset($_SESSION['staff_id']) && (int)$_SESSION['staff_id'] > 0;

if (!$isStudent && !$isStaff) {
    header("Location: login.php");
    exit;
}

if ($requestedAs === 'staff' && $isStaff) {
    $userID = (int)$_SESSION['staff_id'];
    $userColumn = 'staff_id';
    $dashboardLink = 'staff_dashboard.php';
} elseif ($requestedAs === 'student' && $isStudent) {
    $userID = (int)$_SESSION['student_id'];
    $userColumn = 'studentID';
    $dashboardLink = 'student_dashboard.php';
} elseif ($isStudent) {
    $userID = (int)$_SESSION['student_id'];
    $userColumn = 'studentID';
    $dashboardLink = 'student_dashboard.php';
} else {
    $userID = (int)$_SESSION['staff_id'];
    $userColumn = 'staff_id';
    $dashboardLink = 'staff_dashboard.php';
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: " . $dashboardLink);
    exit;
}

$rideID = (int)($_POST['rideID'] ?? 0);
$reason = trim($_POST['reason'] ?? 'No reason given');

if ($rideID <= 0) {
    header("Location: " . $dashboardLink);
    exit;
}

$driverID = 0;
$check = $conn->prepare("SELECT DriverID FROM ride WHERE rideID = ? AND $userColumn = ? AND ride_status IN ('Requested','Accepted','Driver Arriving','In Progress') LIMIT 1");
$check->bind_param('ii', $rideID, $userID);
$check->execute();
$row = $check->get_result()->fetch_assoc();
$check->close();

if ($row) {
    $driverID = (int)($row['DriverID'] ?? 0);
    $stmt = $conn->prepare("
        UPDATE ride
        SET ride_status = 'Cancelled', cancelled_at = NOW(), cancellation_reason = ?
        WHERE rideID = ? AND $userColumn = ?
          AND ride_status IN ('Requested', 'Accepted', 'Driver Arriving', 'In Progress')
    " );
    $stmt->bind_param('sii', $reason, $rideID, $userID);
    $stmt->execute();
    $ok = $stmt->affected_rows === 1;
    $stmt->close();

    if ($ok) {
        if ($driverID > 0) {
            $free = $conn->prepare("UPDATE driver SET availability_status = 'Available' WHERE DriverID = ?");
            $free->bind_param('i', $driverID);
            $free->execute();
            $free->close();
        }
        $_SESSION['ride_success'] = 'Ride cancelled successfully. Reason: ' . $reason;
    } else {
        $_SESSION['ride_error'] = 'Unable to cancel ride.';
    }
} else {
    $_SESSION['ride_error'] = 'This ride cannot be cancelled because it is no longer active.';
}

header('Location: ' . $dashboardLink);
exit;
?>