<?php
session_start();
include_once __DIR__ . '/db_connect.php';

$requestedAs = strtolower(trim((string)($_GET['as'] ?? '')));
$isStudent = isset($_SESSION['student_id']) && (int)$_SESSION['student_id'] > 0;
$isStaff   = isset($_SESSION['staff_id']) && (int)$_SESSION['staff_id'] > 0;

if (!$isStudent && !$isStaff) {
    header("Location: login.php");
    exit;
}

if ($requestedAs === 'staff' && $isStaff) {
    $requesterType = 'staff';
    $userID = (int)$_SESSION['staff_id'];
    $dashboardLink = 'staff_dashboard.php';
} elseif ($requestedAs === 'student' && $isStudent) {
    $requesterType = 'student';
    $userID = (int)$_SESSION['student_id'];
    $dashboardLink = 'student_dashboard.php';
} elseif (strtolower((string)($_SESSION['role'] ?? '')) === 'staff' && $isStaff) {
    $requesterType = 'staff';
    $userID = (int)$_SESSION['staff_id'];
    $dashboardLink = 'staff_dashboard.php';
} elseif ($isStudent) {
    $requesterType = 'student';
    $userID = (int)$_SESSION['student_id'];
    $dashboardLink = 'student_dashboard.php';
} else {
    $requesterType = 'staff';
    $userID = (int)$_SESSION['staff_id'];
    $dashboardLink = 'staff_dashboard.php';
}

$ownerColumn = $requesterType === 'student' ? 'p.studentID' : 'p.staff_id';
$stmt = $conn->prepare("
    SELECT p.parcel AS parcelID, p.studentID, p.parcel_description, p.parcel_size, p.recipient_name, p.recipient_contact, p.pickup_location, p.destination, p.estimated_price, p.DriverID, p.requested_at, p.completed_at, p.parcel_status, p.delivery_method, p.staff_id, d.DriverFname, d.DriverLname, pp.payment_status AS parcel_payment_status
    FROM parcel p
    LEFT JOIN driver d ON p.DriverID = d.DriverID
    LEFT JOIN parcel_payment pp ON pp.parcel = p.parcel
    WHERE $ownerColumn = ?
    ORDER BY p.requested_at DESC
");
$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();



$pageTitle = "Parcel Services";
include 'header.php';
?>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"><script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
.parcels-page { max-width: 1100px; margin: 0 auto; padding: 35px 25px 60px; }
.parcels-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 20px; flex-wrap: wrap; margin-bottom: 25px; }
.parcels-head h1 { color: #0c2d4d; font-size: 28px; font-weight: 800; margin: 0 0 6px; }
.parcels-head p { color: #6b7280; margin: 0; font-size: 15px; }
.btn-back { padding: 11px 18px; background: #0c2d4d; color: #fff; text-decoration: none; border-radius: 8px; font-size: 14px; font-weight: 600; }
.btn-back:hover { background: #185fa5; }
.btn-new { display: inline-block; padding: 12px 22px; background: #0c2d4d; color: #fff; text-decoration: none; border-radius: 8px; font-weight: 700; font-size: 14px; margin-bottom: 25px; }
.btn-new:hover { background: #185fa5; }
.parcels-empty { background: #fff; border: 1px solid #e2e2dc; border-radius: 14px; padding: 60px 30px; text-align: center; color: #6b7280; }
.parcels-empty h3 { color: #0c2d4d; margin: 0 0 8px; font-size: 20px; }
.parcels-empty a { color: #185fa5; font-weight: 700; text-decoration: none; }
.parcels-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 18px; }
.parcel-item { background: #fff; border: 1px solid #e2e2dc; border-radius: 14px; padding: 22px; box-shadow: 0 4px 14px rgba(11,31,58,0.05); }
.parcel-item-head { display: flex; justify-content: space-between; align-items: center; padding-bottom: 12px; border-bottom: 1px solid #f0f1f3; margin-bottom: 14px; }
.parcel-item-head h3 { color: #0c2d4d; font-size: 15px; margin: 0; }
.status-pill { padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
.status-requested { background: #fbecc9; color: #8a6d00; }
.status-accepted { background: #dbe8fb; color: #185fa5; }
.status-in-progress { background: #fef3c7; color: #b8860b; }
.status-completed { background: #dcf1e9; color: #0f6e56; }
.status-cancelled { background: #fbe2df; color: #b03a2e; }
.parcel-row { display: flex; justify-content: space-between; padding: 7px 0; font-size: 13.5px; }
.parcel-row .label { color: #6b7280; font-weight: 600; }
.parcel-row .value { color: #172033; text-align: right; max-width: 60%; }
.parcel-price { background: #dcf1e9; color: #0f6e56; padding: 12px; border-radius: 8px; margin-top: 14px; font-weight: 800; font-size: 16px; text-align: center; }
</style>

<div class="parcels-page">

    <div class="parcels-head">
        <div>
            <h1>📦 Parcel Services</h1>
            <p>View your parcel collection and delivery history.</p>
        </div>
        <a href="<?php echo $dashboardLink; ?>" class="btn-back">← Back to Dashboard</a>
    </div>

    <?php if (isset($_SESSION['parcel_success'])): ?>
        <div style="background:#dcf1e9;color:#0f6e56;padding:14px;border-radius:8px;margin-bottom:20px;font-weight:600;">
            ✅ <?php echo htmlspecialchars($_SESSION['parcel_success']); unset($_SESSION['parcel_success']); ?>
        </div>
    <?php endif; ?>

    <a href="request_parcel.php?as=<?php echo $requesterType; ?>" class="btn-new">+ Parcel Services</a><div id="parcelDriverMap" style="height:360px;border-radius:14px;border:1px solid #e2e2dc;margin-bottom:25px"></div>

    <?php if ($result->num_rows === 0): ?>

        <div class="parcels-empty">
            <h3>No parcels yet</h3>
            <p>You haven't used any parcel services.</p>
            <br>
            <a href="request_parcel.php?as=<?php echo $requesterType; ?>">Use Parcel Services →</a>
        </div>

    <?php else: ?>

        <div class="parcels-grid">
            <?php while ($p = $result->fetch_assoc()): ?>
                <?php
                $statusClass = strtolower(str_replace(' ', '-', $p['parcel_status']));
                $driverName = trim(($p['DriverFname'] ?? '') . ' ' . ($p['DriverLname'] ?? ''));
                ?>
                <div class="parcel-item">
                    <div class="parcel-item-head">
                        <h3>Parcel #<?php echo (int)$p['parcelID']; ?></h3>
                        <span class="status-pill status-<?php echo $statusClass; ?>">
                            <?php echo htmlspecialchars($p['parcel_status']); ?>
                        </span>
                    </div>

                    <div class="parcel-row"><span class="label">Pickup</span><span class="value"><?php echo htmlspecialchars($p['pickup_location']); ?></span></div>
                    <div class="parcel-row"><span class="label">Destination</span><span class="value"><?php echo htmlspecialchars($p['destination']); ?></span></div>
                    <div class="parcel-row"><span class="label">Size</span><span class="value"><?php echo htmlspecialchars($p['parcel_size']); ?></span></div>
                    <div class="parcel-row"><span class="label">Recipient</span><span class="value"><?php echo htmlspecialchars($p['recipient_name']); ?></span></div>
                    <?php if ($driverName): ?>
                        <div class="parcel-row"><span class="label">Driver</span><span class="value"><?php echo htmlspecialchars($driverName); ?></span></div>
                    <?php endif; ?>
                    <div class="parcel-row"><span class="label">Requested</span><span class="value"><?php echo date('d M Y, H:i', strtotime($p['requested_at'])); ?></span></div>

                    <div class="parcel-price">R<?php echo number_format((float)$p['estimated_price'], 2); ?></div>

                    <?php if ($p['parcel_status'] === 'Delivered' && !empty($p['DriverID'])): ?>
                        <?php
                        $parcelRatingCheck = $conn->prepare("SELECT ratingID FROM parcel_driver_ratings WHERE parcel = ? LIMIT 1");
                        $parcelRatingCheck->bind_param("i", $p['parcelID']);
                        $parcelRatingCheck->execute();
                        $parcelAlreadyRated = $parcelRatingCheck->get_result()->num_rows > 0;
                        $parcelRatingCheck->close();
                        ?>
                        <?php if (!$parcelAlreadyRated): ?>
                            <a href="rate_parcel_driver.php?parcel_id=<?php echo (int)$p['parcelID']; ?>&as=<?php echo urlencode($requesterType); ?>" style="display:block;margin-top:12px;padding:11px 16px;background:#e0a526;color:#0c2d4d;border-radius:8px;text-align:center;text-decoration:none;font-weight:800;">★ Rate Delivery Driver</a>
                        <?php else: ?>
                            <div style="margin-top:12px;color:#0f6e56;font-weight:700;text-align:center;">★ Delivery Driver Rated</div>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if ($p['parcel_status'] === 'Delivered'): ?>
                        <?php if (($p['parcel_payment_status'] ?? '') === 'Paid'): ?>
                            <div style="margin-top:12px;color:#0f6e56;font-weight:700;text-align:center;">✅ Paid</div>
                        <?php else: ?>
                            <a href="process_parcel_payment.php?parcel_id=<?php echo (int)$p['parcelID']; ?>" style="display:block;margin-top:12px;padding:11px 16px;background:#0f6e56;color:#fff;border-radius:8px;text-align:center;text-decoration:none;font-weight:700;">💳 Pay for Parcel</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        </div>

    <?php endif; ?>

</div>

<script>
const parcelMap=L.map('parcelDriverMap').setView([-32.7833,26.8448],13); L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(parcelMap);
const parcelMarkers=new Map(); const assignedParcelMarkers=new Map();
const trackedParcelIds=[<?php
    $tracked=[];
    $result->data_seek(0);
    while($tp=$result->fetch_assoc()){ if(!empty($tp['DriverID']) && in_array($tp['parcel_status'],['Accepted','In Progress'],true)) $tracked[]=(int)$tp['parcelID']; }
    echo implode(',', $tracked);
?>];
const carIcon=L.divIcon({html:'<div style="background:#0c2d4d;color:#fff;border-radius:50%;width:38px;height:38px;display:flex;align-items:center;justify-content:center;font-size:21px;border:3px solid #fff;box-shadow:0 2px 9px rgba(0,0,0,.35);">🚗</div>',className:'',iconSize:[38,38],iconAnchor:[19,19]});
function refreshOnlineDrivers(){fetch('get_online_drivers.php',{credentials:'same-origin',cache:'no-store'}).then(r=>r.json()).then(d=>{if(!d.success)return;const seen=new Set();d.drivers.forEach(x=>{if(x.latitude===null||x.longitude===null)return;const id=String(x.DriverID);seen.add(id);let m=parcelMarkers.get(id);if(!m){m=L.marker([x.latitude,x.longitude],{icon:carIcon}).addTo(parcelMap);parcelMarkers.set(id,m)}else m.setLatLng([x.latitude,x.longitude]);m.bindPopup('<strong>🚗 '+x.DriverFname+' '+x.DriverLname+'</strong><br>● Online');});parcelMarkers.forEach((m,id)=>{if(!seen.has(id)){parcelMap.removeLayer(m);parcelMarkers.delete(id)}})}).catch(()=>{})}
function refreshAssignedParcel(id){fetch('get_driver_location.php?parcel_id='+encodeURIComponent(id),{credentials:'same-origin',cache:'no-store'}).then(r=>r.json()).then(d=>{const key=String(id);if(!d.success||!d.driver_assigned||d.stale||d.lat===null||d.lng===null){const old=assignedParcelMarkers.get(key);if(old){parcelMap.removeLayer(old);assignedParcelMarkers.delete(key)}return;}let m=assignedParcelMarkers.get(key);if(!m){m=L.marker([d.lat,d.lng]).addTo(parcelMap);assignedParcelMarkers.set(key,m)}else m.setLatLng([d.lat,d.lng]);m.bindPopup('<strong>📦 Your parcel driver</strong><br>Live location updated '+(d.age_seconds??0)+'s ago');}).catch(()=>{})}
function refreshParcelMap(){refreshOnlineDrivers();trackedParcelIds.forEach(refreshAssignedParcel)} refreshParcelMap(); setInterval(refreshParcelMap,5000);
</script><?php include 'footer.php'; ?>