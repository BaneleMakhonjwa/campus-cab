<?php
session_start();
include_once __DIR__ . '/db_connect.php';

$pageTitle = "Help Center";
include 'header.php';
?>

<!-- ================= HERO ================= -->
<section class="cc-hero" style="padding: 60px 20px;">
    <div class="cc-hero-inner" style="grid-template-columns: 1fr; text-align: center;">
        <div class="cc-hero-text">
            <p class="cc-hero-label">— Help Center</p>
            <h1>How Can We <span>Help?</span></h1>
            <p class="cc-hero-desc" style="margin-left: auto; margin-right: auto;">
                Find answers to common questions about Campus Cab.
            </p>
        </div>
    </div>
</section>


<!-- ================= FAQ ================= -->
<section class="cc-quick">
    <div class="cc-quick-header" style="text-align: center;">
        <h2>Frequently Asked Questions</h2>
        <p>Everything you need to know about our service.</p>
    </div>

    <div class="cc-quick-cards" style="max-width: 900px; margin: 0 auto; grid-template-columns: 1fr;">

        <div class="cc-quick-card" style="padding: 25px;">
            <h4>🚗 How do I request a ride?</h4>
            <p>Simply log in, click "Book a Ride", enter your pickup and destination, and we'll assign a nearby driver.</p>
        </div>
         <div class="cc-quick-card" style="padding: 25px;">
            <h4>📦 How do I use parcel services?</h4>
            <p>Simply log in, click "parcel collection", enter your parcel pickup point, destination and parcel details, and we'll assign a nearby driver for collection.</p>
        </div>

        <div class="cc-quick-card" style="padding: 25px;">
            <h4>💰 How much does a ride cost?</h4>
            <p>Fares are calculated based on distance. You'll see the estimated price before confirming your ride.</p>
        </div>
         <div class="cc-quick-card" style="padding: 25px;">
            <h4>💰 How much does parcel collection cost?</h4>
            <p>It depends on the pickup point and destination( courier guy, main gate and res-res differ in prices).</p>
        </div>

        <div class="cc-quick-card" style="padding: 25px;">
            <h4>⏱️ How long will I wait?</h4>
            <p>Average wait times are 3–7 minutes during normal hours, and slightly longer during rush hours (07:00–09:00 and 16:00–18:30).</p>
        </div>

        <div class="cc-quick-card" style="padding: 25px;">
            <h4>🔐 Is my information safe?</h4>
            <p>Yes. We use secure password hashing and never share your personal information with third parties.</p>
        </div>

        <div class="cc-quick-card" style="padding: 25px;">
            <h4>🚗 How do I become a driver?</h4>
            <p>Click "Register" on the home page, select "Driver", and complete the form. Our admin team will review and approve your application.</p>
        </div>

    </div>
</section>


<!-- ================= SAFETY TIPS ================= -->
<section class="cc-quick" style="background: #f8f9fa;">
    <div class="cc-quick-header" style="text-align: center;">
        <h2>🛡️ Safety Tips</h2>
        <p>Your safety is our priority.</p>
    </div>

    <div class="cc-quick-cards" style="max-width: 1000px; margin: 0 auto; grid-template-columns: repeat(2, 1fr);">

        <div class="cc-quick-card">
            <div class="cc-quick-icon">✅</div>
            <h4>Verify Your Driver</h4>
            <p>Check the driver's name and vehicle registration before getting in.</p>
        </div>

        <div class="cc-quick-card">
            <div class="cc-quick-icon">📍</div>
            <h4>Share Your Trip</h4>
            <p>Let a friend know your route and expected arrival time.</p>
        </div>

        <div class="cc-quick-card">
            <div class="cc-quick-icon">📱</div>
            <h4>Keep Your Phone Charged</h4>
            <p>Make sure your phone is on so you can track your ride.</p>
        </div>

        <div class="cc-quick-card">
            <div class="cc-quick-icon">🚨</div>
            <h4>Report Issues</h4>
            <p>If something feels wrong, report it immediately through the website.</p>
        </div>

    </div>
</section>


<!-- ================= CTA ================= -->
<section class="cc-quick" style="background: linear-gradient(135deg, #0f1e3d 0%, #1a2b52 100%); text-align: center;">
    <div class="cc-quick-header" style="margin-bottom: 25px;">
        <h2 style="color: white;">Still Have Questions?</h2>
        <p style="color: rgba(255,255,255,0.8);">Our support team is here to help.</p>
    </div>

    <div class="cc-hero-buttons" style="justify-content: center;">
        <a href="contact.php" class="cc-btn cc-btn-primary">📞 Contact Us</a>
        <a href="mailto:225704411@ufh.co.za" class="cc-btn cc-btn-outline">📧 Email Support</a>
    </div>
</section>

<?php include 'footer.php'; ?>