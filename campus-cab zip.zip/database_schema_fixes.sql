-- CampusCab fixes based on the ACTUAL campus_cab_db schema.
-- Required for staff-owned rides and parcels because the live schema currently
-- marks studentID as NOT NULL even though both tables already have staff_id.

ALTER TABLE ride
    MODIFY studentID INT NULL;

ALTER TABLE parcel
    MODIFY studentID INT NULL;

