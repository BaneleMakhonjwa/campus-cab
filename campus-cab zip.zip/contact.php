<?php
session_start();
include_once __DIR__ . '/db_connect.php';

$pageTitle = "Contact Us";
include 'header.php';
?>

<!-- ================= HERO ================= -->
<section class="cc-hero" style="padding: 60px 20px;">
    <div class="cc-hero-inner" style="grid-template-columns: 1fr; text-align: center;">
        <div class="cc-hero-text">
            <p class="cc-hero-label">— Get in Touch</p>
            <h1>Contact <span>Campus Cab</span></h1>
            <p class="cc-hero-desc" style="margin-left: auto; margin-right: auto;">
                Have a question? Need help with a ride? We're here for you.
            </p>
        </div>
    </div>
</section>


<!-- ================= CONTACT CARDS ================= -->
<section class="cc-quick">
    <div class="cc-quick-header" style="text-align: center;">
        <h2>Ways to Reach Us</h2>
        <p>Choose whichever works best for you.</p>
    </div>

    <div class="cc-quick-cards" style="max-width: 1000px; margin: 0 auto; grid-template-columns: repeat(2, 1fr);">

        <a href="mailto:support@campuscab.co.za" class="cc-quick-card">
            <div class="cc-quick-icon">📧</div>
            <h4>Email Us</h4>
            <p>225704411@ufh.co.za</p>
            <span style="color: #0f6e56; font-weight: 600; font-size: 13px;">We reply within 24 hours</span>
        </a>

        <a href="tel:+27401234567" class="cc-quick-card">
            <div class="cc-quick-icon">📞</div>
            <h4>Call Us</h4>
            <p>+27 79 838 5564</p>
            <span style="color: #0f6e56; font-weight: 600; font-size: 13px;">Mon – Fri: 08:00 – 17:00</span>
        </a>

        <a href="https://wa.me/27798385564" target="_blank" class="cc-quick-card">
            <div class="cc-quick-icon">💬</div>
            <h4>WhatsApp</h4>
            <p>+27 79 838 5564</p>
            <span style="color: #0f6e56; font-weight: 600; font-size: 13px;">Quick responses</span>
        </a>

        <div class="cc-quick-card">
            <div class="cc-quick-icon">📍</div>
            <h4>Visit Us</h4>
            <p>University of Fort Hare<br>Alice Campus, Eastern Cape</p>
            <span style="color: #0f6e56; font-weight: 600; font-size: 13px;">Student Centre, Office 12</span>
        </div>

    </div>
</section>


<!-- ================= SOCIAL MEDIA ================= -->
<section class="cc-quick" style="background: #f8f9fa;">
    <div class="cc-quick-header" style="text-align: center;">
        <h2>Follow Us</h2>
        <p>Stay updated with news and announcements.</p>
    </div>

    <div class="cc-quick-cards" style="max-width: 900px; margin: 0 auto; grid-template-columns: repeat(3, 1fr);">

        <a href="#" class="cc-quick-card" style="text-align: center;">
            <div class="cc-quick-icon" style="font-size: 42px;">📘</div>
            <h4>Facebook</h4>
            <p>@CampusCabUFH</p>
        </a>

        <a href="https://www.instagram.com/uber/" class="cc-quick-card" style="text-align: center;">
            <div class="cc-quick-icon" style="font-size: 42px;">📸</div>
            <h4>Instagram</h4>
            <p>@campuscab_ufh</p>
        </a>

        <a href="#" class="cc-quick-card" style="text-align: center;">
            <div class="cc-quick-icon" style="font-size: 42px;">🐦</div>
            <h4>Twitter / X</h4>
            <p>@CampusCabUFH</p>
        </a>

    </div>
</section>


<!-- ================= SUPPORT HOURS ================= -->
<section class="cc-quick">
    <div class="cc-quick-header" style="text-align: center;">
        <h2>Support Hours</h2>
        <p>When you can expect to hear back from us.</p>
    </div>

    <div class="activity-table-wrapper" style="max-width: 700px; margin: 0 auto; overflow-x: auto; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
        <table class="activity-table">
            <thead>
                <tr>
                    <th>Day</th>
                    <th>Support Hours</th>
                    <th>Response Time</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Monday – Friday</td>
                    <td>08:00 – 17:00</td>
                    <td>Within 2 hours</td>
                </tr>
                <tr>
                    <td>Saturday</td>
                    <td>09:00 – 13:00</td>
                    <td>Within 4 hours</td>
                </tr>
                <tr>
                    <td>Sunday & Public/School Holidays</td>
                    <td>Closed</td>
                    <td>Next business day</td>
                </tr>
            </tbody>
        </table>
    </div>
</section>


<!-- ================= CTA ================= -->
<section class="cc-quick" style="background: linear-gradient(135deg, #0f1e3d 0%, #1a2b52 100%); text-align: center;">
    <div class="cc-quick-header" style="margin-bottom: 25px;">
        <h2 style="color: white;">Still Need Help?</h2>
        <p style="color: rgba(255,255,255,0.8);">Our team is ready to assist you.</p>
    </div>

    <div class="cc-hero-buttons" style="justify-content: center;">
        <a href="mailto:225704411@ufh.co.za" class="cc-btn cc-btn-primary">📧 Email Support</a>
        <a href="help.php" class="cc-btn cc-btn-outline">❓ Help Center</a>
    </div>
</section>

<?php include 'footer.php'; ?>