CampusCab Driver Ride Popup Fix

Replace the existing header.php with this version.

The 30-second New Ride Request popup is now shown ONLY when:
  $_SESSION['role'] === 'driver'
  and $_SESSION['driver_id'] is present.

Therefore it will not appear on student or staff requester pages even if an old/stale driver_id remains in the PHP session.

The popup remains available on driver pages and continues to use accept_ride.php and driver_active_ride.php.

Based on the actual campus_cab_db schema. PHP syntax checked with php -l.
