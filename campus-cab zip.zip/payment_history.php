<?php
// Legacy route retained for compatibility. Payment history is now handled by my_payments.php.
header('Location: my_payments.php');
exit;
?>
