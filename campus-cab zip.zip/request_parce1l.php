<?php
session_start();
include_once __DIR__ . '/db_connect.php';

$requestedAs = strtolower(trim((string)($_GET['as'] ?? '')));
$isStudent = !empty($_SESSION['student_id']); $isStaff = !empty($_SESSION['staff_id']);
if (!$isStudent && !$isStaff) { header('Location: login.php'); exit; }
if ($requestedAs === 'staff' && $isStaff) $parcelRequester='staff';
elseif ($requestedAs === 'student' && $isStudent) $parcelRequester='student';
elseif (strtolower((string)($_SESSION['role'] ?? '')) === 'staff' && $isStaff) $parcelRequester='staff';
elseif ($isStudent) $parcelRequester='student'; else $parcelRequester='staff';
$userID = $parcelRequester === 'student' ? (int)$_SESSION['student_id'] : (int)$_SESSION['staff_id'];
$dashboardLink = $parcelRequester === 'student' ? 'student_dashboard.php' : 'staff_dashboard.php';

$locations = [];
$result = $conn->query("SELECT location_id, name, latitude, longitude FROM campus_location ORDER BY name");
while ($row = $result->fetch_assoc()) $locations[] = $row;

$pageTitle = 'Parcel Services';
include 'header.php';
?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
.parcel-page{max-width:900px;margin:0 auto;padding:35px 25px 60px}.parcel-header h1{color:#0c2d4d;font-size:28px;font-weight:800;margin:0 0 6px}.parcel-header p{color:#6b7280;font-size:15px;margin:0 0 30px}.parcel-card,.driver-card{background:#fff;border:1px solid #e2e2dc;border-radius:14px;padding:30px;box-shadow:0 4px 14px rgba(11,31,58,.05);margin-bottom:20px}.parcel-section-title{color:#0c2d4d;font-size:16px;font-weight:700;margin:0 0 16px;padding-bottom:10px;border-bottom:1px solid #f0f1f3}.form-group{margin-bottom:18px}.form-group label{display:block;font-weight:600;font-size:14px;color:#0c2d4d;margin-bottom:6px}.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px;border:1px solid #dfe3e8;border-radius:8px;font-size:15px;font-family:inherit;box-sizing:border-box}.form-group small{display:block;color:#6b7280;font-size:12px;margin-top:5px}.form-row{display:grid;grid-template-columns:1fr 1fr;gap:15px}.toggle-row{display:flex;gap:10px;margin-bottom:18px}.toggle-btn{flex:1;padding:12px;border:2px solid #dfe3e8;background:#fff;border-radius:8px;cursor:pointer;font-weight:600;font-size:14px;color:#6b7280}.toggle-btn.active{border-color:#0c2d4d;background:#0c2d4d;color:#fff}.location-results{display:none;position:relative;z-index:1000;border:1px solid #dfe3e8;border-top:none;border-radius:0 0 8px 8px;background:#fff;box-shadow:0 6px 14px rgba(11,31,58,.12);max-height:240px;overflow-y:auto}.location-result{padding:10px 12px;cursor:pointer;border-bottom:1px solid #f0f1f3}.location-result:hover{background:#f5f8fb}.location-result small{display:block;color:#6b7280;font-size:11px;margin-top:3px}.mini-map{height:220px;border-radius:10px;margin-top:10px;border:1px solid #dfe3e8}.drivers-map{height:320px;min-height:320px;width:100%;display:block;position:relative;overflow:hidden;border-radius:12px;border:1px solid #dfe3e8;background:#e9eef2}.drivers-map .leaflet-container{height:100%;width:100%}; .drivers-map .leaflet-pane,.drivers-map .leaflet-tile-pane,.drivers-map .leaflet-overlay-pane,.drivers-map .leaflet-shadow-pane,.drivers-map .leaflet-marker-pane,.drivers-map .leaflet-tooltip-pane,.drivers-map .leaflet-popup-pane{position:absolute}.drivers-map .leaflet-tile{max-width:none!important;max-height:none!important}.btn-submit{width:100%;padding:14px;background:#0c2d4d;color:#fff;border:none;border-radius:8px;font-size:15px;font-weight:700;cursor:pointer;margin-top:10px}.btn-back{display:inline-block;padding:10px 18px;background:#6b7280;color:#fff;text-decoration:none;border-radius:8px;font-size:13px;font-weight:600;margin-bottom:20px}@media(max-width:600px){.form-row{grid-template-columns:1fr}.parcel-card,.driver-card{padding:20px}}
</style>
<div class="parcel-page">
<a href="<?php echo htmlspecialchars($dashboardLink); ?>" class="btn-back">← Back to Dashboard</a>
<div class="parcel-header"><h1>📦 Parcel Services</h1><p>Have a parcel collected from campus and delivered to your chosen destination.</p></div>
<form method="POST" action="save_parcel.php" id="parcelForm">
<input type="hidden" name="passenger_type" value="<?php echo htmlspecialchars($parcelRequester ?? (strtolower((string)($_SESSION['role'] ?? 'student')) === 'staff' ? 'staff' : 'student')); ?>">
<div class="parcel-card">
<h2 class="parcel-section-title">📍 Pickup Point</h2>
<div class="form-group">
<label for="pickupSearch">Search for a pickup location</label>
<input type="text" id="pickupSearch" placeholder="Search an address, place or landmark in Alice..." autocomplete="off">
<div id="pickupResults" class="location-results"></div>
<small>Search for a location, or choose a campus residence/saved campus location below.</small>
</div>
<div class="form-group">
<label for="pickupCampus">Campus residences / saved campus locations</label>
<select id="pickupCampus">
<option value="">-- Select Campus Location --</option>
<?php foreach($locations as $loc): ?><option value="<?php echo htmlspecialchars($loc['name']); ?>" data-lat="<?php echo htmlspecialchars($loc['latitude']); ?>" data-lng="<?php echo htmlspecialchars($loc['longitude']); ?>"><?php echo htmlspecialchars($loc['name']); ?></option><?php endforeach; ?>
<option value="Main Gate">Main Gate</option><option value="Courier Guy Offices">Courier Guy Offices</option><option value="Post Office">Post Office</option><option value="__other__">📍 Other (use map)</option>
</select>
<input type="hidden" id="pickup_location" name="pickup_location" required>
<input type="hidden" id="pickup_lat" name="pickup_lat"><input type="hidden" id="pickup_lng" name="pickup_lng">
</div>
<div id="pickupMapBlock" style="display:none"><label>Click on the map to set pickup</label><div id="pickupMap" class="mini-map"></div></div>
</div>
<div class="parcel-card">
<h2 class="parcel-section-title">📦 Parcel Details</h2>
<div class="form-group"><label for="parcel_description">Parcel Description *</label><textarea id="parcel_description" name="parcel_description" rows="3" placeholder="e.g., Small box with books" required></textarea></div>
<div class="form-row"><div class="form-group"><label for="parcel_size">Parcel Size *</label><select id="parcel_size" name="parcel_size" required><option value="">-- Select Size --</option><option>Small</option><option>Medium</option><option>Large</option><option>Extra Large</option></select></div><div class="form-group"><label for="recipient_contact">Recipient Cell *</label><input type="tel" id="recipient_contact" name="recipient_contact" placeholder="0712345678" maxlength="10" required></div></div>
<div class="form-group"><label for="recipient_name">Recipient Name *</label><input type="text" id="recipient_name" name="recipient_name" placeholder="Who receives the parcel?" required></div>
</div>
<div class="parcel-card">
<h2 class="parcel-section-title">🎯 Destination</h2>
<div class="toggle-row"><button type="button" class="toggle-btn active" id="btnOnCampus" onclick="setDestination('oncampus')">🏠 On Campus</button><button type="button" class="toggle-btn" id="btnOffCampus" onclick="setDestination('offcampus')">🗺️ Off Campus</button></div>
<div id="onCampusBlock"><div class="form-group"><label for="campus_destination">Campus residences / saved campus locations *</label><select id="campus_destination"><option value="">-- Select Campus Location --</option><?php foreach($locations as $loc): ?><option value="<?php echo htmlspecialchars($loc['name']); ?>" data-lat="<?php echo htmlspecialchars($loc['latitude']); ?>" data-lng="<?php echo htmlspecialchars($loc['longitude']); ?>"><?php echo htmlspecialchars($loc['name']); ?></option><?php endforeach; ?></select></div></div>
<div id="offCampusBlock" style="display:none"><div class="form-group"><label for="offCampusSearch">Search for a destination</label><input type="text" id="offCampusSearch" placeholder="Search an address, place or landmark in Alice..." autocomplete="off"><div id="destinationResults" class="location-results"></div><small>Search for a destination or click the map to drop a pin.</small></div><div id="map" class="mini-map"></div><input type="hidden" id="off_lat" name="off_lat"><input type="hidden" id="off_lng" name="off_lng"><input type="hidden" id="off_campus_text" name="off_campus_text"><input type="hidden" id="delivery_method" name="delivery_method" value="On-Campus"></div>
</div>
<div class="driver-card"><h2 class="parcel-section-title">🚗 Online Drivers</h2><p style="color:#6b7280;font-size:13.5px;margin-top:-10px;margin-bottom:15px">Available drivers are shown live on the map.</p><div id="driversMap" class="drivers-map"></div><div id="parcelDriverList" style="display:grid;gap:10px;margin-top:15px"></div></div>
<button type="submit" class="btn-submit">✅ Submit Parcel Service</button>
</form></div>
<script>
const ALICE_VIEWBOX='26.75,-32.70,26.95,-32.88';
let pickupMap=null,destMap=null,driverMap=null,pickupMarker=null,destMarker=null;
function esc(v){return String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function setPickup(name,lat='',lng=''){document.getElementById('pickup_location').value=name||'';document.getElementById('pickupSearch').value=name||'';document.getElementById('pickup_lat').value=lat;document.getElementById('pickup_lng').value=lng;document.getElementById('pickupCampus').value='';document.getElementById('pickupResults').style.display='none';}
function setupSearch(inputId,resultsId,type){const input=document.getElementById(inputId),results=document.getElementById(resultsId);let timer=null;input.addEventListener('input',()=>{clearTimeout(timer);const q=input.value.trim();if(type==='pickup'){document.getElementById('pickup_location').value='';document.getElementById('pickupCampus').value='';}else{document.getElementById('off_campus_text').value='';}if(q.length<3){results.innerHTML='';results.style.display='none';return;}timer=setTimeout(async()=>{try{const p=new URLSearchParams({format:'json',q:q+', Alice, Eastern Cape, South Africa',countrycodes:'za',bounded:'1',viewbox:ALICE_VIEWBOX,limit:'5',addressdetails:'1'});const r=await fetch('https://nominatim.openstreetmap.org/search?'+p.toString(),{headers:{Accept:'application/json','Accept-Language':'en'}});if(!r.ok)throw Error();const data=await r.json();results.innerHTML='';if(!data.length){results.innerHTML='<div class="location-result">No locations found. Try a different search.</div>';results.style.display='block';return;}data.forEach(place=>{const el=document.createElement('div');el.className='location-result';el.innerHTML='<strong>'+esc(place.display_name.split(',').slice(0,2).join(', '))+'</strong><small>'+esc(place.display_name)+'</small>';el.onclick=()=>{if(type==='pickup'){setPickup(place.display_name,place.lat,place.lon);}else{document.getElementById('off_campus_text').value=place.display_name;document.getElementById('off_lat').value=place.lat;document.getElementById('off_lng').value=place.lon;input.value=place.display_name;results.style.display='none';if(destMarker){destMap.removeLayer(destMarker)}destMarker=L.marker([place.lat,place.lon]).addTo(destMap);destMap.setView([place.lat,place.lon],15);}};results.appendChild(el);});results.style.display='block';}catch(e){results.innerHTML='<div class="location-result">Location search is temporarily unavailable.</div>';results.style.display='block';}},400);document.addEventListener('click',e=>{if(e.target!==input&&!results.contains(e.target))results.style.display='none';});}
function initPickupMap(){if(pickupMap)return;pickupMap=L.map('pickupMap').setView([-32.7833,26.8448],14);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(pickupMap);pickupMap.on('click',e=>{if(pickupMarker)pickupMap.removeLayer(pickupMarker);pickupMarker=L.marker(e.latlng).addTo(pickupMap);setPickup('Map location ('+e.latlng.lat.toFixed(6)+', '+e.latlng.lng.toFixed(6)+')',e.latlng.lat,e.latlng.lng);});}
function initDestMap(){if(destMap)return;destMap=L.map('map').setView([-32.7833,26.8448],14);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(destMap);destMap.on('click',e=>{if(destMarker)destMap.removeLayer(destMarker);destMarker=L.marker(e.latlng).addTo(destMap);document.getElementById('off_lat').value=e.latlng.lat;document.getElementById('off_lng').value=e.latlng.lng;document.getElementById('off_campus_text').value='Map location ('+e.latlng.lat.toFixed(6)+', '+e.latlng.lng.toFixed(6)+')';document.getElementById('offCampusSearch').value=document.getElementById('off_campus_text').value;});}
function setDestination(type){const on=type==='oncampus';document.getElementById('btnOnCampus').classList.toggle('active',on);document.getElementById('btnOffCampus').classList.toggle('active',!on);document.getElementById('onCampusBlock').style.display=on?'block':'none';document.getElementById('offCampusBlock').style.display=on?'none':'block';document.getElementById('delivery_method').value=on?'On-Campus':'Off-Campus';if(!on){setTimeout(()=>{initDestMap();destMap.invalidateSize();},150);}}
document.getElementById('pickupCampus').addEventListener('change',function(){const o=this.options[this.selectedIndex];if(this.value==='__other__'){document.getElementById('pickup_location').value='';document.getElementById('pickupSearch').value='';document.getElementById('pickupMapBlock').style.display='block';setTimeout(()=>{initPickupMap();pickupMap.invalidateSize();},150);}else if(this.value){setPickup(o.textContent.trim(),o.dataset.lat||'',o.dataset.lng||'');document.getElementById('pickupMapBlock').style.display='none';}});
document.getElementById('campus_destination').addEventListener('change',function(){if(this.value){document.getElementById('off_campus_text').value=this.value;document.getElementById('off_lat').value=this.options[this.selectedIndex].dataset.lat||'';document.getElementById('off_lng').value=this.options[this.selectedIndex].dataset.lng||'';}});
function initDriversMap(){
    const el=document.getElementById('driversMap');
    if(!el) return;
    if(typeof L === 'undefined'){
        const list=document.getElementById('parcelDriverList');
        if(list) list.innerHTML='<div style="padding:18px;text-align:center;color:#b42318;border:1px solid #f0c7c7;border-radius:10px;background:#fff">Map library could not be loaded.</div>';
        return;
    }

    // Use the same Leaflet setup as the working ride-request page.
    if(driverMap){
        driverMap.invalidateSize(true);
        return;
    }

    driverMap=L.map('driversMap').setView([-32.7833,26.8448],13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
        maxZoom:19,
        attribution:'&copy; OpenStreetMap contributors'
    }).addTo(driverMap);

    const carIcon=L.divIcon({
        html:'<div style="background:#0c2d4d;color:#fff;border-radius:50%;width:38px;height:38px;display:flex;align-items:center;justify-content:center;font-size:21px;border:3px solid #fff;box-shadow:0 2px 9px rgba(0,0,0,.35);">🚗</div>',
        className:'',iconSize:[38,38],iconAnchor:[19,19]
    });
    const driverMarkers=new Map();
    const listEl=document.getElementById('parcelDriverList');

    function refreshLiveDrivers(){
        fetch('get_online_drivers.php',{credentials:'same-origin',cache:'no-store'})
            .then(r=>{
                if(!r.ok) throw new Error('HTTP '+r.status);
                return r.json();
            })
            .then(data=>{
                if(!data || !data.success) throw new Error('Invalid driver response');
                const seen=new Set();
                if(listEl) listEl.innerHTML='';

                const drivers=Array.isArray(data.drivers)?data.drivers:[];
                drivers.forEach(d=>{
                    const id=String(d.DriverID);
                    const lat=Number(d.latitude),lng=Number(d.longitude);
                    seen.add(id);
                    const name=((d.DriverFname||'')+' '+(d.DriverLname||'')).trim() || 'Driver';
                    const vehicle=[d.vehicle_make||'',d.vehicle_model||''].filter(Boolean).join(' ') || 'Vehicle details unavailable';

                    if(listEl){
                        const item=document.createElement('div');
                        item.className='driver-item';
                        item.style.cursor='pointer';
                        item.innerHTML='<div class="driver-avatar">🚗</div><div class="driver-info"><h4>'+esc(name)+'</h4><p>'+esc(vehicle)+' &nbsp; <span style="color:#0f6e56;font-weight:700">● Online</span></p></div>';
                        item.addEventListener('click',()=>{
                            if(Number.isFinite(lat)&&Number.isFinite(lng)){
                                driverMap.setView([lat,lng],16);
                                const marker=driverMarkers.get(id);
                                if(marker) marker.openPopup();
                            }
                        });
                        listEl.appendChild(item);
                    }

                    // Keep drivers without coordinates in the visible list, but only put
                    // drivers with real coordinates on the map.
                    if(!Number.isFinite(lat)||!Number.isFinite(lng)) return;

                    let marker=driverMarkers.get(id);
                    if(!marker){
                        marker=L.marker([lat,lng],{icon:carIcon}).addTo(driverMap);
                        driverMarkers.set(id,marker);
                    }else{
                        marker.setLatLng([lat,lng]);
                    }
                    marker.bindPopup('<strong>🚗 '+esc(name)+'</strong><br>'+esc(vehicle)+'<br><span style="color:#0f6e56">● Online</span>');
                });

                driverMarkers.forEach((marker,id)=>{
                    if(!seen.has(id)){
                        driverMap.removeLayer(marker);
                        driverMarkers.delete(id);
                    }
                });

                if(listEl && drivers.length===0){
                    listEl.innerHTML='<div style="padding:18px;text-align:center;color:#6b7280;border:1px solid #e2e2dc;border-radius:10px;background:#fff">No online drivers available right now.</div>';
                }
            })
            .catch(error=>{
                console.error('Online drivers error:',error);
                if(listEl && !listEl.children.length){
                    listEl.innerHTML='<div style="padding:18px;text-align:center;color:#b42318;border:1px solid #f0c7c7;border-radius:10px;background:#fff">Unable to load online drivers. Please try again.</div>';
                }
            });
    }

    refreshLiveDrivers();
    setInterval(refreshLiveDrivers,5000);

    // Important when Leaflet is initialized inside a page whose layout/header has just rendered.
    setTimeout(()=>driverMap.invalidateSize(true),0);
    setTimeout(()=>driverMap.invalidateSize(true),100);
    setTimeout(()=>driverMap.invalidateSize(true),500);
    setTimeout(()=>driverMap.invalidateSize(true),1000);
}

setupSearch('pickupSearch','pickupResults','pickup');setupSearch('offCampusSearch','destinationResults','destination');document.addEventListener('DOMContentLoaded',initDriversMap);setTimeout(initDriversMap,100);
document.getElementById('parcelForm').addEventListener('submit',e=>{if(!document.getElementById('pickup_location').value){e.preventDefault();alert('Please select or search for a pickup location.');return;}if(document.getElementById('delivery_method').value==='On-Campus'&&!document.getElementById('campus_destination').value){e.preventDefault();alert('Please select a campus residence.');return;}if(document.getElementById('delivery_method').value==='Off-Campus'&&!document.getElementById('off_campus_text').value){e.preventDefault();alert('Please search for a destination or drop a pin on the map.');return;}});
</script>
<?php include 'footer.php'; ?>
