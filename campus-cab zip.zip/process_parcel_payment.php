<?php
session_start();
require_once __DIR__ . '/db_connect.php';

$isStudent = isset($_SESSION['student_id']);
$isStaff   = isset($_SESSION['staff_id']);

if (!$isStudent && !$isStaff) {
    header('Location: login.php');
    exit;
}

$userID     = $isStudent ? (int)$_SESSION['student_id'] : (int)$_SESSION['staff_id'];
$userColumn = $isStudent ? 'studentID' : 'staff_id';
$dashboard  = $isStudent ? 'student_dashboard.php' : 'staff_dashboard.php';
$parcelID   = (int)($_GET['parcel_id'] ?? $_POST['parcel_id'] ?? 0);

if ($parcelID <= 0) {
    header('Location: ' . $dashboard);
    exit;
}

// The requester is verified from the actual parcel table. Only delivered parcels
// are presented for payment in the current CampusCab flow.
$sql = "
    SELECT parcel, estimated_price, parcel_status, pickup_location, destination
    FROM parcel
    WHERE parcel = ?
      AND $userColumn = ?
      AND parcel_status = 'Delivered'
    LIMIT 1
";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    http_response_code(500);
    exit('Unable to prepare parcel lookup.');
}
$stmt->bind_param('ii', $parcelID, $userID);
$stmt->execute();
$parcel = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$parcel) {
    header('Location: my_Parcels.php');
    exit;
}

// Use the server-side parcel price; do not trust an amount submitted by the browser.
$amount      = (float)$parcel['estimated_price'];
$deliveryFee = 0.00;
$totalAmount = $amount + $deliveryFee;

$stmt = $conn->prepare("
    SELECT payment_id, payment_status, payment_method, total_amount, paid_at
    FROM parcel_payment
    WHERE parcel = ?
    LIMIT 1
");
if (!$stmt) {
    http_response_code(500);
    exit('Unable to prepare payment lookup.');
}
$stmt->bind_param('i', $parcelID);
$stmt->execute();
$existing = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $method = (string)($_POST['payment_method'] ?? 'Cash');
    if (!in_array($method, ['Cash', 'Card'], true)) {
        $method = 'Cash';
    }

    if ($method === 'Card') {
        header('Location: card_payment.php?type=parcel&id=' . $parcelID);
        exit;
    }

    if ($existing) {
        $paymentID = (int)$existing['payment_id'];
        $stmt = $conn->prepare("UPDATE parcel_payment SET payment_method='Cash', payment_status='Paid', paid_at=NOW(), item_cost=?, delivery_fee=?, total_amount=? WHERE payment_id=? AND parcel=?");
        if (!$stmt) {
            http_response_code(500);
            exit('Unable to prepare payment update.');
        }
        $stmt->bind_param('dddii', $amount, $deliveryFee, $totalAmount, $paymentID, $parcelID);
        $stmt->execute();
        $stmt->close();
    } else {
        $stmt = $conn->prepare("INSERT INTO parcel_payment (parcel, item_cost, delivery_fee, total_amount, payment_method, payment_status, paid_at) VALUES (?, ?, ?, ?, 'Cash', 'Paid', NOW())");
        if (!$stmt) {
            http_response_code(500);
            exit('Unable to prepare payment insert.');
        }
        $stmt->bind_param('iddd', $parcelID, $amount, $deliveryFee, $totalAmount);
        $stmt->execute();
        $stmt->close();
    }

    header('Location: my_payments.php?parcel_id=' . $parcelID);
    exit;
}

if ($existing && strcasecmp((string)$existing['payment_status'], 'Paid') === 0) {
    header('Location: my_payments.php?parcel_id=' . $parcelID);
    exit;
}

$pageTitle = 'Parcel Payment';
include 'header.php';
?>

<div style="max-width:650px;margin:40px auto;padding:25px;background:#fff;border-radius:14px;box-shadow:0 5px 20px rgba(0,0,0,.08)">
    <h1>💳 Parcel Payment</h1>
    <p>Parcel #<?php echo (int)$parcelID; ?></p>
    <p><?php echo htmlspecialchars($parcel['pickup_location']); ?> → <?php echo htmlspecialchars($parcel['destination']); ?></p>
    <p><strong>Amount: R<?php echo number_format($totalAmount, 2); ?></strong></p>

    <form method="post">
        <input type="hidden" name="parcel_id" value="<?php echo (int)$parcelID; ?>">

        <label for="payment_method">Payment method</label>
        <select id="payment_method" name="payment_method" required style="display:block;width:100%;padding:12px;margin:8px 0 18px;box-sizing:border-box">
            <option value="Cash">Cash</option>
            <option value="Card">Card</option>
        </select>

        <button type="submit" style="padding:12px 20px;border:0;border-radius:8px;background:#0f6e56;color:#fff;font-weight:700">
            Continue
        </button>
    </form>
</div>

<?php include 'footer.php'; ?>
