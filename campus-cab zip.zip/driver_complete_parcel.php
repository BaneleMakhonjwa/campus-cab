<?php
session_start(); require_once __DIR__.'/db_connect.php';
$driverID=(int)($_SESSION['driver_id']??0);$parcelID=(int)($_POST['parcelID']??$_GET['parcelID']??0);if($driverID<=0||$parcelID<=0){header('Location: driver_parcel_requests.php');exit;}
$stmt=$conn->prepare("UPDATE parcel SET parcel_status='Delivered', completed_at=NOW() WHERE parcel=? AND DriverID=? AND parcel_status='In Progress'");$stmt->bind_param('ii',$parcelID,$driverID);$stmt->execute();$completed=$stmt->affected_rows===1;$stmt->close();
$free=$conn->prepare("UPDATE driver SET availability_status='Available' WHERE DriverID=?");$free->bind_param('i',$driverID);$free->execute();$free->close();
header('Location: driver_parcel_requests.php?completed='.$parcelID);exit;
?>