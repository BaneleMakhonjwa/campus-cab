<?php
session_start();
require_once __DIR__ . '/db_connect.php';

header('Content-Type: application/json; charset=utf-8');

function response_json(array $data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}

$driverID = (int)($_SESSION['driver_id'] ?? 0);
if ($driverID <= 0) {
    response_json(['success' => false, 'code' => 'NOT_LOGGED_IN', 'message' => 'Driver session is not active. Please log in again.'], 401);
}

$input = $_POST;
if (!$input && stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false) {
    $decoded = json_decode(file_get_contents('php://input'), true);
    if (is_array($decoded)) $input = $decoded;
}

$rideID = (int)($input['ride_id'] ?? $input['rideID'] ?? 0);
$latRaw = $input['lat'] ?? $input['latitude'] ?? null;
$lngRaw = $input['lng'] ?? $input['longitude'] ?? null;
$accuracyRaw = $input['accuracy'] ?? null;

if ($rideID <= 0 || !is_numeric($latRaw) || !is_numeric($lngRaw)) {
    response_json(['success' => false, 'code' => 'INVALID_LOCATION', 'message' => 'Valid ride and GPS coordinates are required.'], 400);
}

$lat = (float)$latRaw;
$lng = (float)$lngRaw;
$accuracy = is_numeric($accuracyRaw) ? (float)$accuracyRaw : null;

if ($lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
    response_json(['success' => false, 'code' => 'OUT_OF_RANGE', 'message' => 'Invalid GPS coordinates.'], 400);
}

$stmt = $conn->prepare("SELECT rideID, pickup_latitude, pickup_longitude, ride_status FROM ride WHERE rideID = ? AND DriverID = ? LIMIT 1");
$stmt->bind_param('ii', $rideID, $driverID);
$stmt->execute();
$ride = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$ride) {
    response_json(['success' => false, 'code' => 'RIDE_NOT_FOUND', 'message' => 'Ride not found or it is not assigned to this driver.'], 404);
}

if (!in_array($ride['ride_status'], ['Accepted', 'Driver Arriving'], true)) {
    response_json(['success' => false, 'code' => 'INVALID_STATUS', 'message' => 'Arrival can only be checked while the ride is waiting for pickup.'], 409);
}

if ($ride['pickup_latitude'] === null || $ride['pickup_longitude'] === null) {
    response_json(['success' => false, 'code' => 'NO_PICKUP_COORDINATES', 'message' => 'This ride does not have pickup GPS coordinates, so arrival cannot be verified.'], 422);
}

// Haversine distance in metres.
$earthRadius = 6371000.0;
$lat1 = deg2rad((float)$ride['pickup_latitude']);
$lat2 = deg2rad($lat);
$dLat = deg2rad($lat - (float)$ride['pickup_latitude']);
$dLng = deg2rad($lng - (float)$ride['pickup_longitude']);
$a = sin($dLat / 2) ** 2 + cos($lat1) * cos($lat2) * sin($dLng / 2) ** 2;
$distance = 2 * $earthRadius * asin(min(1, sqrt($a)));

// Allow a small amount of GPS uncertainty. Cap the threshold so it cannot become unreasonable.
$accuracyAllowance = $accuracy !== null && $accuracy > 0 ? min($accuracy, 75.0) : 0.0;
$allowedDistance = min(200.0, max(100.0, 100.0 + $accuracyAllowance));

// Store the same location used for the arrival check.
$loc = $conn->prepare("INSERT INTO location (ride_id, driver_id, latitude, longitude, recorded_at) VALUES (?, ?, ?, ?, NOW())");
$loc->bind_param('iidd', $rideID, $driverID, $lat, $lng);
$loc->execute();
$loc->close();
$heartbeat = $conn->prepare("UPDATE driver SET availability_status='Available' WHERE DriverID=? AND driverAccount_Status='Active'");
$heartbeat->bind_param('i', $driverID);
$heartbeat->execute();
$heartbeat->close();

if ($distance > $allowedDistance) {
    response_json([
        'success' => false,
        'code' => 'TOO_FAR_FROM_PICKUP',
        'message' => 'You are not close enough to the pickup point yet.',
        'distance_m' => round($distance, 1),
        'allowed_m' => round($allowedDistance, 1),
        'accuracy_m' => $accuracy !== null ? round($accuracy, 1) : null
    ], 422);
}

response_json([
    'success' => true,
    'arrived' => true,
    'message' => 'Arrival confirmed. You are at the pickup point.',
    'distance_m' => round($distance, 1),
    'accuracy_m' => $accuracy !== null ? round($accuracy, 1) : null
]);
