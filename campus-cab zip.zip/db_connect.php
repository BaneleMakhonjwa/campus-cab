<?php
/**
 * Central database connection for CampusCab.
 * Environment variables override the local development defaults.
 */
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$servername = getenv('CAMPUS_CAB_DB_HOST') ?: '127.0.0.1';
$username   = getenv('CAMPUS_CAB_DB_USER') ?: 'root';
$password   = getenv('CAMPUS_CAB_DB_PASS') ?: '';
$dbname     = getenv('CAMPUS_CAB_DB_NAME') ?: 'campus_cab_db';
$port       = (int)(getenv('CAMPUS_CAB_DB_PORT') ?: 3306);

try {
    $conn = new mysqli($servername, $username, $password, $dbname, $port);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    http_response_code(500);
    error_log('CampusCab DB connection failed: ' . $e->getMessage());
    die('Database connection failed. Check the CampusCab database configuration.');
}
?>
