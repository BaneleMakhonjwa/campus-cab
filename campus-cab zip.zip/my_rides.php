<?php
session_start();
include_once __DIR__ . '/db_connect.php';

// This page supports multiple identities in one PHP session. Use the explicit
// requester context from the link, falling back to the current login role.
$requestedAs = strtolower(trim((string)($_GET['as'] ?? '')));
$hasStudent = isset($_SESSION['student_id']) && (int)$_SESSION['student_id'] > 0;
$hasStaff = isset($_SESSION['staff_id']) && (int)$_SESSION['staff_id'] > 0;
$activeRole = strtolower(trim((string)($_SESSION['role'] ?? '')));

if ($requestedAs === 'staff' && $hasStaff) {
    $isStudent = false; $isStaff = true;
} elseif ($requestedAs === 'student' && $hasStudent) {
    $isStudent = true; $isStaff = false;
} elseif ($activeRole === 'staff' && $hasStaff) {
    $isStudent = false; $isStaff = true;
} elseif ($activeRole === 'student' && $hasStudent) {
    $isStudent = true; $isStaff = false;
} elseif ($hasStudent) {
    $isStudent = true; $isStaff = false;
} elseif ($hasStaff) {
    $isStudent = false; $isStaff = true;
} else {
    header('Location: login.php'); exit;
}

$pageTitle = 'My Rides';
if ($isStudent) {
    $userID = (int)$_SESSION['student_id']; $userColumn = 'studentID'; $dashboardLink = 'student_dashboard.php'; $context='student';
} else {
    $userID = (int)$_SESSION['staff_id']; $userColumn = 'staff_id'; $dashboardLink = 'staff_dashboard.php'; $context='staff';
}

// Fetch all rides for this user
$stmt = $conn->prepare("
    SELECT 
        r.rideID,
        r.request_type,
        r.pickup_address,
        r.destination_address,
        r.ride_status,
        r.estimated_price,
        r.estimated_distance_km,
        r.estimated_duration_min,
        r.requested_at,
        r.Completed_at,
        r.cancellation_reason,
        r.DriverID,
        d.DriverFname,
        d.DriverLname,
        d.vehicle_registration,
        d.vehicle_make,
        d.vehicle_model
    FROM ride r
    LEFT JOIN driver d ON r.DriverID = d.DriverID
    WHERE r.$userColumn = ?
    ORDER BY r.requested_at DESC
    LIMIT 50
");
$stmt->bind_param("i", $userID);
$stmt->execute();
$rides = $stmt->get_result();
$stmt->close();

include 'header.php';
$newSafetyPin = $_SESSION['new_safety_pin'] ?? '';
$newSafetyPinType = $_SESSION['new_safety_pin_type'] ?? '';
unset($_SESSION['new_safety_pin'], $_SESSION['new_safety_pin_type']);
?>

<style>
.pin-notice{max-width:1100px;margin:18px auto 0;padding:14px 20px;background:#fff8df;border:1px solid #e0a526;border-radius:10px;color:#0c2d4d;font-weight:600}.pin-notice strong{font-size:22px;letter-spacing:3px;margin-left:8px}
</style>
<style>
.rides-page { max-width: 1100px; margin: 0 auto; padding: 35px 25px 60px; }

.rides-head {
    display: flex; justify-content: space-between; align-items: flex-start;
    gap: 20px; flex-wrap: wrap; margin-bottom: 30px;
}
.rides-head h1 { color: #0c2d4d; font-size: 30px; font-weight: 800; margin: 0 0 6px; }
.rides-head p { color: #6b7280; font-size: 15px; margin: 0; }

.btn-back {
    display: inline-flex; align-items: center; gap: 8px;
    background: #0c2d4d; color: #fff; text-decoration: none;
    padding: 11px 18px; border-radius: 8px; font-size: 14px;
    font-weight: 600; transition: background 0.25s ease;
}
.btn-back:hover { background: #185fa5; }

.rides-empty {
    background: #fff; border: 1px solid #e2e2dc;
    border-radius: 14px; padding: 60px 30px;
    text-align: center; color: #6b7280;
}
.rides-empty h3 { color: #0c2d4d; margin: 0 0 8px; font-size: 20px; }
.rides-empty a {
    color: #185fa5; font-weight: 700; text-decoration: none;
}
.rides-empty a:hover { text-decoration: underline; }

.ride-card {
    background: #fff; border: 1px solid #e2e2dc;
    border-radius: 14px; padding: 22px; margin-bottom: 16px;
    box-shadow: 0 4px 14px rgba(11,31,58,0.05);
    transition: transform 0.25s ease, box-shadow 0.25s ease;
}
.ride-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 22px rgba(11,31,58,0.1);
}

.ride-head {
    display: flex; justify-content: space-between; align-items: flex-start;
    gap: 15px; padding-bottom: 14px;
    border-bottom: 1px solid #f0f1f3; margin-bottom: 14px;
}
.ride-id { color: #6b7280; font-size: 12.5px; font-weight: 700; margin-bottom: 4px; }
.ride-id strong { color: #0c2d4d; font-size: 16px; }
.ride-type {
    display: inline-block; padding: 3px 10px; border-radius: 12px;
    font-size: 11px; font-weight: 700; margin-left: 8px;
    text-transform: uppercase; letter-spacing: 0.4px;
}
.ride-type.ride   { background: #e0e7ef; color: #0c2d4d; }
.ride-type.parcel { background: #ede9fe; color: #6d28d9; }

.status-pill {
    padding: 6px 14px; border-radius: 20px;
    font-size: 11.5px; font-weight: 700;
    text-transform: uppercase; letter-spacing: 0.4px;
    white-space: nowrap;
}
.status-requested       { background: #fbecc9; color: #8a6d00; }
.status-accepted        { background: #dbe8fb; color: #185fa5; }
.status-driver-arriving { background: #dbe8fb; color: #185fa5; }
.status-in-progress     { background: #fef3c7; color: #b8860b; }
.status-completed       { background: #dcf1e9; color: #0f6e56; }
.status-cancelled       { background: #fbe2df; color: #b03a2e; }

.ride-body {
    display: grid;
    grid-template-columns: 1.5fr 1fr;
    gap: 20px;
    align-items: start;
}

.route-info { display: flex; flex-direction: column; gap: 10px; }
.route-row { display: flex; gap: 10px; align-items: flex-start; }
.route-icon { font-size: 16px; flex-shrink: 0; margin-top: 2px; }
.route-text { flex: 1; }
.route-label {
    color: #6b7280; font-size: 11px; font-weight: 700;
    text-transform: uppercase; letter-spacing: 0.4px; margin-bottom: 2px;
}
.route-value { color: #172033; font-size: 14px; line-height: 1.4; }

.ride-meta {
    background: #f8f9fa; border-radius: 10px;
    padding: 14px; display: grid; gap: 8px;
}
.meta-row {
    display: flex; justify-content: space-between;
    font-size: 13px;
}
.meta-row .label { color: #6b7280; font-weight: 600; }
.meta-row .value { color: #172033; font-weight: 700; }
.meta-row.price .value { color: #0f6e56; font-size: 16px; }

.ride-footer {
    display: flex; justify-content: space-between; align-items: center;
    gap: 15px; padding-top: 14px; margin-top: 14px;
    border-top: 1px solid #f0f1f3; flex-wrap: wrap;
}
.ride-footer .date { color: #6b7280; font-size: 12.5px; }
.ride-actions { display: flex; gap: 8px; flex-wrap: wrap; }

.btn-view {
    padding: 9px 16px; background: #0c2d4d; color: #fff;
    border-radius: 7px; text-decoration: none;
    font-size: 12.5px; font-weight: 700;
}
.btn-view:hover { background: #185fa5; }

.btn-rate {
    padding: 9px 16px; background: #e0a526; color: #0c2d4d;
    border-radius: 7px; text-decoration: none;
    font-size: 12.5px; font-weight: 700;
}
.btn-rate:hover { background: #b8860b; }

.no-driver { color: #6b7280; font-size: 12.5px; font-style: italic; }

@media (max-width: 700px) {
    .rides-page { padding: 25px 15px 45px; }
    .rides-head h1 { font-size: 24px; }
    .ride-body { grid-template-columns: 1fr; }
    .ride-head { flex-direction: column; }
}
</style>

<?php if ($newSafetyPin !== ""): ?><div class="pin-notice">Your <?php echo htmlspecialchars($newSafetyPinType); ?> passenger Safety PIN is <strong><?php echo htmlspecialchars($newSafetyPin); ?></strong>. Keep it private and give it to your driver when asked.</div><?php endif; ?>
<div class="rides-page">

    <div class="rides-head">
        <div>
            <h1>📊 My Rides</h1>
            <p>View your ride and parcel services history.</p>
        </div>
        <a href="<?php echo $dashboardLink; ?>" class="btn-back">← Back to Dashboard</a>
    </div>

    <?php if ($rides->num_rows === 0): ?>

        <div class="rides-empty">
            <h3>No rides yet</h3>
            <p>You haven't requested any rides or parcels.</p>
            <br>
            <a href="request.php">Request your first ride →</a>
        </div>

    <?php else: ?>

        <?php while ($ride = $rides->fetch_assoc()): ?>

            <?php
            $statusClass = strtolower(str_replace(' ', '-', $ride['ride_status']));
            $typeClass = strtolower($ride['request_type']);
            $driverName = trim(($ride['DriverFname'] ?? '') . ' ' . ($ride['DriverLname'] ?? ''));
            $driverVehicle = trim(($ride['vehicle_make'] ?? '') . ' ' . ($ride['vehicle_model'] ?? ''));
            ?>

            <div class="ride-card">

                <div class="ride-head">
                    <div>
                        <div class="ride-id">
                            Ride <strong>#<?php echo (int)$ride['rideID']; ?></strong>
                            <span class="ride-type <?php echo $typeClass; ?>">
                                <?php echo htmlspecialchars($ride['request_type']); ?>
                            </span>
                        </div>
                    </div>
                    <span class="status-pill status-<?php echo $statusClass; ?>">
                        <?php echo htmlspecialchars($ride['ride_status']); ?>
                    </span>
                </div>

                <div class="ride-body">

                    <div class="route-info">

                        <div class="route-row">
                            <div class="route-icon">📍</div>
                            <div class="route-text">
                                <div class="route-label">Pickup</div>
                                <div class="route-value">
                                    <?php echo htmlspecialchars($ride['pickup_address'] ?? '—'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="route-row">
                            <div class="route-icon">🎯</div>
                            <div class="route-text">
                                <div class="route-label">Destination</div>
                                <div class="route-value">
                                    <?php echo htmlspecialchars($ride['destination_address'] ?? '—'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="route-row">
                            <div class="route-icon">🚗</div>
                            <div class="route-text">
                                <div class="route-label">Driver</div>
                                <div class="route-value">
                                    <?php if ($driverName): ?>
                                        <?php echo htmlspecialchars($driverName); ?>
                                        <?php if ($driverVehicle): ?>
                                            <br><small style="color:#6b7280;">
                                                <?php echo htmlspecialchars($driverVehicle); ?>
                                                <?php if ($ride['vehicle_registration']): ?>
                                                    · <?php echo htmlspecialchars($ride['vehicle_registration']); ?>
                                                <?php endif; ?>
                                            </small>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="no-driver">No driver assigned</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="ride-meta">

                        <?php if ($ride['estimated_distance_km']): ?>
                            <div class="meta-row">
                                <span class="label">Distance</span>
                                <span class="value">
                                    <?php echo number_format((float)$ride['estimated_distance_km'], 2); ?> km
                                </span>
                            </div>
                        <?php endif; ?>

                        <?php if ($ride['estimated_duration_min']): ?>
                            <div class="meta-row">
                                <span class="label">Duration</span>
                                <span class="value">
                                    ~<?php echo (int)$ride['estimated_duration_min']; ?> min
                                </span>
                            </div>
                        <?php endif; ?>

                        <?php if ($ride['estimated_price']): ?>
                            <div class="meta-row price">
                                <span class="label">Fare</span>
                                <span class="value">
                                    R<?php echo number_format((float)$ride['estimated_price'], 2); ?>
                                </span>
                            </div>
                        <?php endif; ?>

                    </div>

                </div>

                <div class="ride-footer">

                    <div class="date">
                        <?php if ($ride['ride_status'] === 'Completed' && $ride['Completed_at']): ?>
                            Completed: <?php echo date('d M Y, H:i', strtotime($ride['Completed_at'])); ?>
                        <?php else: ?>
                            Requested: <?php echo date('d M Y, H:i', strtotime($ride['requested_at'])); ?>
                        <?php endif; ?>
                    </div>

                    <div class="ride-actions">

                        <?php if (in_array($ride['ride_status'], ['Requested', 'Accepted', 'Driver Arriving', 'In Progress'])): ?>
                            <a href="trip.php?id=<?php echo (int)$ride['rideID']; ?>&as=<?php echo urlencode($context); ?>" class="btn-view">
                                View Live
                            </a>
                        <?php endif; ?>

                        <?php if ($ride['ride_status'] === 'Completed'): ?>

                            <?php
                            // Check if already rated
                            $rateCheck = $conn->prepare("SELECT ratingID FROM driver_ratings WHERE rideID = ? LIMIT 1");
                            $rateCheck->bind_param("i", $ride['rideID']);
                            $rateCheck->execute();
                            $alreadyRated = $rateCheck->get_result()->num_rows > 0;
                            $rateCheck->close();
                            ?>

                            <?php if ($alreadyRated): ?>
                                <span style="color:#0f6e56;font-size:12.5px;font-weight:600;">
                                    ✅ Rated
                                </span>
                            <?php else: ?>
                                <a href="rate_driver.php?ride_id=<?php echo (int)$ride['rideID']; ?>&as=<?php echo urlencode($context); ?>" class="btn-rate">
                                    ⭐ Rate Driver
                                </a>
                            <?php endif; ?>

                        <?php endif; ?>

                    </div>

                </div>

            </div>

        <?php endwhile; ?>

    <?php endif; ?>

</div>

<?php include 'footer.php'; ?>