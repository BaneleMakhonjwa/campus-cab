<?php
session_start();
include_once __DIR__ . '/db_connect.php';

$error = '';
$success = 'Email verification is not enabled in the active Campus Cab database schema. No verification email is required.';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resend Verification | Campus Cab</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="container verify-container">
        <div class="verify-box">
            <h1>📧 Resend Verification Email</h1>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">❌ <?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    ✅ <?php echo htmlspecialchars($success); ?>
                    <br><br>
                    <a href="login_student.php" class="btn-primary">🔑 Go to Login</a>
                </div>
            <?php else: ?>

            <form method="POST">
                <div class="form-group">
                    <label for="email">Enter your email address</label>
                    <input type="email" id="email" name="email" placeholder="StudentNo@ufh.ac.za" required>
                </div>
                <button type="submit" class="btn-primary btn-block">📧 Resend Verification</button>
                <p class="login-link">
                    <a href="login_student.php">← Back to Login</a>
                </p>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>