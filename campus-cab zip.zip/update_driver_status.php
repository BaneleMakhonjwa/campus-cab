<?php
session_start(); require_once __DIR__.'/db_connect.php'; header('Content-Type: application/json; charset=utf-8');
function respond(array $d,int $s=200):void{http_response_code($s);echo json_encode($d,JSON_UNESCAPED_SLASHES);exit;}
$driverID=(int)($_SESSION['driver_id']??0); if($driverID<=0) respond(['success'=>false,'message'=>'Your driver session has expired.'],401);
$input=$_POST; if(!$input && stripos($_SERVER['CONTENT_TYPE']??'','application/json')!==false){$x=json_decode(file_get_contents('php://input'),true);if(is_array($x))$input=$x;}
$status=trim((string)($input['status']??'')); $lat=$input['lat']??null; $lng=$input['lng']??null;
if(!in_array($status,['Available','Unavailable'],true)) respond(['success'=>false,'message'=>'Invalid availability status.'],400);
$check=$conn->prepare("SELECT driverAccount_Status,availability_status FROM driver WHERE DriverID=? LIMIT 1");$check->bind_param('i',$driverID);$check->execute();$driver=$check->get_result()->fetch_assoc();$check->close();
if(!$driver) respond(['success'=>false,'message'=>'Driver account was not found.'],404);
if($driver['driverAccount_Status']!=='Active') respond(['success'=>false,'message'=>'Your driver account is inactive.'],403);
if($status==='Available'){
 if(!is_numeric($lat)||!is_numeric($lng)) respond(['success'=>false,'code'=>'GPS_REQUIRED','message'=>'Live GPS location is required before going online.'],400);
 $lat=(float)$lat;$lng=(float)$lng;if($lat<-90||$lat>90||$lng<-180||$lng>180)respond(['success'=>false,'message'=>'Invalid GPS coordinates.'],400);
 $stmt=$conn->prepare("UPDATE driver SET availability_status='Available' WHERE DriverID=?");$stmt->bind_param('i',$driverID);$stmt->execute();$stmt->close();
 $loc=$conn->prepare("INSERT INTO location (ride_id,driver_id,latitude,longitude,recorded_at,request_type) VALUES (NULL,?,?,?,NOW(),'availability')");$loc->bind_param('idd',$driverID,$lat,$lng);$loc->execute();$loc->close();
 respond(['success'=>true,'status'=>'Available','is_online'=>true,'lat'=>$lat,'lng'=>$lng]);
}
$stmt=$conn->prepare("UPDATE driver SET availability_status='Unavailable' WHERE DriverID=?");$stmt->bind_param('i',$driverID);$stmt->execute();$stmt->close();respond(['success'=>true,'status'=>'Unavailable','is_online'=>false]);
