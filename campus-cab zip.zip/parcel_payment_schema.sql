-- CampusCab parcel payment table.
-- This file mirrors the exact parcel_payment schema supplied for the actual database.

CREATE TABLE IF NOT EXISTS `parcel_payment` (
    `payment_id` INT AUTO_INCREMENT PRIMARY KEY,
    `parcel` INT NOT NULL,
    `item_cost` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `delivery_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `total_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `payment_method` VARCHAR(50) NOT NULL,
    `payment_status` VARCHAR(30) NOT NULL DEFAULT 'Pending',
    `paid_at` DATETIME NULL,

    CONSTRAINT `fk_parcel_payment_parcel`
        FOREIGN KEY (`parcel`)
        REFERENCES `parcel`(`parcel`)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    UNIQUE KEY `unique_parcel_payment` (`parcel`)
);
