# CampusCab schema audit

**Source of truth:** `actual_database_export.sql`, exported from the user's live `campus_cab_db` on 2026-10-03.

The project is no longer aligned to the supplied project `database.sql`. That file and the old live-tracking migration file were removed from this build so they cannot be accidentally imported.

## Actual schema facts used by the application

- `student` uses `password`; it has no `studentNumber` or `email_verified` column.
- `staff` uses `staff_id`, `staff_name`, `surname`, `staff_email`, `staff_phone`, `staffAccount_status`, `password`.
- `driver` uses `password`, `profile_picture`, `vehicle_registration`, `vehicle_make`, `vehicle_model`, `availability_status`; it has no approval/online/OTP columns.
- `ride` uses `staff_id`, `passenger_type`, `request_type`, and the existing arrival/cancellation fields. It has no `requester_type` column.
- `parcel` has a primary key named **`parcel`**, not `parcelID`; it contains `studentID` and `staff_id`, but `studentID` is NOT NULL.
- `location` has `ride_id`, `driver_id`, coordinates, `recorded_at`, and `request_type`; it has no `parcel_id`.
- `payment` links to **`ride_id` only** and has no parcel/requester columns.
- `payment_method` does contain `requester_type`/`requester_id` and is separate from `payment`.
- `safety_pin` stores `user_type`, `user_id`, and `pin_hash`; it does not have the `pin_verification` spelling used by older code.
- `user_activity_log` is the available audit-log table; there is no `audit_log` table.
- `vehicle` stores registration, make, model, colour and capacity separately from the `driver` table.

## Code changes

- Removed all `ride.requester_type` references.
- Reworked student/staff/driver/admin authentication to use the actual column names.
- Reworked staff and student registration so unsupported ID-number columns are not inserted.
- Reworked driver registration/profile handling around the actual `driver` and `vehicle` columns.
- Reworked driver online status to use the actual `availability_status` field; removed writes to nonexistent `is_online`, `last_seen`, and approval fields.
- Reworked live location writes to the actual `location` columns and `request_type`.
- Reworked parcel reads/writes around the actual primary key `parcel` and removed unsupported parcel columns such as `accepted_at`, `cancelled_at`, and `cancellation_reason`.
- Kept ride payments on the actual `payment.ride_id` relationship and added the separate `parcel_payment.parcel` relationship for parcel payments.
- Reworked admin user/driver/admin pages to the actual schema and removed unsupported approval/status/audit fields.
- Reworked admin audit logging to use `user_activity_log`.
- Disabled the old reset-token and OTP database flows because the actual database has no columns to store those values.

## Validation performed

- PHP syntax lint completed successfully for all application PHP files outside the bundled PHPMailer/Composer source tree.
- Explicit `table.column` references were checked against the actual table definitions and no remaining mismatches were found by the static audit.
- The application was **not** connected to the user's live XAMPP MariaDB from this environment, so browser/runtime behavior still needs to be smoke-tested in XAMPP.

## Important limitation from the actual schema

The actual `payment` table still supports rides only through `ride_id`. Parcel payments are intentionally stored in the separate `parcel_payment` table and are not added to `payment`.

Likewise, the current `location` table cannot associate a location row directly with a parcel. Parcel driver tracking uses the driver's latest `request_type='parcel'` location, which is compatible with the existing schema but cannot distinguish two simultaneous parcel assignments to the same driver.


## Parcel payment schema extension

The application is audited against the exact `parcel_payment` schema supplied by the user:

- `payment_id INT AUTO_INCREMENT PRIMARY KEY`
- `parcel INT NOT NULL` with foreign key to `parcel.parcel`
- `item_cost DECIMAL(10,2) NOT NULL DEFAULT 0.00`
- `delivery_fee DECIMAL(10,2) NOT NULL DEFAULT 0.00`
- `total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00`
- `payment_method VARCHAR(50) NOT NULL`
- `payment_status VARCHAR(30) NOT NULL DEFAULT 'Pending'`
- `paid_at DATETIME NULL`
- `UNIQUE KEY unique_parcel_payment (parcel)`
- foreign key uses `ON DELETE CASCADE` and `ON UPDATE CASCADE`

Parcel-payment code changes:

1. `process_parcel_payment.php` writes only the columns present in the exact table.
2. Payment ownership is checked against the actual `parcel.studentID` or `parcel.staff_id`.
3. Parcel payment amounts are derived from the server-side `parcel.estimated_price`; browser-submitted amounts are not trusted.
4. Existing payments are updated by `payment_id` and `parcel`; new payments use the unique `parcel` key.
5. `payment_method` is treated as `VARCHAR(50)`, not as an ENUM, so the PHP layer no longer incorrectly restricts stored methods to Cash/Card/EFT.
6. `payment_status` is treated as a string; the UI recognizes common statuses such as Paid/Pending/Failed but does not require an ENUM definition.
7. `my_Parcels.php` reads payment state through `LEFT JOIN parcel_payment pp ON pp.parcel = p.parcel`.
8. `my_payments.php` combines ride payments and parcel payments without inventing a `requester_type` or `parcel_id` column.
9. `payment_history.php` remains a compatibility redirect to `my_payments.php`.
10. `parcel_payment_schema.sql` now mirrors the exact schema supplied by the user rather than the earlier ENUM/DECIMAL(8,2) proposal.

## Map Driver Visibility Update

The live driver maps now use the following behavior:
- When the logged-in student/staff member has no ride in `In Progress`, the map shows all Active drivers whose `availability_status` is `Available` and have a recorded location.
- When that requester has a ride in `In Progress`, the map shows only the driver assigned to that ride (`ride.DriverID`).
- When the ride becomes `Completed` or `Cancelled`, the active-ride filter no longer applies and all available online drivers appear again.
- Driver markers use a car icon (`🚗`) rather than Leaflet's default pin on the requester-facing maps.
- The same visibility endpoint is used by the available-driver map, ride-request map, trip map, and parcel page's online-driver layer.
