<?php
session_start();
include_once __DIR__ . '/db_connect.php';
include 'admin_auth.php';

requireAdmin();

// Fetch stats
$stats = [];

// Total students
$r = $conn->query("SELECT COUNT(*) AS c FROM student");
$stats['students'] = $r->fetch_assoc()['c'];

// Total drivers
$r = $conn->query("SELECT COUNT(*) AS c FROM driver");
$stats['drivers'] = $r->fetch_assoc()['c'];

// Pending drivers
$r = $conn->query("SELECT COUNT(*) AS c FROM driver WHERE driverAccount_Status = 'Inactive'");
$stats['pending'] = $r->fetch_assoc()['c'];

// Total staff
$r = $conn->query("SELECT COUNT(*) AS c FROM staff");
$stats['staff'] = $r->fetch_assoc()['c'];

// Total rides
$r = $conn->query("SELECT COUNT(*) AS c FROM ride");
$stats['rides'] = $r->fetch_assoc()['c'];

// Total parcels
$r = $conn->query("SELECT COUNT(*) AS c FROM parcel");
$stats['parcels'] = $r->fetch_assoc()['c'];

// Total revenue
$r = $conn->query("SELECT COALESCE(SUM(estimated_price), 0) AS c FROM ride WHERE ride_status = 'Completed'");
$stats['revenue'] = $r->fetch_assoc()['c'];

// Total admins
$r = $conn->query("SELECT COUNT(*) AS c FROM admin");
$stats['admins'] = $r->fetch_assoc()['c'];

$pageTitle = "Admin Dashboard";
include 'header.php';
?>

<style>
.admin-page {
    max-width: 1200px;
    margin: 0 auto;
    padding: 35px 25px 60px;
}
.admin-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 30px;
}
.admin-header h1 {
    margin: 0 0 6px;
    color: #0c2d4d;
    font-size: 30px;
    font-weight: 800;
}
.admin-header p {
    margin: 0;
    color: #6b7280;
    font-size: 15px;
}
.admin-badge {
    display: inline-block;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.4px;
}
.badge-super {
    background: #fef3c7;
    color: #b8860b;
}
.badge-admin {
    background: #dbe8fb;
    color: #185fa5;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 18px;
    margin-bottom: 35px;
}
.stat-card {
    background: #ffffff;
    border: 1px solid #e2e2dc;
    border-radius: 14px;
    padding: 22px;
    box-shadow: 0 4px 14px rgba(11, 31, 58, 0.05);
    transition: transform 0.25s ease;
}
.stat-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 22px rgba(11, 31, 58, 0.1);
}
.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    margin-bottom: 14px;
}
.stat-icon.blue   { background: #dbe8fb; color: #185fa5; }
.stat-icon.green  { background: #dcf1e9; color: #0f6e56; }
.stat-icon.amber  { background: #fef3c7; color: #b8860b; }
.stat-icon.red    { background: #fbe2df; color: #b03a2e; }
.stat-icon.purple { background: #ede9fe; color: #6d28d9; }
.stat-icon.navy   { background: #e0e7ef; color: #0c2d4d; }

.stat-label {
    color: #6b7280;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    margin-bottom: 6px;
}
.stat-value {
    color: #0c2d4d;
    font-size: 28px;
    font-weight: 800;
    line-height: 1;
}

.actions-section h2 {
    color: #0c2d4d;
    font-size: 22px;
    margin-bottom: 20px;
}
.actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 18px;
}
.action-card {
    background: #ffffff;
    border: 1px solid #e2e2dc;
    border-radius: 14px;
    padding: 22px;
    text-decoration: none;
    color: inherit;
    box-shadow: 0 4px 14px rgba(11, 31, 58, 0.05);
    transition: all 0.25s ease;
    display: block;
    position: relative;
}
.action-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 22px rgba(11, 31, 58, 0.1);
    border-color: #e0a526;
}
.action-card h3 {
    margin: 0 0 6px;
    color: #0c2d4d;
    font-size: 17px;
    font-weight: 700;
}
.action-card p {
    margin: 0;
    color: #6b7280;
    font-size: 13px;
    line-height: 1.5;
}
.action-arrow {
    position: absolute;
    bottom: 20px;
    right: 20px;
    width: 34px;
    height: 34px;
    background: #e0a526;
    color: #0c2d4d;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
}
@media (max-width: 700px) {
    .admin-page { padding: 25px 15px; }
    .admin-header h1 { font-size: 24px; }
}
</style>

<div class="admin-page">

    <div class="admin-header">
        <div>
            <h1>🛡️ Admin Dashboard</h1>
            <p>Welcome back, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></p>
        </div>
        <span class="admin-badge <?php echo isSuperAdmin() ? 'badge-super' : 'badge-admin'; ?>">
            <?php echo isSuperAdmin() ? '👑 Super Admin' : 'Admin'; ?>
        </span>
    </div>

    <!-- STATS -->
    <div class="stats-grid">

        <div class="stat-card">
            <div class="stat-icon blue">🎓</div>
            <div class="stat-label">Total Students</div>
            <div class="stat-value"><?php echo $stats['students']; ?></div>
        </div>

        <div class="stat-card">
            <div class="stat-icon green">🚗</div>
            <div class="stat-label">Total Drivers</div>
            <div class="stat-value"><?php echo $stats['drivers']; ?></div>
        </div>

        <div class="stat-card">
            <div class="stat-icon amber">⏳</div>
            <div class="stat-label">Pending Drivers</div>
            <div class="stat-value"><?php echo $stats['pending']; ?></div>
        </div>

        <div class="stat-card">
            <div class="stat-icon purple">👔</div>
            <div class="stat-label">Total Staff</div>
            <div class="stat-value"><?php echo $stats['staff']; ?></div>
        </div>

        <div class="stat-card">
            <div class="stat-icon navy">🚕</div>
            <div class="stat-label">Total Rides</div>
            <div class="stat-value"><?php echo $stats['rides']; ?></div>
        </div>

        <div class="stat-card">
            <div class="stat-icon navy">📦</div>
            <div class="stat-label">Total Parcels</div>
            <div class="stat-value"><?php echo $stats['parcels']; ?></div>
        </div>

        <div class="stat-card">
            <div class="stat-icon green">💰</div>
            <div class="stat-label">Total Revenue</div>
            <div class="stat-value">R<?php echo number_format($stats['revenue'], 2); ?></div>
        </div>

        <div class="stat-card">
            <div class="stat-icon red">🛡️</div>
            <div class="stat-label">Total Admins</div>
            <div class="stat-value"><?php echo $stats['admins']; ?></div>
        </div>

    </div>

    <!-- ACTIONS -->
    <div class="actions-section">
        <h2>Quick Actions</h2>
        <div class="actions-grid">

            <a href="admin_drivers.php" class="action-card">
                <h3>🚗 Manage Drivers</h3>
                <p>Approve, reject or suspend driver applications.</p>
                <span class="action-arrow">→</span>
            </a>

            <?php if (isSuperAdmin()): ?>
            <a href="admin_admins.php" class="action-card">
                <h3>👑 Manage Admins</h3>
                <p>Register and manage admin accounts. Super Admin only.</p>
                <span class="action-arrow">→</span>
            </a>
            <?php endif; ?>

            <a href="admin_users.php" class="action-card">
                <h3>👥 View Users</h3>
                <p>View all students, drivers and staff members.</p>
                <span class="action-arrow">→</span>
            </a>

            <a href="admin_audit_log.php" class="action-card">
                <h3>📋 Audit Log</h3>
                <p>Track all administrative actions and accountability.</p>
                <span class="action-arrow">→</span>
            </a>

            <a href="admin_rides.php" class="action-card">
                <h3>🚕 View Rides</h3>
                <p>Monitor all ride requests and their statuses.</p>
                <span class="action-arrow">→</span>
            </a>

            <a href="admin_parcels.php" class="action-card">
                <h3>📦 View Parcels</h3>
                <p>Monitor all parcel deliveries and their statuses.</p>
                <span class="action-arrow">→</span>
            </a>
            <a href="admin_driver_payments.php" class="action-card">
            <h3>💰 Driver Payments</h3>
           <p>Pay drivers for weekly earnings. 80% driver / 20% campus split.</p>
           <span class="action-arrow">→</span>
           </a>

            <a href="logout.php" class="action-card" style="border-color: #fbe2df;">
                <h3 style="color: #b03a2e;">🚪 Sign Out</h3>
                <p>End your admin session.</p>
                <span class="action-arrow" style="background: #b03a2e; color: white;">→</span>
            </a>

        </div>
    </div>

</div>

<?php include 'footer.php'; ?>