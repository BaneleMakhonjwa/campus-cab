<?php
// admin_auth.php - Admin helper functions

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']) && isset($_SESSION['admin_role']);
}

function isSuperAdmin() {
    return isset($_SESSION['admin_role']) && $_SESSION['admin_role'] === 'super_admin';
}

function requireAdmin() {
    if (!isAdminLoggedIn()) {
        header("Location: login.php?role=admin");
        exit;
    }
}

function requireSuperAdmin() {
    requireAdmin();
    if (!isSuperAdmin()) {
        header("Location: admin_dashboard.php?error=access_denied");
        exit;
    }
}

function logAction($conn, $action, $targetType = null, $targetID = null, $targetName = null) {
    if (!isAdminLoggedIn()) return;
    $actorName = $_SESSION['admin_name'] ?? 'Admin';
    $description = $action . ($targetType ? ' | '.$targetType.' #'.($targetID ?? '') : '') . ($targetName ? ' | '.$targetName : '');
    $stmt = $conn->prepare("INSERT INTO user_activity_log (actor_type,actor_name,action_type,target_type,target_id,description) VALUES ('Admin',?,?,?,?,?)");
    $id = $targetID !== null ? (string)$targetID : null;
    $stmt->bind_param('sssss',$actorName,$action,$targetType,$id,$description);
    $stmt->execute(); $stmt->close();
}
?>
