<?php
session_start();
include 'db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['driver_id'])) {
    echo json_encode(['error' => 'Not logged in']);
    exit;
}

$driverID = (int)$_SESSION['driver_id'];
$action = $_GET['action'] ?? 'ping';

if ($action === 'ping') {
    $stmt = $conn->prepare("UPDATE driver SET availability_status='Available' WHERE DriverID=? AND driverAccount_Status='Active'");
    $stmt->bind_param('i',$driverID); $stmt->execute(); $stmt->close();
    echo json_encode(['status'=>'online']); exit;
}

if ($action === 'offline') {
    $stmt = $conn->prepare("UPDATE driver SET availability_status = 'Unavailable' WHERE DriverID = ?");
    $stmt->bind_param("i", $driverID);
    $stmt->execute();
    $stmt->close();

    echo json_encode(['status' => 'offline']);
    exit;
}

if ($action === 'check_ride') {
    // Find a new ride for this driver
    $stmt = $conn->prepare("
        SELECT 
            r.rideID,
            r.pickup_address,
            r.destination_address,
            r.estimated_distance_km,
            r.estimated_duration_min,
            r.estimated_price,
            r.requested_at,
            COALESCE(s.studentFname, st.staff_name) AS studentFname,
            COALESCE(s.studentLname, st.surname) AS studentLname,
            COALESCE(s.studentPhoneNo, st.staff_phone) AS studentPhoneNo
        FROM ride r
        LEFT JOIN student s ON r.studentID = s.studentID
        LEFT JOIN staff st ON r.staff_id = st.staff_id
        JOIN driver me ON me.DriverID = ?
        WHERE r.ride_status = 'Requested'
          AND r.DriverID IS NULL
          AND me.availability_status = 'Available'
          AND me.driverAccount_Status = 'Active'

        ORDER BY r.requested_at ASC
        LIMIT 1
    ");
    $stmt->bind_param("i", $driverID);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        echo json_encode(['ride' => $row]);
    } else {
        echo json_encode(['ride' => null]);
    }
    $stmt->close();
    exit;
}
?>